#' input generation of all dummy nn with holiday data.
#'
#' DID NOT PERFORM!! USE \link{simple_nn_with_holiday_forecast}
#'
#' @param df timeseries data frame.
#' @param from forecast starting date.
#' @param postal_code of current meter point.
#' @param generate_holidays_data_driven generate the holiday calender
#'   data driven. See \link{get_holidays_from_timeseries}.
#'
#' @import dplyr
#' @importFrom lubridate ymd
#' @importFrom lubridate minutes
#' @importFrom lubridate as_datetime
#' @importFrom lubridate wday
#'
#' @export

all_dummy_nn_input_generation <- function(df, from, postal_code, generate_holidays_data_driven = FALSE){

  from_datetime <- as_datetime(from)

  # get forecast interval
  fc_interval <- df %>% filter(timestamp >= from_datetime) %>% pull(timestamp)

  if(generate_holidays_data_driven){
    holidays <- get_holidays_from_timeseries(df = df, postal_code_or_state = postal_code, forecast_start_date = from_datetime)
  } else {
    holidays <- get_holidays_from_postal_code(postal_code_or_state = postal_code)
  }

  # trimm forecast starting date to the actual day
  from <- ymd(substr(from_datetime, 1, 10))

  # get dates of timeseries
  dates <-
    df %>%
    mutate(timestamp = timestamp - minutes(15)) %>%
    select(timestamp) %>%
    left_join(mapping_table_datetime_to_day) %>%
    pull(timestamp_new) %>%
    unique()

  # get indizes of observation and forecast periods
  observation_idx <- which(dates < from)
  forecast_idx <- which(dates >= from)

  all_data_x <- data_frame(Weekday = wday(dates, label = TRUE, abbr = FALSE))
  all_data_x <- all_data_x %>%
    mutate(Monday = Weekday == 'Monday',
           Tuesday = Weekday == 'Tuesday',
           Wednesday = Weekday == 'Wednesday',
           Thursday = Weekday == 'Thursday',
           Friday = Weekday == 'Friday',
           Saturday = Weekday == 'Saturday',
           Sunday = Weekday == 'Sunday',
           Holiday = dates %in% holidays) %>%
    mutate_all(as.integer) %>%
    mutate(Time = (1:length(dates))/length(dates),
           Day_of_year = yday(dates)/366) %>%
    select(-Weekday) %>% as.matrix()

  # generate y values
  all_data_y <- matrix(df$value, ncol = 96, byrow = TRUE)

  # set up train and test set
  train_x <- all_data_x[observation_idx,] %>% data.matrix()
  train_y <- all_data_y[observation_idx,] %>% data.matrix()
  test_x  <- all_data_x[forecast_idx,] %>% data.matrix()
  test_y  <- all_data_y[forecast_idx,] %>% data.matrix()

  return(list(train_x = train_x, train_y = train_y, test_x = test_x, test_y = test_y, fc_interval = fc_interval))

}

#' forecast using all dummy nn
#'
#' DID NOT PERFORM!! USE \link{simple_nn_with_holiday_forecast}
#'
#' @param df timeseries data frame.
#' @param net neurel network specification.
#' @param from forecast starting date.
#' @param model_selection flag to perform model selection based on validation errors.
#' @param generate_holidays_data_driven see \link{get_holidays_from_timeseries}.
#' @param number_of_folds number of folds to be used in \link{mx.crossvalidation}.
#' @param postal_code postal code of current timeseries.
#' @param verbose print during cross validation.
#' @param verbose_mxnet Print during mxnet training.
#' @param ... other parameters passed to \link{mx.crossvalidation}.
#'
#' @import dplyr
#'
#' @export

all_dummy_nn_forecast <- function(df, net = NULL, from, model_selection = FALSE, generate_holidays_data_driven = FALSE, number_of_folds = 5, postal_code, verbose = TRUE, verbose_mxnet = FALSE, ...){

  if(is.null(net)) net <- get_default_networks()

  input_data <-
    all_dummy_nn_input_generation(df = df,
                                  from = from,
                                  postal_code = postal_code,
                                  generate_holidays_data_driven = generate_holidays_data_driven)

  train_x <- input_data$train_x
  train_y <- input_data$train_y
  test_x  <- input_data$test_x
  test_y  <- input_data$test_y
  fc_interval <- input_data$fc_interval

  additional_model_slug <- paste0('all_dummy_data_holidays', generate_holidays_data_driven, '_')

  result_df <- mx.crossvalidation(net = net,
                                  train_x = train_x,
                                  train_y = train_y,
                                  number_of_folds = number_of_folds,
                                  verbose = verbose,
                                  verbose_mxnet = verbose_mxnet,
                                  additional_model_slug = additional_model_slug,
                                  ...)

  result_df <-
    result_df %>%
    mutate(forecast = map(model, ~mx.data.output.generation(model = .x, test_x = test_x, test_y = test_y, fc_interval = fc_interval)))

  naive_result_df <- naive_model_validation(df = df, from = from, postal_code = postal_code)

  result_df <- bind_rows(result_df, naive_result_df)

  if (model_selection) {

    return(nn_model_selection(result_df))

  }

  return(result_df)

}
