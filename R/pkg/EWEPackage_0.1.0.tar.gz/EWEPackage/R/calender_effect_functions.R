#' Get shifted dates from holiday data.
#'
#' \code{get_shifted_dates_from_holidays} generates a mapping table for holiday
#' accounted shifting.
#'
#' Given an array of dates in \code{original_days_to_shift} and an array of
#' holidays \code{holidays} the function returns the corresponding shifted dates
#' using the following heuristics:
#'
#' \itemize{ \item Saturdays and Sundays are shifted exactly 7 days, \item
#' Holidays are shifted to the last Sunday, \item Businessdays are shifted to
#' the last businessday which is the same weekday. }
#'
#' @examples
#' holidays <- get_holidays_from_postal_code('Bremen')
#' original_days_to_shift <-
#'  seq(lubridate::ymd('2016-01-01'),
#'  lubridate::ymd('2017-01-01'), by = 'day')
#' get_shifted_dates_from_holidays(original_days_to_shift = original_days_to_shift,
#'                                 holidays = holidays)
#'
#' @param original_days_to_shift vector of days to shift.
#' @param holidays holidays.
#'
#' @import dplyr
#' @importFrom lubridate wday
#' @importFrom lubridate days
#' @importFrom lubridate ymd
#' @importFrom lubridate floor_date
#' @importFrom DBI dbWriteTable
#'
#' @export

get_shifted_dates_from_holidays <- function(original_days_to_shift, holidays){

  # remove sundays which are holidays from holidays, since they are supposed to be shifted to the last sunday
  holidays <- holidays[wday(holidays, label = T, abbr = F) != 'Sunday']

  # get data frame of input dates, seven day shifted dates, and dates shifted to the last sunday
  # and calculate flag indicating wether input date is holiday or not
  current_data_frame_of_shifte_dates <-
    data_frame(original_day = original_days_to_shift) %>%
    mutate(seven_day_shift = original_day - days(7), floored_day = floor_date(original_day, unit = 'week')) %>%
    mutate(is_current_holiday = (original_day %in% holidays))

  # get data frame subset where the input date is a holiday these are shifted to the last sunday so we dont have to bother
  holiday_subset <- current_data_frame_of_shifte_dates %>% filter(is_current_holiday)

  # get data frame subset where the input date is not a holiday
  non_holiday_subset <- current_data_frame_of_shifte_dates %>% filter(!is_current_holiday)

  # get data frame subset where input is not a holiday and the seven day shift is also not a holiday.
  # we dont have to bother for these.
  seven_day_shift_is_not_holiday <- non_holiday_subset %>% filter(! seven_day_shift %in% holidays)

  # get data frame subset where input date is not a holiday but the seven day shift is a holiday.
  # this is the crucial part and has to be put into the function again
  seven_day_shift_is_holiday <-
    non_holiday_subset %>%
    filter(seven_day_shift %in% holidays) %>%
    select(original_day, seven_day_shift) %>%
    rename(temporary_shifted_day = seven_day_shift)

  if(nrow(seven_day_shift_is_holiday) == 0){ # if there are no furhter special cases

    out <- bind_rows(
      data_frame(original_day = holiday_subset$original_day, shifted_day = holiday_subset$floored_day),
      data_frame(original_day = seven_day_shift_is_not_holiday$original_day, shifted_day = seven_day_shift_is_not_holiday$seven_day_shift)
    )

  } else { # if there are another special cases left

    tmp <-
      seven_day_shift_is_holiday %>%
      left_join(
        get_shifted_dates_from_holidays(original_days_to_shift = seven_day_shift_is_holiday$temporary_shifted_day, ymd(setdiff(as.character(holidays), as.character(seven_day_shift_is_holiday$temporary_shifted_day)))) %>%
          rename(temporary_shifted_day = original_day),
        by = "temporary_shifted_day"
      ) %>% select(original_day, shifted_day)

    out <- bind_rows(
      data_frame(original_day = holiday_subset$original_day, shifted_day = holiday_subset$floored_day),
      data_frame(original_day = seven_day_shift_is_not_holiday$original_day, shifted_day = seven_day_shift_is_not_holiday$seven_day_shift),
      tmp
    )

  }


  return(out %>% arrange(original_day))

}



#' Get shifted datetimes from holiday data.
#'
#' \code{get_shifted_datetimes_from_holidays} generates a mapping table for holiday
#' accounted shifting.
#'
#' Given an array of dates in \code{original_days_to_shift} and an array of
#' holidays \code{holidays} the function returns the corresponding shifted datetimes
#' using the following heuristics:
#'
#' \itemize{
#'   \item Saturdays and Sundays are shifted exactly 7 days,
#'   \item Holidays are shifted to the last Sunday,
#'   \item Businessdays are shifted to the last businessday which is the same
#'   weekday.
#' }
#'
#' @examples
#' holidays <- get_holidays_from_postal_code('Bremen')
#' original_days_to_shift <-
#'  seq(lubridate::ymd('2016-01-01'),
#'  lubridate::ymd('2017-01-01'), by = 'day')
#' get_shifted_datetimes_from_holidays(original_days_to_shift = original_days_to_shift,
#'                                     holidays = holidays)
#'
#' @param original_days_to_shift vector of days to shift.
#' @param holidays holidays.
#'
#' @import dplyr
#' @importFrom tidyr nest
#' @importFrom tidyr unnest
#'
#' @export

get_shifted_datetimes_from_holidays <- function(original_days_to_shift, holidays){

  # FUTURE TODO performance improvement using data.table!

  data_frame_of_shifted_dates <- get_shifted_dates_from_holidays(original_days_to_shift, holidays)

  original_timestamp_df <- data_frame_of_shifted_dates %>%
    select(original_day) %>%
    rename(day = original_day) %>%
    left_join(mapping_table_day_to_datetime, by = 'day') %>%
    rename(original_timestamp = datetime) %>%
    select(original_timestamp) %>%
    unnest()

  shifted_timestamp_df <- data_frame_of_shifted_dates %>%
    select(shifted_day) %>%
    rename(day = shifted_day) %>%
    left_join(mapping_table_day_to_datetime, by = 'day') %>%
    rename(shifted_timestamp = datetime) %>%
    select(shifted_timestamp) %>%
    unnest()

  bind_cols(original_timestamp_df, shifted_timestamp_df)

}

#' Get shifted dates accounting for holidays in specific state helper function.
#'
#' \code{get_shifted_dates_using_holiday_data_helper} returns a mapping table
#' with one week shifted dates in a specific state of Germany.
#'
#' Returns the one week shifted dates for a sequence of dates given by
#' \code{forecast_period} accounting for holidays in the following way:
#' \itemize{
#'   \item Saturdays and Sundays are shifted exactly 7 days,
#'   \item Holidays are shifted to the last Sunday,
#'   \item Businessdays are shifted to the last businessday which is the same
#'   weekday.
#' }
#'
#' @param postal_code_or_state character or integer of the postal code or the state. If
#'   'all' then all german holidays are used. If it is a vector of admissible
#'   characters it uses the union of all the holidays.
#' @param forecast_period the period of dates which should be shifted.
#' @param account_for_bridging_days logical indicating wether bridging days should be
#' accounted for as well
#'
#' @return returns data frame of original dates and shifted dates
#'
#' @examples
#' require(lubridate)
#'
#' forecast_period <- seq(ymd('2014-02-01'), ymd('2017-01-01'), by = 'day')
#'
#' get_shifted_dates_using_holiday_data_helper('01156', forecast_period)
#' get_shifted_dates_using_holiday_data_helper(48155, forecast_period)
#' get_shifted_dates_using_holiday_data_helper('Sachsen', forecast_period)
#' get_shifted_dates_using_holiday_data_helper('Bremen', forecast_period)
#' get_shifted_dates_using_holiday_data_helper(c('Bremen','Sachsen') , forecast_period)
#'
#' @import dplyr
#' @importFrom lubridate floor_date
#'
#' @export

get_shifted_dates_using_holiday_data_helper <- function(postal_code_or_state, forecast_period, account_for_bridging_days = FALSE){

  # convert input to character vector
  postal_code_or_state <- as.character(postal_code_or_state)

  #get holidays for postal_code_or_state
  holidays <- get_holidays_from_postal_code(postal_code_or_state)

  shifted_days_df <- data_frame()

  # for loop to get shifted days
  for (i in seq_along(forecast_period)){

    current_day <- forecast_period[i]

    if (weekdays(current_day) %in% c('Saturday', 'Sunday')){ # if saturday or sunday -> shift exactly 7 days

      day_to_copy <- current_day - 7

    } else if (current_day %in% holidays){ # if holiday -> shift to the last sunday

      last_sunday <- floor_date(current_day, "week")
      day_to_copy <- last_sunday

    } else if (account_for_bridging_days & is_bridging_day(current_day,holidays)) {
      last_sunday <- floor_date(current_day, "week")
      day_to_copy <- last_sunday

    } else { # otherwise it's a businessday -> search for last businessday on the same weekday

      previous_day <- current_day - 7

      while (previous_day %in% holidays | (account_for_bridging_days & is_bridging_day(previous_day,holidays))){
        previous_day <- previous_day - 7
      }

      day_to_copy <- previous_day

    }

    shifted_days_df <- bind_rows(shifted_days_df, data_frame(original_day = current_day, shifted_day = day_to_copy))

  }

  return(shifted_days_df)

}


#' Get shifted dates accounting for holidays in specific state.
#'
#' \code{get_shifted_dates_using_holiday_data} returns a mapping table with one
#' week shifted dates in a specific state or postal code of Germany.
#'
#' Returns the one week shifted dates accounting for holidays in the
#' given state or postal code in the following way:
#' \itemize{
#'   \item Saturdays and Sundays are shifted exactly 7 days,
#'   \item Holidays are shifted to the last Sunday,
#'   \item Businessdays are shifted to the last businessday which is the same weekday.
#' }
#'
#' @param postal_code_or_state character or integer of the postal code or the state. If
#'   'all' then all german holidays are used.
#' @return returns data frame of original dates and shifted dates
#'
#' @examples
#' get_shifted_dates_using_holiday_data(48155)
#' get_shifted_dates_using_holiday_data('01156')
#' get_shifted_dates_using_holiday_data('Sachsen')
#' get_shifted_dates_using_holiday_data('Bremen')
#' get_shifted_dates_using_holiday_data('all')
#'
#' @import dplyr
#' @importFrom tidyr nest
#' @importFrom tidyr unnest
#' @importFrom lubridate floor_date
#'
#' @export

get_shifted_dates_using_holiday_data <- function(postal_code_or_state){

  # convert input to character vector
  postal_code_or_state <- as.character(postal_code_or_state)


  # Control sequence
  if (postal_code_or_state == 'all') {

    return(mapping_table_state_to_shifted_holidays %>% filter(state == postal_code_or_state) %>% select(shifted_days) %>% unnest())

  } else if (postal_code_or_state %in% mapping_table_state_to_holiday$state){

    return(mapping_table_state_to_shifted_holidays %>% filter(state == postal_code_or_state) %>% select(shifted_days) %>% unnest())

  } else if (postal_code_or_state %in% mapping_table_postal_code_to_state$postal_code){

    current_state <- mapping_table_postal_code_to_state %>% filter(postal_code == postal_code_or_state) %>% pull(state)
    return(mapping_table_state_to_shifted_holidays %>% filter(state == current_state) %>% select(shifted_days) %>% unnest())

  } else {

    stop('postal_code_or_state was not found')

  }

}


#' Get shifted timestamps accounting for holidays in specific state.
#'
#' \code{get_shifted_timestamps_using_holiday_data} returns a mapping table with one
#' week shifted dates in a specific state or postal code of Germany.
#'
#' Returns the one week shifted dates accounting for holidays in the
#' given state or postal code in the following way:
#' \itemize{
#'   \item Saturdays and Sundays are shifted exactly 7 days,
#'   \item Holidays are shifted to the last Sunday,
#'   \item Businessdays are shifted to the last businessday which is the same weekday.
#' }
#'
#' @param postal_code_or_state character or integer of the postal code or the state. If
#'   'all' then all german holidays are used.
#' @return returns data frame of original dates and shifted dates
#'
#' @examples
#' get_shifted_timestamps_using_holiday_data(48155)
#' get_shifted_timestamps_using_holiday_data('01156')
#' get_shifted_timestamps_using_holiday_data('Sachsen')
#' get_shifted_timestamps_using_holiday_data('Bremen')
#' get_shifted_timestamps_using_holiday_data('all')
#'
#' @import dplyr
#' @importFrom tidyr nest
#' @importFrom tidyr unnest
#' @importFrom lubridate floor_date
#'
#' @export

get_shifted_timestamps_using_holiday_data <- function(postal_code_or_state){

  # convert input to character vector
  postal_code_or_state <- as.character(postal_code_or_state)

  # Control sequence
  if (postal_code_or_state == 'all') {

    return(mapping_table_state_to_shifted_holidays %>% filter(state == postal_code_or_state) %>% select(shifted_timestamps) %>% unnest())

  } else if (postal_code_or_state %in% mapping_table_state_to_holiday$state){

    return(mapping_table_state_to_shifted_holidays %>% filter(state == postal_code_or_state) %>% select(shifted_timestamps) %>% unnest())

  } else if (postal_code_or_state %in% mapping_table_postal_code_to_state$postal_code){

    current_state <- mapping_table_postal_code_to_state %>% filter(postal_code == postal_code_or_state) %>% pull(state)
    return(mapping_table_state_to_shifted_holidays %>% filter(state == current_state) %>% select(shifted_timestamps) %>% unnest())

  } else {

    warning(paste('postal_code_or_state', postal_code_or_state ,'was not found. Returning all.'))

    return(mapping_table_state_to_shifted_holidays %>% filter(state == 'all') %>% select(shifted_timestamps) %>% unnest())

  }

}


#' Get shifted timestamps accounting for holidays in specific state.
#'
#' \code{get_shifted_timestamps_using_holiday_data} returns a mapping table with one
#' week shifted dates in a specific state or postal code of Germany.
#'
#' Returns the one week shifted dates accounting for holidays in the
#' given state or postal code in the following way:
#' \itemize{
#'   \item Saturdays and Sundays are shifted exactly 7 days,
#'   \item Holidays are shifted to the last Sunday,
#'   \item Businessdays are shifted to the last businessday which is the same weekday.
#' }
#'
#' @param postal_code_or_state character or integer of the postal code or the state. If
#'   'all' then all german holidays are used.
#' @return returns data frame of original dates and shifted dates
#'
#' @examples
#' get_shifted_timestamps_using_holiday_data(48155)
#' get_shifted_timestamps_using_holiday_data('01156')
#' get_shifted_timestamps_using_holiday_data('Sachsen')
#' get_shifted_timestamps_using_holiday_data('Bremen')
#' get_shifted_timestamps_using_holiday_data('all')
#'
#' @import dplyr
#' @importFrom tidyr nest
#' @importFrom tidyr unnest
#' @importFrom lubridate floor_date
#'
#' @export

get_shifted_timestamps_using_holiday_and_bridging_day_data <- function(postal_code_or_state){

  # convert input to character vector
  postal_code_or_state <- as.character(postal_code_or_state)

  # Control sequence
  if (postal_code_or_state == 'all') {

    return(mapping_table_state_to_shifted_holidays_including_bridging_days %>% filter(state == postal_code_or_state) %>% select(shifted_timestamps) %>% unnest())

  } else if (postal_code_or_state %in% mapping_table_state_to_shifted_holidays_including_bridging_days$state){

    return(mapping_table_state_to_shifted_holidays_including_bridging_days %>% filter(state == postal_code_or_state) %>% select(shifted_timestamps) %>% unnest())

  } else if (postal_code_or_state %in% mapping_table_postal_code_to_state$postal_code){

    current_state <- mapping_table_postal_code_to_state %>% filter(postal_code == postal_code_or_state) %>% pull(state)
    return(mapping_table_state_to_shifted_holidays_including_bridging_days %>% filter(state == current_state) %>% select(shifted_timestamps) %>% unnest())

  } else {

    warning(paste('postal_code_or_state', postal_code_or_state ,'was not found. Returning all.'))

    return(mapping_table_state_to_shifted_holidays_including_bridging_days %>% filter(state == 'all') %>% select(shifted_timestamps) %>% unnest())

  }

}

#' Get the forecast start date based on a certain split of the data.
#'
#' \code{get_forecast_start_date} returns the start date of the forecast horizon
#' based on a certain split.
#'
#' Based on a percentage split the start date of the forecast horizon is
#' returned. Default is a 2/3 split. The corresponding date is returned in an
#' ymd_hms format ending with 00:15:00. Therefore the forecast start date is
#' inclusive!
#'
#' @param df time series data frame with column names 'timestamp' and 'value'.
#' @param observation_percentage the fraction of the timeseries which is the
#'   observation period.
#' @return inclusive forecast start date.
#'
#' @import dplyr
#' @importFrom lubridate floor_date
#' @importFrom lubridate ymd_hms
#'
#' @export

get_forecast_start_date <- function(df, observation_percentage = 2/3){

  last_observation <- round(nrow(df) * observation_percentage)

  forecast_start_date <-
    df[last_observation, ]$timestamp %>%
    floor_date(unit = 'day') %>%
    as.character() %>%
    paste('00:15:00') %>%
    ymd_hms()

  return(forecast_start_date)

}


# comment_bf: This function seems to be unused! ####

# #' Convert a day to sequence of datetimes.
# #'
# #' \code{day_to_datetime} generates a sequence of of datetimes for a given day.
# #'
# #' Given a day the corresponding sequence of datetimes is returned. Starting
# #' from 00:00:15 and ending with 00:00:00 of the next day.
# #'
# #'
# #' @examples
# #' day_to_datetime(lubridate::ymd('2016-01-01'))
# #'
# #' @param day to be converted to the sequence of datetimes.
# #'
# #' @importFrom lubridate ymd_hms
# #' @importFrom lubridate days
# #'
# #' @export
#
# day_to_datetime <- function(day) {
#
#   ymd_hms(seq(ymd_hms(paste(day,'00:15:00')), ymd_hms(paste(day + days(1),'00:00:00')), by = '15 min'))
#
# }
