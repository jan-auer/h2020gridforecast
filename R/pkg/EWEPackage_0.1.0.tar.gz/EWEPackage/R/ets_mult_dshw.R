####################################################################
## An adapted multiplicative Double Seasonal Holt Winter method
####################################################################



#' Double-Seasonal Holt-Winters Forecasting
#'
#' Returns forecasts using Taylor's (2003) Double-Seasonal Holt-Winters method
#' without trend.
#'
#' We use use no trend and
#' multiplicative seasonality, where there are two seasonal components which
#' are multiplied together. For example, with a series of half-hourly data, one
#' would set \code{period1=48} for the daily period and \code{period2=336} for
#' the weekly period. The smoothing parameter notation used here is different
#' from that in Taylor (2003); instead it matches that used in Hyndman et al
#' (2008) and that used for the \code{ets} function.
#'
#' @param y  A numeric vector.
#' @param period1 Period of the shorter seasonal period.
#' @param period2 Period of the longer seasonal period.
#' @param h Number of periods for forecasting.
#' @param alpha Smoothing parameter for the level. If \code{NULL}, the
#' parameter is estimated using least squares.
#' @param gamma Smoothing parameter for the first seasonal period. If
#' \code{NULL}, the parameter is estimated using least squares.
#' @param omega Smoothing parameter for the second seasonal period. If
#' \code{NULL}, the parameter is estimated using least squares.
#' @param phi Autoregressive parameter. If \code{NULL}, the parameter is
#' estimated using least squares.
#' @param lambda Box-Cox transformation parameter. Ignored if \code{NULL}.
#' Otherwise, data transformed before model is estimated.
#' @param biasadj Use adjusted back-transformed mean for Box-Cox
#' transformations. If TRUE, point forecasts and fitted values are mean
#' forecast. Otherwise, these points can be considered the median of the
#' forecast densities. By default, the value is taken from what was used when
#' fitting the model.
#' @param armethod If TRUE, the forecasts are adjusted using an AR(1) model for
#' the errors.
#' @param model If it's specified, an existing model is applied to a new data
#' set.
#' @param opt_crit Either "square" or "abs" specifying which error measure should
#' be used for estimating the parameters
#' @return An object of class "\code{forecast}" which is a list that includes the
#' following elements:
#'   \item{model}{A list containing information about the fitted model}
#'   \item{method}{The name of the forecasting method as a character string}
#'   \item{mean}{Point forecasts as a time series}
#'   \item{x}{The original time series.}
#'   \item{residuals}{Residuals from the fitted model. That is x minus fitted values.}
#'   \item{fitted}{Fitted values (one-step forecasts)}
#'
#' The function \code{summary} is used to obtain and print a summary of the
#' results, while the function \code{plot} produces a plot of the forecasts.
#'
#' The generic accessor functions \code{fitted.values} and \code{residuals}
#' extract useful features of the value returned by \code{dshw}.
#'
#' @references Taylor, J.W. (2003) Short-term electricity demand forecasting
#' using double seasonal exponential smoothing. \emph{Journal of the
#' Operational Reseach Society}, \bold{54}, 799-805.
#'
#' @importFrom zoo rollmean.default
#'
#' @examples
#'
#' \dontrun{
#' fcast <- mult_dshw(taylor)
#' plot(fcast)
#'
#' t <- seq(0,5,by=1/20)
#' x <- exp(sin(2*pi*t) + cos(2*pi*t*4) + rnorm(length(t),0,.1))
#' fit <- mult_dshw(x,20,5)
#' plot(fit)
#' }
#'

mult_dshw <- function(y, period1=NULL, period2=NULL, h=2*max(period1,period2),
                 alpha=NULL, gamma=NULL, omega=NULL, phi=NULL, lambda=NULL, biasadj=FALSE,
                 armethod=TRUE, model=NULL, opt_crit="square")
{
  if(min(y,na.rm=TRUE) <= 0){
    stop("mult_dshw not suitable when data contain zeros or negative numbers")
  }
  seriesname <- deparse(substitute(y))
  if (!is.null(model) && model$method == "DSHW") {
    period1 <- model$period1
    period2 <- model$period2
  } else if(is.null(period1) | is.null(period2)) {
    stop("Error in mult_dshw(): the seasonal periods should be specified with period1= and period2=")
  } else {
    if(period1 > period2)
    {
      tmp <- period2
      period2 <- period1
      period1 <- tmp
    }
  }

  if(!armethod)
    phi <- 0

  if(period1 < 1 | period1 == period2)
    stop("Inappropriate periods")
  ratio <- period2/period1
  if(ratio-trunc(ratio) > 1e-10)
    stop("Seasonal periods are not nested")

  if (!is.null(model)) {
    lambda <- model$model$lambda
  }

  if (!is.null(lambda))
  {
    origy <- y
    y <- BoxCox(y, lambda)
  }

  if (!is.null(model)) {
    pars <- model$model
    alpha <- pars$alpha
    #beta <- pars$beta
    gamma <- pars$gamma
    omega <- pars$omega
    phi <- pars$phi
  } else {
    pars <- rep(NA,4)

    if(!is.null(alpha))
      pars[1] <- alpha
    #if(!is.null(beta))
      #pars[2] <- beta
    if(!is.null(gamma))
      pars[2] <- gamma
    if(!is.null(omega))
      pars[3] <- omega
    if(!is.null(phi))
      pars[4] <- phi
  }

  # Estimate parameters
  if(sum(is.na(pars)) > 0)
  {
    pars <- par_dshw(y,period1,period2,pars, opt_crit)
    alpha <- pars[1]
    #beta <- pars[2]
    gamma <- pars[2]
    omega <- pars[3]
    phi <- pars[4]
  }

  ## Allocate space
  n <- length(y)
  yhat <- numeric(n)

  ## Starting values
  compute_initial_values = TRUE
  I <- numeric(length = n+period1)
  if (compute_initial_values || is.null(model) || is.null(model$model$I_start)){
    # heuristic for finding good initial values
    I[1:period1] <- seasindex(y,period1)
  } else{
    I[1:period1] <- tail(model$model$I,period1)
  }
  w <- numeric(length = n+period2)
  if (compute_initial_values || is.null(model) || is.null(model$model$w_start)){
    # heuristic for finding good initial values
    w_start <- seasindex(y,period2)
    w_start <- w_start[1:period2] / rep(I[1:period1],ratio)
  } else{
    w_start <- tail(model$model$w, period2)
  }

  if (compute_initial_values || is.null(model) || is.null(model$model$smoothed)){
    s <- (mean(y[1:(2*period2)]))
  } else{
    s <- model$model$smoothed
  }

  w[1:period2] <- w_start

  ## In-sample fit
  for(i in 1: n)
  {
    yhat[i] <- (s) * I[i]*w[i]
    snew <- alpha*(y[i]/(I[i]*w[i]))+(1-alpha)*(s)
    #tnew <- beta*(snew-s)+(1-beta)*t
    I[i+period1] <- gamma*(y[i]/(snew*w[i])) + (1-gamma)*I[i]
    w[i+period2] <- omega*(y[i]/(snew*I[i])) + (1-omega)*w[i]
    s <- snew
    #t <- tnew
  }

  # Forecasts
  #fcast <- (s + (1:h)*t) * rep(I[n+(1:period1)],h/period1 + 1)[1:h] * rep(w[n+(1:period2)],h/period2 + 1)[1:h]
  fcast <- (s ) * rep(I[n+(1:period1)],h/period1 + 1)[1:h] * rep(w[n+(1:period2)],h/period2 + 1)[1:h]

  # Calculate MSE and MAPE
  e <- y - yhat
  if(armethod)
  {
    yhat <- yhat + phi * c(0,e[-n])
    e <- y - yhat
    fcast <- fcast + phi^(1:h)*e[n]
  }
  mse <- mean(e^2)
  mdae <- mean(abs(e))
  mape <- mean(abs(e)/y)*100


  if(!is.null(lambda))
  {
    y <- origy
    fcast <- InvBoxCox(fcast, lambda, biasadj, var(e))
    attr(lambda, "biasadj") <- biasadj
    #Does this also need a biasadj backtransform?
    yhat <- InvBoxCox(yhat,lambda)
  }

  return(structure(list(mean=fcast, method = "DSHW", x=y,residuals=e,fitted=yhat,series=seriesname,
                        model=list(mape=mape,mse=mse,mdae = mdae,alpha=alpha, gamma=gamma,omega=omega,phi=phi,
                                   lambda = lambda, smoothed=s,w=w,I=I), period1 = period1,
                        period2 = period2),class="forecast"))

}

### Double Seasonal Holt-Winters smoothing parameter optimization
####################################################################################################################
####################################################################################################################


par_dshw <- function(y, period1, period2, pars, opt_crit)
{
  # initial values are chosen to best fit electricity load forecast
  start <- c(0.1,0.2,0.6,0.7)[is.na(pars)]
  out <- optim(start, dshw.error, y=y, period1=period1, period2=period2, pars=pars, opt_crit=opt_crit,
               method = "L-BFGS-B", lower = c(0,0,0,0), upper = c(1,1,1,0.95))
  #             control = list(reltol=0.01))
  pars[is.na(pars)] <- out$par
  return(pars)
}

dshw.error <- function(par, y, period1, period2, pars, opt_crit)
{
  pars[is.na(pars)] <- par
  if(max(pars) > 0.99 | min(pars) < 0 | pars[4] > .95)
    return(1e20) #what !?!?
  else
    if (identical(opt_crit,"abs")){
      return(mult_dshw(y, period1, period2, h=1, pars[1], pars[2], pars[3], pars[4], armethod=(abs(pars[4]) >1e-7))$model$mdae)
    } else if (identical(opt_crit,"square")){
      return(mult_dshw(y, period1, period2, h=1, pars[1], pars[2], pars[3], pars[4], armethod=(abs(pars[4]) >1e-7))$model$mse)
    } else {
      stop("Optimization criterium not valid. has to be *abs* or * square*")
    }
}

### Calculating seasonal indexes
# this is a heuristic for finding good initial values
seasindex <- function(y,p)
{
  #require(zoo)
  n <- length(y)
  n2 <- 2*p
  shorty <- y[1:n2]
  average <- numeric(n)
  simplema <- zoo::rollmean.default(shorty, p)
  if (identical(p%%2,0)) # Even order
  {
    centeredma <- zoo::rollmean.default(simplema[1:(n2-p+1)],2)
    average[p/2 + 1:p] <- shorty[p/2 + 1:p]/centeredma[1:p]
    si <- average[c(p+(1:(p/2)),(1+p/2):p)]
  }
  else # Odd order
  {
    average[(p-1)/2 + 1:p] <- shorty[(p-1)/2 + 1:p]/simplema[1:p]
    si <- average[c(p+(1:((p-1)/2)),(1+(p-1)/2):p)]
  }
  return(si)
}
