#' Helper for creating different regression models
#'
#' This function is a helper that generates some different combinations of calendar effect dummies and lagged variables.
#'
#' More detail needed?
#'
#' @param model_complexity Adjust model complexity. Default set to 2, corresponding to 42 models.
#' @param school Boolean value. If TRUE, then also school holidays are taken into account. Default set to TRUE.
#'
#' @return A list with two elements: all_lags_grid and all_dummies_grid
#' @export
get_model_grid <- function(model_complexity = 2, school = TRUE){
  if(school){
    switch(model_complexity,
           { # low complexity = 4*5 models
             all_dummies <- list(
               # list(c(2,3,4,5,6), c(7,1,8,9)), # (Monday to Friday), (Sat, Sun, Holi, Bridge)

               list(2, c(3,4,5), 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)
               list(2, c(3,4,5), 6, c(7,1,8,9), 10), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)

               list(2, 3, 4, 5, 6, c(7,1,8,9)),
               list(2, 3, 4, 5, 6, c(7,1,8,9), 10)) # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Sun, Holi, Bridge)

             all_lags <- list(c(0),
                              c(2),
                              c(2,3),
                              c(2,3,7),
                              c(2,3,7,14))
           },
           { # medium complexity = 8*5 models
             all_dummies <- list(
               list(c(2,3,4,5,6), c(7,1,8,9)), # (Monday to Friday), (Sat, Sun, Holi, Bridge)
               list(c(2,3,4,5,6), c(7,9), c(1,8), 10), # (Monday to Friday), (Sat, Bridge), (Sun, Holi)

               list(2, c(3,4,5), 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)
               list(2, c(3,4,5), 6, c(7,1,8,9), 10), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)
               list(2, c(3,4,5), 6, c(7,9), c(1,8), 10), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Bridge), (Sun, Holi)


               list(2, 3, 4, 5, 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Sun, Holi, Bridge)
               list(2, 3, 4, 5, 6, c(7,1,8,9), 10), # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Sun, Holi, Bridge)
               list(2, 3, 4, 5, 6, c(7,9), c(1,8), 10)) # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Bridge), (Sun, Holi)



             all_lags <- list(c(0),
                              c(2),
                              c(2,3),
                              c(2,3,7),
                              c(2,3,7,14))
           },
           { # high complexity = 8*6 models
             all_dummies <- list(

               list(2, c(3,4,5), 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)
               list(2, c(3,4,5), 6, c(7,9), c(1,8)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Bridge), (Sun, Holi)

               list(2, 3, 4, 5, 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Sun, Holi, Bridge)
               list(2, 3, 4, 5, 6, c(7,9), c(1,8)), # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Bridge), (Sun, Holi)

              list(2, c(3,4,5), 6, c(7,1,8,9), 10), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)
              list(2, c(3,4,5), 6, c(7,9), c(1,8), 10), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Bridge), (Sun, Holi)

              list(2, 3, 4, 5, 6, c(7,1,8,9), 10), # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Sun, Holi, Bridge)
              list(2, 3, 4, 5, 6, c(7,9), c(1,8), 10)) # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Bridge), (Sun, Holi)


             all_lags <- list(c(0),
                              c(2),
                              c(2,3),
                              c(2,3,4),
                              c(2,3,4,7),
                              c(2,3,4,7,14))
           }
    )
  } else {
    switch(model_complexity,
           { # low complexity = 3*5 models
             all_dummies <- list(
               list(c(2,3,4,5,6), c(7,1,8,9)), # (Monday to Friday), (Sat, Sun, Holi, Bridge)

               list(2, c(3,4,5), 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)

               list(2, 3, 4, 5, 6, c(7,1,8,9))) # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Sun, Holi, Bridge)

             all_lags <- list(c(0),
                              c(2),
                              c(2,3),
                              c(2,3,7),
                              c(2,3,4,7,14))
           },
           { # medium complexity = 6*7 models
             all_dummies <- list(
               list(c(2,3,4,5,6), c(7,1,8,9)), # (Monday to Friday), (Sat, Sun, Holi, Bridge)
               list(c(2,3,4,5,6), c(7,9), c(1,8)), # (Monday to Friday), (Sat, Bridge), (Sun, Holi)

               list(2, c(3,4,5), 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)
               list(2, c(3,4,5), 6, c(7,9), c(1,8)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Bridge), (Sun, Holi)


               list(2, 3, 4, 5, 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Sun, Holi, Bridge)
               list(2, 3, 4, 5, 6, c(7,9), c(1,8))) # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Bridge), (Sun, Holi)



             all_lags <- list(c(0),
                              c(2),
                              c(2,3),
                              c(2,7), c(2,3,7),
                              c(2,7,14), c(2,3,7,14))
           },
           { # high complexity = 6*10 models
             all_dummies <- list(
               list(c(2,3,4,5,6), c(7,1,8,9)), # (Monday to Friday), (Sat, Sun, Holi, Bridge)
               list(c(2,3,4,5,6), c(7,9), c(1,8)), # (Monday to Friday), (Sat, Bridge), (Sun, Holi)

               list(2, c(3,4,5), 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)
               list(2, c(3,4,5), 6, c(7,9), c(1,8)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Bridge), (Sun, Holi)

               list(2, 3, 4, 5, 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Sun, Holi, Bridge)
               list(2, 3, 4, 5, 6, c(7,9), c(1,8))) # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Bridge), (Sun, Holi)


             all_lags <- list(c(0),
                              c(2),
                              c(2,3),
                              c(2,3,4),
                              c(2,7), c(2,3,7), c(2,3,4,7),
                              c(2,7,14), c(2,3,7,14), c(2,3,4,7,14))
           },
           {# trivial complexity for debugging
             all_dummies <- list(
               list(c(2,3,4,5,6), c(7,1,8,9))) # (Monday to Friday), (Sat, Sun, Holi, Bridge)


             all_lags <- list(c(2))

           }

    )
  }


  all_dummies_grid <- rep(all_dummies, each = length(all_lags))

  all_lags_grid <- all_lags %>% rep(length(all_dummies))
  all_lags_grid <- dplyr::data_frame(my_lags = purrr::map(all_lags_grid, ~dplyr::data_frame(lag_day = .x, lag_q_hour = 0)))

  return(list(
    all_lags_grid = all_lags_grid,
    all_dummies_grid = all_dummies_grid
  )
  )

}

# When model_complexity = 2, then the most chosen models contain ALL LAGS, and the intercepts are
# 21 (2 times): Mon, (Tue, Wed, Thu), Fri, (Sat, bridge, Sun, Holi)
# 35 (81 times): Mon to Fri separate, (Sat, bridge, Sun, Holi) together
# 42 (13 times): Mon to Fri separate, Sat & bridge together, Sun & Holi together (full model!!!)

# BIC different!!!! Chooses again all lags, but not all dummies!

#' Create interactions between dummies and lags
#'
#' This function creates the character strings representing the formulae used for calculating different models with interactions.
#'
#' @return Character vector containing formula representations.
#' @export
get_interaction_formulas <- function(){

  # Real dummies ####
  name_dummy_real <-
    c("dummy_1_7", # sat sun
      "dummy_2_3_4_5_6", # mon to fri
      "dummy_8", # holi
      "dummy_9") # bridge

  formula_name_dummy_real <- paste0(names_dummies_real, collapse = " + ")

  # Interactions of lag 2 ####

  # dummies for interactions with lag 02
  name_dummy_for_interaction_02 <-
    c("dummy_2_3", # mon tue
      "dummy_4_5_6", # wed to fri
      "dummy_1_7")

  formula_name_interaction_lag_02_00 <- create_combos(name_dummy_for_interaction_02, "value_lag_02_00")


  # Interactions of lag 3 ####

  # dummies for interactions with lag 03
  name_dummy_for_interaction_03 <-
    c("dummy_2_5_6", # mon Thu fri
      "dummy_3_4", # tue wed
      "dummy_1_7") # sat sun

  formula_name_interaction_lag_03_00 <- create_combos(name_dummy_for_interaction_03, "value_lag_03_00")

  # Interactions of lag 7 ####

  # dummies for interactions with lag 07
  name_dummy_for_interaction_07 <-
    c("dummy_1_7", # sat sun
      "dummy_2_3_4_5_6") # mon to fri

  formula_name_interaction_lag_07_00 <- create_combos(name_dummy_for_interaction_07, "value_lag_07_00")

  gg <- expand.grid(formula_name_dummy_real,
              formula_name_interaction_lag_02_00,
              #formula_name_interaction_lag_03_00,
              formula_name_interaction_lag_07_00) %>%
    as_tibble() %>%
    mutate_all(as.character)

  ll <- lapply(1:nrow(gg), function(x) paste(gg[x,], collapse = " + ")) %>% unlist()

  ll <- paste("value ~ -1 + ", ll)

  return(ll)

}

#' Helper function needed for creating interaction formulas
#'
#' You should not see this. This function is not supposed to be exported
#'
#' @param name_dummy_interaction Character vector containing the names of the dummies used for creating interactions with on particular lag.
#' @param name_lag Character. One name of a lag to be interacted with
#'
#' @return Character vector of formulas with interaction terms
create_combos <- function(name_dummy_interaction,
                          name_lag){
  all_combos <- lapply(1:length(name_dummy_interaction),
                       function(x) combn(name_dummy_interaction, x, simplify = FALSE)) %>% unlist(recursive = FALSE)
  out <- lapply(1:length(all_combos),
                function(x) paste0(name_lag,":", all_combos[[x]], collapse = " + ")) %>% unlist()
  return(out)
}



