#' \code{overwrite_holiday_with_regular_day} takes a timeseries in dataframe
#' form and replaces the values on holidays and bridging days with the values of the week before
#'
#' @param df data frame of the form timestamp / value of the underlying
#'   timeseries containing "sufficient" history for an according weekly shift
#' @param list_of_holidays output given by get_holiday_from_postal_code
#' @param training_set df of the form timestamp / value of the timeframe to be
#'   "cleaned"
#'
#' @return data frame of the form timestamp / value with the same timestamps as
#'   parameter training_set
#'
#' @import dplyr
#' @importFrom lubridate minutes
#' @importFrom lubridate days
#' @importFrom lubridate floor_date
#' @importFrom lubridate as_datetime
#' @export
#'

overwrite_holiday_with_regular_day <- function(df,list_of_holidays, training_set) {

  this_many_days_of_training <- nrow(training_set)/96

  if(this_many_days_of_training != round(this_many_days_of_training)){
    stop("Only full days are allowed. Number of observations in training_set is not divisible by 96.")
  }

  day_of_first_observation <- training_set %>% head(1) %>% pull(timestamp) %>% as.Date()
  last_day_of_observation <- training_set %>% tail(1) %>% pull(timestamp) %>% as.Date() - days(1)
  relevant_holidays <- list_of_holidays[list_of_holidays >= day_of_first_observation & list_of_holidays <= last_day_of_observation]

  training_set <- rbind(list(day_of_first_observation,NaN), training_set)

  timestamp_days <- as.Date(training_set$timestamp)
  df_timestamp_days <- as.Date(df$timestamp)

  for (i in 1:length(relevant_holidays)){
    current_holiday <- relevant_holidays[i]
    day_of_previous_week <- current_holiday - days(7)
    while (day_of_previous_week %in% list_of_holidays){
      day_of_previous_week <- day_of_previous_week - days(7)
    }
    #shift by one quarter hour as day start at 00:15:00
    current_holiday_in_training_set <- timestamp_days == current_holiday
    current_holiday_in_training_set <- lag(current_holiday_in_training_set, default = FALSE)
    day_of_previous_week_in_df <- df_timestamp_days == day_of_previous_week

    if (any(day_of_previous_week_in_df)){
      day_of_previous_week_in_df <- lag(day_of_previous_week_in_df, default = FALSE)
      training_set[current_holiday_in_training_set,]$value <- df[day_of_previous_week_in_df,]$value
    }else{
      #warning. not enough history provided
    }


  }
  training_set <- training_set[2:nrow(training_set),]


  return(training_set)
}


