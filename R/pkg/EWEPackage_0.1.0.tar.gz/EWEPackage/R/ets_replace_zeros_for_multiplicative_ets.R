#' \code{replace_zeros_for_multiplicative_ets} takes a timeseries in dataframe
#' form and replaces zeros with the average of nonzero neighbours
#'
#' @param df data frame of the form timestamp / value of the underlying
#'
#' @return data frame of the form timestamp / value with the same timestamps as
#'   parameter df but no zeros
#'
#' @import dplyr
#' @importFrom zoo na.locf
#' @export
#'

replace_zeros_for_multiplicative_ets <- function(df) {
  
  val <- df$value
  
  if (any(is.na(val))){
    stop("NA encountered.")
  }
  
  # if there are zeros to the very end put NAs there
  copy_non_zeros_from_the_right <- na.locf(ifelse(val == 0, NA, val),na.rm = FALSE, fromLast = TRUE)
  #put zeros back where NA is (in the end)
  copy_non_zeros_from_the_right[is.na(copy_non_zeros_from_the_right)] = 0
  
  # if there are zeros in the beginning put NAs there
  copy_non_zeros_from_the_left <- na.locf(ifelse(val == 0, NA, val),na.rm = FALSE)
  #put zeros back where NA is (in the beginning)
  copy_non_zeros_from_the_left[is.na(copy_non_zeros_from_the_left)] = 0
  
  #average of nonzero neighbours
  df$value <- copy_non_zeros_from_the_left*0.5 +
    0.5*copy_non_zeros_from_the_right
  
  
  return(df)
}


