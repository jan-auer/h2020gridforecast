#' Generic ARX forecasting function
#'
#' \code{forecast_arx} takes a \link[dplyr]{data_frame} pertaining to a load time series (i.e. with column names timestamp and value).
#' It generates forecasts (also in the form of a data_frame with the same column names) for the forecasting period specified by \code{from} and \code{to}.
#' The function calls \link{create_arx_regression} which generates the regression inputs for each of the 96 time series pertaining to one particular 15 minutes interval.
#'
#'
#' @inheritParams create_arx_regression
#' @param from Datetime object, indicated the begin of the forecasting period.
#' @param to Datetime object, indicated the begin of the forecasting period.
#' @param verbose Boolean. Default set to FALSE.
#'   If TRUE, then a list containing not only the forecast time series (in data_frame form) is returned, but also the model specification is returned.
#'   If TRUE, then a list with the elements
#'   \describe{
#'     \item{regression_forecasts}{Dataframe containing the forecast from \code{from} to \code{to}.}
#'     \item{my_lags}{The corresponding input of the function with the same name.}
#'     \item{my_dummies_wday_hb}{The corresponding input of the function with the same name.}
#'   }
#' @param model_info Boolean. Default set to FALSE. If TRUE, then a list with two elements is returned
#' in-sample model statistics of the \link[stats]{lm} objects by \link[broom]{glance}
#'   \describe{
#'     \item{regression_forecasts}{Dataframe containing the forecast from \code{from} to \code{to}.}
#'     \item{regression_model_info}{Dataframe containing 96 rows and 2 list-columns with glance and tidy-lm objects.}
#'     \item{regression_model_glance}{Data_frame with one row, containing variables (mean_r_sq, n_regr, mean_aic, mean_bic), i.e. the mean of \code{R^2}, AIC, BIC, where the mean is taken across the 96 univariate models, and the number of regressors.}
#'     \item{regression_model_tidy}{Data_frame of dimension (number of regressors x 4) with columns (term, mean_p, mean_est, sd_est), i.e. the mean p-value, mean estimate and the standard deviation of this estimate (across the different 96 quarter hours of the day).}
#'   }
#'
#' @return Data_frame object containing the forecast from \code{from} to \code{to}.
#'   It has two columns: \code{timestamp} and \code{value}.
#' @importFrom purrr %>%
#' @export
#'
#' @examples
#' # b_df_load <- TransnetBW_base %>%
#' #   filter(meter_point_intern == "EWEU_1671959") %>%
#' #   select(ts_load) %>%
#' #   unnest()
#' # b_postal_code <- TransnetBW_base %>%
#' #   filter(meter_point_intern == "EWEU_1671959") %>%
#' #   select(postal_code) %>%
#' #   as.character()
#' # b_id_load <- TransnetBW_base %>%
#' #   filter(meter_point_intern == "EWEU_1671959") %>%
#' #   select(id_load)
#' # b_lags <- data_frame(lag_day = c(1, 2, 3, 4, 5, 6, 7, 14, 21), lag_q_hour = 0)
#' # forecast_arx(my_df_load = b_df_load,
#' #   from = lubridate::ymd_hms("2016-01-01 00:15:00"),
#' #   to = lubridate::ymd_hms("2017-01-01 00:00:00"),
#' #   my_postal_code = b_postal_code,
#' #   my_lags = b_lags)
#'
forecast_arx <- function(my_df_load,
                         from = NULL,
                         to = NULL,
                         my_lags = data_frame(lag_day = c(2, 3, 7, 14, 21), lag_q_hour = 0),
                         my_postal_code = NULL,
                         my_dummies_wday_hb = list(1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
                         verbose = FALSE,
                         model_info = FALSE){

  regression_inputs <- create_arx_regression(my_df_load = my_df_load,
                                             my_postal_code,
                                             my_lags = my_lags,
                                             my_dummies_wday_hb = my_dummies_wday_hb)


  # to_enquo <- dplyr::enquo(to)
  # from_enquo <- dplyr::enquo(from)
  # lubridate::ymd_hms("2016-01-01 00:15:00")
  # rlang::UQ(from_enquo)
  # !!from_enquo
  # from_enquo
  # from
  # from (if evaluated before)


  regression_model <- regression_inputs %>%
    dplyr::mutate(my_lm_model = purrr::map(univ_regr, ~ lm(value ~ . - 1, data = .x[.x$timestamp <  from,-1], na.action = na.exclude)))

  regression_model_info <- regression_model %>%
    dplyr::mutate(my_15min_id = 1:nrow(.)) %>%
    dplyr::mutate(my_tidy = purrr::map(my_lm_model, ~broom::tidy(.x))) %>%
    dplyr::mutate(my_glance = purrr::map(my_lm_model, ~broom::glance(.x))) %>%
    dplyr::select(-c(univ_regr, my_lm_model))

  summarise_glance <- regression_model_info %>%
    tidyr::unnest(my_glance) %>%
    dplyr::select(-my_tidy) %>%
    dplyr::summarise(mean_r_sq = mean(r.squared),
                     n_regr = mean(df),
                     mean_aic = mean(AIC),
                     mean_bic = mean(BIC))

  summarise_tidy <- regression_model_info %>%
    tidyr::unnest(my_tidy) %>%
    dplyr::group_by(term) %>%
    dplyr::summarise(mean_p = mean(p.value),
                     mean_est = mean(estimate),
                     sd_est = sd(estimate))

  regression_forecasts <- regression_model %>%
    dplyr::mutate(my_new_data = purrr::map(univ_regr, ~.x[.x$timestamp >= from,-c(1,2)]))  %>%
    dplyr::mutate(my_prediction_value = purrr::map2(my_lm_model, my_new_data, ~predict.lm(object = .x, newdata = .y))) %>%
    dplyr::mutate(my_prediction_timestamp =  purrr::map(univ_regr, ~.x[.x$timestamp >= from,1])) %>%
    dplyr::mutate(my_prediction =  purrr::map2(my_prediction_timestamp, my_prediction_value, ~tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y))) %>%
    tidyr::unnest(my_prediction) %>%
    dplyr::arrange(timestamp) %>%
    dplyr::filter(timestamp >= from & timestamp <= to)

  if (model_info){
    return(
      list(
        regression_forecasts = regression_forecasts,
        regression_model_info = regression_model_info,
        regression_model_glance = summarise_glance,
        regression_model_coeffs = summarise_tidy
      ))
  } else if (verbose){
    return(
      list(regression_forecasts = regression_forecasts,
           my_lags = my_lags,
           my_dummies_wday_hb = my_dummies_wday_hb)
    )
  } else {
    return(regression_forecasts)
  }

}







#' Generate input for univariate ARX
#'
#' \code{create_arx_regression} generates all variables necessary for univariate ARX modelling.
#' The regressors comprise
#' \itemize{
#'   \item lagged variables (as indicated in \code{my_lags})
#'   \item dummies for holidays (for which \code{postal_code} is needed)
#'   \item dummies for bridging days
#'   \item dummies for the days of the week
#' }
#'
#' @param my_df_load Data_frame object. Generic load time series with columns "timestamp" and "value"
#' @param my_postal_code Character or integer, indicating the postal code pertaining to a given load time series, needed to retrieve holidays for a given postal code.
#' @param my_lags Data_frame object. Columns are "lag_day" and "lag_q_hour".
#'   Default is set to daily lags at days \code{1, 2, 3, 7, 14, 21}.
#'   Can be set to NULL, in which case no lags are included.
#' @param my_dummies_wday_hb List object containing integers referring to weekdays and "special" days (1 to 7 = Sunday to Saturday, 8 = Holidays, 9 = Bridging days, 10 = School holidays).
#'   One list element corresponds to one dummy variable, i.e. if one wants different dummies for all weekdays, then the first seven list elements must contain the integers 1 to 7.
#'   The list can be of length 7 to 10, depending on whether one wants to treat holidays (8), bridging days (9), and school holidays (10).
#'   Including the integers 8 and 9 (representing holidays and bridging days) allows for flexible combining of different calendar effect dummies.
#'   Note: 1 corresponds to Sunday!
#'   Default is \code{list(1,2,3,4,5,6,7,8,9)}, i.e. every weekday has its own intercept and holidays and bridging days are treated separately.
#'   School holidays are not included as default because they do not lead to improved forecasting precision.
#' @param data_driven Boolean, default set to FALSE. If TRUE, the holidays are determined in a data-driven way with \link{get_holidays_from_timeseries}.
#' @param verbose Default set to FALSE.
#'   Used for testing, returns a list of the usual output and the "raw output", i.e. the response and regressor not separated in 96 tibbles containing time series with daily periodicities.
#' @param check_singularity Boolean, default set to FALSE. If TRUE, the function checks for singularity of any of the 96 obtained (univariate) regression matrices.
#'   A warning is issued and a new regressor matrix is created, consisting only of the weekday dummies.
#'
#' @return List column containing the time series and the regressors for each quarter hour separately.
#'   One list contains a data_frame with columns "timestamp", "value", "value_lag_DD_QQ" (see \link{get_lags}), "dummy_holidays", "dummy_bridging", "dummy_sun", ... "dummy_sat".
#' @importFrom purrr %>%
#' @export
#'
#' @examples
#' # b_df_load <- TransnetBW_base %>%
#' #   filter(meter_point_intern == "EWEU_1671959") %>%
#' #   select(ts_load) %>%
#' #   unnest()
#' # b_postal_code <- TransnetBW_base %>%
#' #   filter(meter_point_intern == "EWEU_1671959") %>%
#' #   select(postal_code) %>%
#' #   as.character()
#' # b_id_load <- TransnetBW_base %>%
#' #   filter(meter_point_intern == "EWEU_1671959") %>%
#' #   select(id_load)
#' # b_lags <- data_frame(lag_day = c(1, 2, 3, 4, 5, 6, 7, 14, 21), lag_q_hour = 0)
#' # create_arx_regression(my_df_load = b_df_load,
#' #   my_postal_code = b_postal_code, my_lags = b_lags)
#' # create_arx_regression(my_df_load = b_df_load,
#' #   my_postal_code = b_postal_code, my_lags = b_lags,
#' #   my_dummies_wday_hb = list(c(1,2,3), c(4,5,6,7)))
#' # create_arx_regression(my_df_load = b_df_load,
#' #   my_postal_code = b_postal_code, my_lags = b_lags,
#' #   my_dummies_wday_hb = list(c(1,7), c(2,6), c(3,4,5), c(8,9)))
#'
create_arx_regression <- function(my_df_load,
                                  my_postal_code,
                                  my_lags = data_frame(lag_day = c(2, 3, 7, 14, 21), lag_q_hour = 0),
                                  my_dummies_wday_hb = list(1, 2, 3, 4, 5, 6, 7, 8, 9),
                                  data_driven = FALSE,
                                  verbose = FALSE,
                                  check_singularity = FALSE){
  # 1) time-series + stamp
  # 2) left_join lags along time-stamp
  # 3) left_join dummies for holidays and bridging days
  # 4) left_join weekday dummies
  # 5) Slice it
  # 6) Univariate regression

  # Check inputs ############################
  # check load data_frame
  if (ncol(my_df_load) != 2){
    stop("my_df_load should have two columns.")
  }
  if (!"timestamp" %in% names(my_df_load)){
    stop("my_df_load should have a column named timestamp.")
  }
  if (!"value" %in% names(my_df_load)){
    stop("my_df_load should have a column named value.")
  }

  # Check lags
  if (!is.null(my_lags)){
    if ( ( ncol(my_lags) != 2 ) || !( "lag_day" %in% names(my_lags) ) || !( "lag_q_hour" %in% names(my_lags) ) ){
      stop("my_lags should have two columns with names lag_day and lag_q_hour")
    }
  }

  if ( !( is.list(my_dummies_wday_hb) ) ){
    stop("my_dummies_wday_hb should be a list, each element containing a vector of integers. See the help file of create_arx_regression.")
  }

  # # Check: Zeros in ts_load? If too many: Throw error ####
  # n_tmp <- my_df_load %>% nrow()
  # n_tmp <- floor(n_tmp*2/3)
  # perc_of_zeros <- my_df_load %>% slice(1:n_tmp) %>% mutate(is_zero = (value == 0)) %>% pull(is_zero) %>% mean()
  # if (perc_of_zeros > 0.1 || n_tmp < 100*96){
  #   stop("Too many zeros in load time series: Use naive model instead of auto-arx.\n")
  # }
  # rm(n_tmp)

  # Join: lags to resp_regr ####
  if (is.null(my_lags)){
    resp_regr <- my_df_load
  } else if (nrow(my_lags) == 1 && my_lags$lag_day == 0 && my_lags$lag_q_hour == 0){
    resp_regr <- my_df_load
  } else {
    regr_lags <- get_lags(my_df_load, my_lags)
    resp_regr <- my_df_load %>% left_join(regr_lags, by = "timestamp")
  }

  # Manipulate: Dummies: weekdays #####
  # First step, load weekday dummies from data folder and give it a different name
  dummy_wday_hb <- dummies_wday # "dummies_wday" from data folder of package
  names(dummy_wday_hb) <- c("timestamp",
                            "dummy_1",
                            "dummy_2",
                            "dummy_3",
                            "dummy_4",
                            "dummy_5",
                            "dummy_6",
                            "dummy_7")

  # Manipulate: Dummies (bank = _8, bridge = _9, school = _10) ####
  if (data_driven){
    if (9 %in% unlist(my_dummies_wday_hb) || 10 %in% unlist(my_dummies_wday_hb)){
      stop("It data_driven = TRUE, then bridging days (9) and school holidays (10) should not be dummies.")
    }

    if (8 %in% unlist(my_dummies_wday_hb)){
      dummy_8 <- create_holiday_dummy_datadriven(my_df_load, my_postal_code, forecast_start_date = lubridate::ymd("2016-01-01"), quarter_hour = TRUE)
      dummy_wday_hb <- dummy_wday_hb %>% left_join(dummy_8, by = "timestamp")
    }

  } else {
    if (8 %in% unlist(my_dummies_wday_hb) || 9 %in% unlist(my_dummies_wday_hb) || 10 %in% unlist(my_dummies_wday_hb)){
      # Get the state corresponding to the postal code: Necessary for retrieving holidays and bridging days
      my_postal_code <- my_postal_code %>% as.character()
      my_state <- mapping_table_postal_code_to_state %>%
        dplyr::filter( postal_code == rlang::UQ(my_postal_code)) %>%
        dplyr::select(state) %>%
        as.character()

      if (length(my_state) == 0){
        stop("There is no state corresponding to the given postal code.", call. = FALSE)
      }

      dummies_listcol_tmp <- dummies_listcol %>%
        dplyr::filter(state == rlang::UQ(my_state))

        dummy_8 <- dummies_listcol_tmp %>%
          tidyr::unnest(dummy_holidays) %>%
          dplyr::rename(dummy_holidays = value) %>%
          dplyr::select(-state)

        dummy_9 <- dummies_listcol_tmp %>%
          tidyr::unnest(dummy_bridgingdays) %>%
          dplyr::rename(dummy_bridging = value) %>%
          dplyr::select(-state)

        dummy_10 <- dummies_listcol_tmp %>%
          tidyr::unnest(dummy_holidays_school) %>%
          dplyr::rename(dummy_holidays_school = value) %>%
          dplyr::select(-state)

        dummy_wday_hb <- dummy_wday_hb %>%
          left_join(dummy_8, by = "timestamp") %>%
          left_join(dummy_9, by = "timestamp") %>%
          left_join(dummy_10, by = "timestamp")

        rm(dummies_listcol_tmp)

    }
  }

  # Join: Dummies to resp_regr ######
  if (length(my_dummies_wday_hb) > 0 ){
    my_dummies_wday_hb_names <- lapply(my_dummies_wday_hb, function(x) paste0("dummy_", paste0(x, collapse = "_")))

    dummy_wday_hb_no_idx <- lapply(my_dummies_wday_hb, function(x) dummy_wday_hb %>% select(1 + x) %>% transmute(name_tmp = Reduce("+", .)) ) %>%
      dplyr::bind_cols() %>%
      dplyr::mutate_all(as.logical) %>%
      stats::setNames(my_dummies_wday_hb_names)

    dummy_wday_hb <- dplyr::bind_cols(dummy_wday_hb %>%
                                        dplyr::select(timestamp), dummy_wday_hb_no_idx)


    resp_regr <- resp_regr %>% left_join(dummy_wday_hb %>% dplyr::mutate_if(is.logical, as.integer), by = "timestamp")

  }

  # Manipulate: Slice into 96 data_frames pertaining to 15 min intervals ####
  # 3 years with 365 days and 96 data points per day = 105,120
  n_obs <- nrow(resp_regr)

  # OLD: Generate a list-column. Each row contains a vector of logicals of length 105,120 which has TRUE as value for one particular 15 min period
  # slice_to_univariate <- diag(rep(TRUE, 96)) %>%
  #   dplyr::as_data_frame() %>%
  #   dplyr::mutate(univariate_ts = map(., ~rep(.x, n_ts/96))) %>% # map each column of the data_frame to a row -> works only if number of rows equals number of columns of data_frame
  #   dplyr::select(univariate_ts)

  # NEW: Generate a list-column with indices pertaining to a particular quarter hour. 96 lists with #days elements
  out <- dplyr::tibble( n_steps = 1:96) %>%
    dplyr::mutate(idx = purrr::map(n_steps, ~seq(.x, n_obs, by = 96L) )) %>%
    dplyr::mutate(univ_regr = purrr::map(idx, ~resp_regr[.x,])) %>%
    dplyr::select(univ_regr)

  # Check: Singularity of design-matrix ####
  if (check_singularity){
    flag_singularity <- out %>%
      dplyr::select(univ_regr) %>%
      dplyr::mutate(rank_mat = purrr::map_int(univ_regr, ~ .x %>% select(-timestamp) %>% filter_all(all_vars(!is.na(.))) %>% base::as.matrix() %>% Matrix::rankMatrix()),
                    col_mat = purrr::map_int(univ_regr, ~ .x %>% select(-timestamp) %>% ncol()),
                    singular_mat = (col_mat > rank_mat)) %>%
      dplyr::summarise(any_singularity = any(singular_mat)) %>%
      dplyr::pull(any_singularity)

    if (flag_singularity){
      warning("Regressor matrix singular. Instead, only weekday dummies are used (and school holidays if included).")
      out <- out %>%
        select(univ_regr) %>%
        transmute(univ_regr_new = purrr::map(univ_regr, ~ .x %>% select(timestamp,
                                                                        value,
                                                                        contains("_1"),
                                                                        contains("_2"),
                                                                        contains("_3"),
                                                                        contains("_4"),
                                                                        contains("_5"),
                                                                        contains("_6"),
                                                                        contains("_7")))) %>%
        rename(univ_regr = univ_regr_new)
    }
  }

  # Use each list-column element of "slice_to_univariate" to select the correct 15 min intervall for each day
  if (!verbose){
    return(out %>% dplyr::select(univ_regr))
  } else {
    return(
      list(
        out = out %>% dplyr::select(univ_regr),
        out_raw = resp_regr)
    )

  }

}

#' Generate data frame with all lags
#'
#' \code{get_lags} generates a data_frame with all lags given in \code{which_lags}
#'
#' @param my_df Data_frame object with columns \code{timestamp} and \code{value} containing a load time series.
#' @param which_lags Data_frame with variables \code{lag_day} and \code{lag_q_hour}.
#'   It indicates which lags should be generated from the given load time series contained in \code{my_df}
#'
#' @return Data_frame object with column \code{timestamp} (identical to the one from \code{my_df}) and columns containing the desired lags.
#'   The columns are named with the convention "value_lag_DD_QQ" where "DD" and "QQ" are replace by the desired day lag and quarter-hour lag respectively.
#'   Note that both "DD" and "QQ" have always two digits.
#' @importFrom purrr %>%
#' @export
#'
#' @examples
#' # df_load <- TransnetBW_base %>% filter(meter_point_intern == "EWEU_1671959") %>% select(ts_load) %>% unnest()
#' # lags_arx <- data_frame(lag_day = c(1, 2, 3, 4, 5, 6, 7, 14, 21), lag_q_hour = 0)
#' # get_lags(my_df = df_load, which_lags = lags_arx)
get_lags <- function(my_df, which_lags){

  my_lags <- which_lags %>%
    dplyr::mutate(name_lag = paste0("value_lag_",
                                    ifelse(nchar(lag_day) == 1, paste0("0", lag_day), lag_day),
                                    "_",
                                    ifelse(nchar(lag_q_hour) == 1, paste0("0", lag_q_hour), lag_q_hour))) %>%
    dplyr::mutate(value_lag = purrr::map2(lag_day, lag_q_hour, ~dplyr::lag(my_df$value, n = .x*96 + .y))) %>%
    dplyr::mutate(timestamp = list(my_df$timestamp))

  return(my_lags %>% dplyr::select(timestamp, name_lag, value_lag) %>% tidyr::unnest() %>% tidyr::spread(key = name_lag, value = value_lag))
}

