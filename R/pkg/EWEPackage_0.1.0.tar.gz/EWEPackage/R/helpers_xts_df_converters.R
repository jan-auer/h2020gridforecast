#' Convert data_frame to xts
#'
#' \code{df_to_xts} converts \code{df} to an \link[xts]{xts}. A data frame with
#' names 'timestamp' and 'value' is converted to an xts object.
#'
#' @param df Data frame with column names 'timestamp' and 'value' of a time
#'   series.
#'
#' @importFrom xts xts
#' @export
#'
df_to_xts <- function(df) {
  xts(df$value, order.by = df$timestamp)
}

#' Convert xts to data_frame
#'
#' \code{xts_to_df} converts an \link[xts]{xts} to a \code{df}. A xts object is
#' converted to a data frame with names 'timestamp' and 'value'.
#'
#' @param ts A xts object.
#'
#' @import dplyr
#' @importFrom zoo index
#' @importFrom zoo coredata
#' @export

xts_to_df <- function(ts) {
  data_frame(timestamp = index(ts), value = ts %>% coredata %>% as.vector)
}

