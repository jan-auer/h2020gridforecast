#' Connect to postgres database without timeout
#'
#' \code{src_postgres_without_timeout} connect to postgres database without
#' timeout
#'
#' Set up a postgres connection like in
#'
#' @param dbname dbname
#' @param host host
#' @param port port
#' @param user user
#' @param password password
#' @param ... other params
#'
#' @import dplyr
#' @importFrom DBI dbConnect
#' @importFrom RPostgreSQL PostgreSQL
#' @importFrom dbplyr src_dbi
#'
#' @return database connection.

src_postgres_without_timeout <-
  function(dbname = NULL,
           host = NULL,
           port = NULL,
           user = NULL,
           password = NULL,
           ...) {
    dplyr::check_dbplyr()
    dplyr:::check_pkg("RPostgreSQL", "connect to PostgreSQL")

    user <-
      user %>% ifelse(is.null(.), if (dplyr:::in_travis())
        "postgres"
        else
          "", .)

    con <- dbConnect(
      PostgreSQL(),
      host = host %>% ifelse(is.null(.), "", .),
      dbname = dbname %>% ifelse(is.null(.), "", .),
      user = user,
      password = password %>% ifelse(is.null(.), "", .),
      port = port %>% ifelse(is.null(.), "", .),
      ...
    )

    src_dbi(con, auto_disconnect = FALSE)
  }


#' Kill all psql connections
#'
#' \code{kill_all_psql_connections} kills all open postgres connections in the
#' current session
#'
#' Set up a postgres connection like in
#'
#' @importFrom DBI dbDriver
#' @importFrom DBI dbListConnections
#' @importFrom DBI dbDisconnect
#'
#' @export

kill_all_psql_connections <- function() {
  drv <- dbDriver("PostgreSQL")
  list_of_connections <- dbListConnections(drv)
  lapply(list_of_connections, dbDisconnect)

}


#' Connect to EWE Database
#'
#' \code{connect_to_ewe_db} connects to EWE database and returns the
#' corresponding connection.
#'
#' A database connection to the EWE database is returned. During connection the
#' timezone of the current session is set to UTC.
#'
#' @param backend which backend to use. defaults to 'localhost'
#'
#' @return database connection.
#'
#' @importFrom DBI dbSendQuery
#' @importFrom DBI dbFetch
#'
#' @export


connect_to_ewe_db <- function(backend = 'localhost') {
  # set username and database name
  credentials <- list(
    localhost = list(user = 'postgres',
                     dbname = 'ewe'),
    aws = list(
      dbname = 'ewe',
      host = 'ewe.cpxoghxsskuo.eu-central-1.rds.amazonaws.com',
      port = 5432,
      user = 'mantigma',
      password = 'fu5I1y8F0AqQaaP46osryteLSQNRxcgo'
    )
  )

  message('Connecting to database... ')

  # Connect to local PostgreSQL via dplyr
  ewe_db <-
    do.call(src_postgres_without_timeout, credentials[[backend]])

  message('Connection to database established.')

  # set timezone of current session
  dbSendQuery(ewe_db$con, "SET SESSION TIME ZONE 'UTC'")

  # get timezone of current session
  timezone_result <-
    dbFetch(dbSendQuery(ewe_db$con, "SHOW TIME ZONE"))

  # check if timezone was set correctly
  if (timezone_result$TimeZone != 'UTC')
    stop('WRONG TIMEZONE!')

  # return database connection
  return(ewe_db)

}

#' Pull timeseries data from EWE database
#'
#' \code{get_timeseries_from_db} connects to EWE database
#' and returns certain timeseries in memory.
#'
#' First of all a connection to the EWE database is established.
#' The user has to specify which timeseries data he or she wants to
#' pull from the database via the \code{name_of_timeseries} parameter.
#' This at the moment is eigther be 'ts_load' or 'ts_fc_ewe'.
#' The user can further specify the corresponding
#'  meter points to be pulled from the database.
#' this can be done using the \code{name_of_controlarea}
#' or \code{vector_of_meter_point_normed}.
#' When using the former it has to be one of the following:
#'
#' \enumerate{
#'  \item TransnetBW
#'  \item Amprion
#'  \item TenneT extern
#'  \item TenneT intern (not to be used due to the size of the data)
#'  \item 50 Hertz
#' }
#'
#' When using \code{vector_of_meter_point_normed} just
#'  specify the normed meter points to be pulled.
#'
#' @param name_of_controlarea name of controlarea to pull.
#' @param vector_of_meter_point_normed vector of meter points to pull.
#' @param name_of_timeseries name of timeseries to pull.
#' @param with_status flag to fetch status as well.
#' @param from start date (inclusive).
#' @param to end date (incluseive).
#'
#' @return data frame in the standard format
#' with the corresponding timeseries data.
#'
#' @import dplyr
#' @importFrom tidyr nest_
#' @importFrom lubridate with_tz
#' @importFrom lubridate ymd_hms
#' @importFrom DBI dbDisconnect
#'
#' @export

get_timeseries_from_db <- function(name_of_controlarea = NULL,
                                   vector_of_meter_point_normed = NULL,
                                   name_of_timeseries,
                                   with_status = FALSE,
                                   from = ymd_hms('2014-01-01 00:15:00'),
                                   to   = ymd_hms('2017-01-01 00:00:00')) {
  if (is.null(name_of_controlarea) &
      is.null(vector_of_meter_point_normed)) {
    stop('At least name_of_controlarea or vector_of_meter_point_normed must be supplied.')
  }

  if (!is.null(name_of_controlarea)) {
    if (!name_of_controlarea %in% c('TransnetBW',
                                    'Amprion',
                                    'TenneT extern',
                                    'TenneT intern',
                                    '50 Hertz')) {
      stop(
        'name_of_controlarea must be one of TransnetBW, Amprion, TenneT extern, TenneT intern or 50 Hertz.'
      )
    }

    if (!is.null(vector_of_meter_point_normed)) {
      stop(
        'Not both name_of_controlarea and vector_of_meter_point_normed can be supplied.'
      )
    }

  }

  # connect to database
  ewe_db <- connect_to_ewe_db()

  # if the controlarea name is supplied we get the corresponding meter points
  if (!is.null(name_of_controlarea)) {
    # get id of controlarea
    id_of_controlarea <-
      tbl(ewe_db, 'controlarea') %>%
      filter(name == name_of_controlarea) %>%
      as_data_frame() %>%
      pull(id)

    # get meter points associated to this control area
    vector_of_meter_point_normed <-
      tbl(ewe_db, 'meter_point') %>%
      filter(controlarea_id == id_of_controlarea) %>%
      as_data_frame() %>%
      pull(meter_point_normed)

  }

  # get ids of meter points to pull from data base
  id_of_meter_points_to_pull <-
    tbl(ewe_db, 'meter_point') %>%
    filter(meter_point_normed %in% vector_of_meter_point_normed) %>%
    as_data_frame() %>%
    pull(id)

  # get ids of time series type to pull from data base
  id_of_timeseries_type_to_pull <-
    tbl(ewe_db, 'timeseries_type') %>%
    filter(name == name_of_timeseries) %>%
    as_data_frame() %>%
    pull(id)

  # pull the corresponding measurements from database and nest
  measurement <-
    tbl(ewe_db$con, 'measurement') %>%
    filter(timeseries_type_id == id_of_timeseries_type_to_pull) %>%
    filter(meter_point_id %in% id_of_meter_points_to_pull) %>%
    select(meter_point_id, timestamp_of_measurement, value, status) %>%
    as_data_frame() %>%
    rename(timestamp = timestamp_of_measurement) %>%
    mutate(timestamp = with_tz(timestamp, tzone = 'UTC')) %>%
    filter(timestamp >= from, timestamp <= to) %>%
    group_by(meter_point_id) %>%
    arrange(timestamp) %>%
    group_by(meter_point_id)

  if (!with_status) {
    measurement <- measurement %>%
      select(-status)
  }

  measurement <- measurement  %>%
    nest_(key_col = name_of_timeseries)

  # prepare final output
  output <- tbl(ewe_db, 'meter_point') %>%
    filter(meter_point_normed %in% vector_of_meter_point_normed) %>%
    as_data_frame() %>%
    rename(meter_point_id = id) %>%
    left_join(measurement, by = 'meter_point_id') %>%
    select(-c(meter_point_id, controlarea_id))


  # disconnect form database
  dbDisconnect(ewe_db$con)

  return(output)

}

#' Pull weather data from EWE database
#'
#' Fetch all weather variables available for a certain
#' controlarea(s) / climatezone(s) / meterpoint(s)
#'
#' In order to fetch all weather data available the user can specify eigther
#'
#' \enumerate{
#'
#'  \item \code{vector_of_names_of_controlarea}
#'  \item \code{vector_of_ids_of_climatezone}
#'  \item \code{vector_of_meter_point_normed}
#'
#' }
#'
#' where all are vectors of the correspoing variables. NB: variables are not
#' necessarily shared over all climate zones.
#'
#' @param vector_of_names_of_controlarea vector of names of controlarea
#' @param vector_of_ids_of_climatezone vector of ids of climate zone
#' @param vector_of_meter_point_normed vector of normed meterpoints
#'
#' @return data frame of all weather data. The resulting data frame is not tidy.
#'
#' @import dplyr
#' @importFrom DBI dbSendQuery
#' @importFrom DBI dbFetch
#' @importFrom DBI dbDisconnect
#'
#' @export

get_weather_data_from_db <-
  function(vector_of_names_of_controlarea = NULL,
           vector_of_ids_of_climatezone = NULL,
           vector_of_meter_point_normed = NULL) {
  if((as.integer(!is.null(vector_of_names_of_controlarea)) +
      as.integer(!is.null(vector_of_ids_of_climatezone)) +
      as.integer(!is.null(vector_of_meter_point_normed))) != 1){
      stop('Incorrect number of input arguments. Only one can and must be supplied.')
    }

    # connecting to database
    ewe_db <- connect_to_ewe_db()

    if (!is.null(vector_of_names_of_controlarea)) {
      controlarea <- tbl(ewe_db$con, 'controlarea') %>% as_data_frame()

      controlarea_ids <-
        controlarea %>% filter(name %in% vector_of_names_of_controlarea) %>% pull(id)

      query <- paste0(
        'SELECT
        wq.climate_zone_id climate_zone,
        wq.variable variable,
        wm.timestamp_of_measurement "timestamp",
        wm.value "value",
        wm.status status
        FROM
        weather_quantity wq
        JOIN weather_measurement wm
        ON wm.zrd_id = wq.zrd_id
        WHERE
        wq.climate_zone_id in (
        SELECT
        DISTINCT(plz.climate_zone_id)
        FROM
        meter_point mp
        JOIN plz
        ON plz.plz = mp.postal_code
        WHERE mp.controlarea_id in (',
        paste(controlarea_ids, collapse = ','),
        '))'
      )

    }

    if (!is.null(vector_of_ids_of_climatezone)) {
      query <- paste0(
        '
        select
        wq.climate_zone_id climate_zone,
        wq.variable variable,
        wm.timestamp_of_measurement "timestamp",
        wm.value "value",
        wm.status status
        from
        weather_quantity wq
        join weather_measurement wm
        on wm.zrd_id = wq.zrd_id
        where wq.climate_zone_id in (',
        paste(vector_of_ids_of_climatezone, collapse = ','),
        ')'
      )

    }

    if (!is.null(vector_of_meter_point_normed)) {
      query <- paste0(
        '
        SELECT
        wq.climate_zone_id climate_zone,
        wq.variable variable,
        wm.timestamp_of_measurement "timestamp",
        wm.value "value",
        wm.status status
        FROM meter_point mp
        JOIN plz
        ON plz.plz=mp.postal_code
        JOIN weather_quantity wq
        ON wq.climate_zone_id = plz.climate_zone_id
        JOIN weather_measurement wm
        ON wm.zrd_id = wq.zrd_id
        WHERE mp.meter_point_normed IN (\'',
        paste(vector_of_meter_point_normed, collapse = '\',\''),
        '\')'
      )

    }

    message('Fetching weatherdata from database... ')
    # prepare output
    output <-
      dbSendQuery(ewe_db$con, query) %>% dbFetch() %>% as_data_frame()
    message('DONE')

    # disconnect form database
    dbDisconnect(ewe_db$con)

    return(output)

  }

#' Write forecast to database
#'
#' Write forecast to database.
#'
#' When writing to the data base please supply a nested data frame with two
#' columns. The first one being 'meter_point_normed'. The second one being
#' 'forecast'.
#'
#' @param df nested data frame
#' @param timeseries_type_name short name of forecast type
#' @param description discription of the forecast
#' @param perform_sanity_check flag to perform check which forecasts are already
#'   in the DB. FUTURE TODO After everything is done set to TRUE
#'
#' @import dplyr
#' @importFrom tidyr unnest
#' @importFrom DBI dbWriteTable
#' @importFrom DBI dbDisconnect
#'
#' @export

write_forecast_to_db <- function(df = NULL, timeseries_type_name = NULL, description = NULL, perform_sanity_check = FALSE){

  if (is.null(df)) stop('df is missing.')
  if (ncol(df) != 2) stop('wrong number of columns in df.')
  if ( !('meter_point_normed' %in% names(df)) ) stop('meter_point_normed not in df.')
  if ( !('forecast' %in% names(df)) ) stop('forecast not in df.')
  if (is.null(timeseries_type_name)) stop('timeseries_type_name is missing.')

  # connect to database
  ewe_db <- connect_to_ewe_db()

  # pull meter point and timeseries type information
  meter_point_df     <- tbl(ewe_db, 'meter_point') %>% as_data_frame()

  meter_point_normed_ids <-
    meter_point_df %>%
    filter(meter_point_normed %in% df$meter_point_normed) %>%
    as_data_frame() %>%
    select(id, meter_point_normed)

  timeseries_type_df <- tbl(ewe_db, 'timeseries_type') %>% as_data_frame()


  if (timeseries_type_name %in% timeseries_type_df$name){
    # if there are already meter points with this kind of timeseries type they wont be written into the df

    old_timeseries_type_id <- timeseries_type_df %>% filter(name == timeseries_type_name) %>% pull(id)

    message('The timeseries type ', timeseries_type_name, ' is already in the database with ID ', old_timeseries_type_id, '.')
    message('The argument description will be ignored since the timeseries is already in the database')

    description <- timeseries_type_df %>% filter(name == timeseries_type_name) %>% pull(description)

    message('Using the following description: ', description, '.')

    if (perform_sanity_check){

      message('Only inserting forecasts corresponding to meterpoints which don\'t have a timeseries with type ',
              timeseries_type_name, '.')


      meter_point_ids_alread_in_db <- tbl(ewe_db$con, 'measurement') %>%
        filter(meter_point_id %in% meter_point_normed_ids$id) %>%
        filter(timeseries_type_id == old_timeseries_type_id) %>%
        as_data_frame()

      if(nrow(meter_point_ids_alread_in_db) > 0){
        meter_point_ids_alread_in_db <- meter_point_ids_alread_in_db %>%
          select(meter_point_id) %>%
          as_data_frame() %>%
          pull(meter_point_id) %>%
          unique()
      } else {
        meter_point_ids_alread_in_db <- c()
      }

      message('There are ', length(meter_point_ids_alread_in_db), ' of the given ', nrow(df), ' meter points which already have this timeseries type.')
      message('These won\'t be written into the database.')

      meter_point_normed_already_in_db <-
        meter_point_normed_ids %>%
        filter(id %in% meter_point_ids_alread_in_db) %>%
        pull(meter_point_normed)

      # remove those who are already in the data base
      df <- df %>%
        filter(! meter_point_normed %in% meter_point_normed_already_in_db)

      if( nrow(df) == 0){
        message('There are no meter points to write into the database.')
        dbDisconnect(ewe_db$con)
        return(invisible(NULL))
      }

      df_to_write <- df %>%
        left_join(meter_point_df, by = "meter_point_normed") %>%
        rename(meter_point_id = id) %>%
        mutate(timeseries_type_id = old_timeseries_type_id) %>%
        select(meter_point_id, timeseries_type_id, forecast) %>%
        unnest() %>%
        rename(timestamp_of_measurement = timestamp)

    } else {

      message('Writing to DB without sanity checks.')

      df_to_write <- df %>%
        left_join(meter_point_df, by = "meter_point_normed") %>%
        rename(meter_point_id = id) %>%
        mutate(timeseries_type_id = old_timeseries_type_id) %>%
        select(meter_point_id, timeseries_type_id, forecast) %>%
        unnest() %>%
        rename(timestamp_of_measurement = timestamp)

    }


  } else {

    if (is.null(description)) {
      dbDisconnect(ewe_db$con)
      stop('There is no decription!')
    }

    message('There is no timeseries type ', timeseries_type_name, ' in the database yet.')
    message('All forecasts corresponding to the supplied meterpoints will be written into the database.')

    new_timeseries_type_id <- max(timeseries_type_df$id) + 1

    message('Forecasts with timeseries type ', timeseries_type_name,
            ' will be written into the database with ID ', new_timeseries_type_id, '.')

    timeseries_type_to_append <- data_frame(id          = new_timeseries_type_id,
                                            name        = timeseries_type_name,
                                            description = description)

    dbWriteTable(conn = ewe_db$con, name = 'timeseries_type', value = timeseries_type_to_append, append = TRUE, row.names = FALSE)

    message('Inserting all data into the database.')

    df_to_write <- df %>%
      left_join(meter_point_df, by = "meter_point_normed") %>%
      rename(meter_point_id = id) %>%
      mutate(timeseries_type_id = new_timeseries_type_id) %>%
      select(meter_point_id, timeseries_type_id, forecast) %>%
      unnest() %>%
      rename(timestamp_of_measurement = timestamp)

  }

  dbWriteBigTable(conn = ewe_db$con, name = 'measurement', value = df_to_write, append = TRUE, row.names = FALSE)

  dbDisconnect(ewe_db$con)

}


#' Get masterdata data frame from database
#'
#' Get masterdata data frame from database
#'
#' Given the name of the control area the masterdata table is pulled.
#'
#' \enumerate{
#'  \item TransnetBW
#'  \item Amprion
#'  \item TenneT extern
#'  \item TenneT intern
#'  \item 50 Hertz
#' }
#'
#' @param name_of_controlarea name of controlarea to pull.
#'
#' @return data frame in the masterdata data frame.
#'
#' @import dplyr
#' @importFrom DBI dbDisconnect
#'
#' @export

get_masterdata_df_from_df <- function(name_of_controlarea) {
  if (!name_of_controlarea %in% c('TransnetBW',
                                  'Amprion',
                                  'TenneT extern',
                                  'TenneT intern',
                                  '50 Hertz')) {
    stop(
      'name_of_controlarea must be one of TransnetBW, Amprion, TenneT extern, TenneT intern or 50 Hertz.'
    )
  }

  # connect to database
  ewe_db <- connect_to_ewe_db()

  # get id of controlarea
  id_of_controlarea <-
    tbl(ewe_db, 'controlarea') %>%
    filter(name == name_of_controlarea) %>%
    as_data_frame() %>%
    pull(id)

  masterdata_df <-
    tbl(ewe_db, 'meter_point') %>%
    as_data_frame() %>%
    filter(controlarea_id == id_of_controlarea) %>%
    select(
      id_customer,
      meter_point_intern,
      meter_point_normed,
      city,
      postal_code,
      id_load,
      id_fc_ewe
    )

  # disconnect form database
  dbDisconnect(ewe_db$con)

  return(masterdata_df)

}

#' Get base data frame from database
#'
#' Get base data frame or a set of meter points from the database.
#'
#' The user can either specify a \code{name_of_controlarea} or a vector of characters \code{vector_of_meter_point_normed}, containing normed meter points.
#' In the former case, all normed meter points for the chosen control area are retrieved.
#' It is not possible to specify both arguments.
#' Note that multiple \code{vector_of_timeseries_type_name} can be indicated.
#' If \code{name_of_controlarea} is used, it has to be one of (as a character string):
#'
#' \enumerate{
#'  \item TransnetBW
#'  \item Amprion
#'  \item TenneT extern
#'  \item TenneT intern (not to be used due to the size of the data)
#'  \item 50 Hertz
#' }
#'
#' If \code{vector_of_meter_point_normed} is used, the normed meter points to be pulled have to be specified.
#'
#' @param name_of_controlarea name of control area to pull.
#' @param vector_of_meter_point_normed vector of meter points to pull.
#' @param vector_of_timeseries_type_name vector of timeseries types to pull.
#'
#' @return data frame in the base data frame format.
#'
#' @import dplyr
#' @importFrom DBI dbDisconnect
#'
#' @export

get_base_df_from_db <- function(name_of_controlarea = NULL,
                                vector_of_meter_point_normed = NULL,
                                vector_of_timeseries_type_name = c('ts_load', 'ts_fc_ewe')) {
  # sanity checks of input data #############################################
  if (is.null(name_of_controlarea) &
      is.null(vector_of_meter_point_normed)) {
    stop('At least name_of_controlarea or vector_of_meter_point_normed must be supplied.')
  }

  if (!is.null(name_of_controlarea)) {
    if (!name_of_controlarea %in% c('TransnetBW',
                                    'Amprion',
                                    'TenneT extern',
                                    'TenneT intern',
                                    '50 Hertz')) {
      stop(
        'name_of_controlarea must be one of TransnetBW, Amprion, TenneT extern, TenneT intern or 50 Hertz.'
      )
    }

    if (name_of_controlarea == 'TenneT intern') {
      stop(
        'TenneT intern has to much data! Please specify vector_of_meter_point_normed instead.'
      )
    }

    if (!is.null(vector_of_meter_point_normed)) {
      stop(
        'Not both name_of_controlarea and vector_of_meter_point_normed can be supplied.'
      )
    }

  }

  # connect to database ####
  ewe_db <- connect_to_ewe_db()

  # Control area: if the controlarea name is supplied we get the corresponding meter points ####
  if (!is.null(name_of_controlarea)) {
    # get id of controlarea
    id_of_controlarea <-
      tbl(ewe_db, 'controlarea') %>%
      filter(name == name_of_controlarea) %>%
      as_data_frame() %>%
      pull(id)

    # get meter points associated to this control area
    vector_of_meter_point_normed <-
      tbl(ewe_db, 'meter_point') %>%
      filter(controlarea_id == id_of_controlarea) %>%
      as_data_frame() %>%
      pull(meter_point_normed)

  }

  # prepare meter_point_information ####
  meter_point_information <- tbl(ewe_db, 'meter_point') %>%
    filter(meter_point_normed %in% vector_of_meter_point_normed) %>%
    as_data_frame() %>%
    select(-c(id, controlarea_id))


  # get timeseries data ####
  # initialize output
  output <- meter_point_information

  for (current_timeseries_type_name in vector_of_timeseries_type_name) {
    message('Currently fetching measurements of ',
            current_timeseries_type_name,
            '.')

    current_timeseries_type_df <-
      get_timeseries_from_db(
        vector_of_meter_point_normed = vector_of_meter_point_normed,
        name_of_timeseries = current_timeseries_type_name,
        with_status = FALSE
      )

    output <- output %>%
      left_join(
        current_timeseries_type_df,
        by = c(
          "id_customer",
          "meter_point_intern",
          "meter_point_normed",
          "city",
          "postal_code",
          "id_load",
          "id_fc_ewe"
        )
      )

    message('Fetching measurements of ',
            current_timeseries_type_name,
            ' done.')

  }

  # disconnect form database
  dbDisconnect(ewe_db$con)

  return(output)

}
