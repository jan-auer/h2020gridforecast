#' DBI extension for big data frames.
#'
#' \code{dbWriteBigTable} writes big dataframes into a database.
#' Just like \link{dbWriteTable}
#'
#' @examples
#' \dontrun{
#' dbWriteBigTable(ewe_db$con, 'dbtable', dataframe_to_write)
#' }
#'
#' @param conn A DBI connection.
#' @param name A character string specifying the unquoted DBMS table name.
#' @param value A \link{data_frame}.
#' @param gigabyte_maximum Maximum number of GB allowed in each split.
#'   Defaults to half a gigabyte.
#' @param ... Other parameters passed on to methods.
#'
#' @import dplyr
#' @importFrom DBI dbWriteTable
#'
#' @export

dbWriteBigTable <- function(conn, name, value, gigabyte_maximum = 0.5, ...){

  # set maximum batch size
  gigabyte_byte_converter <- 1e+09
  maximum_batch_size <- gigabyte_maximum * gigabyte_byte_converter

  # calculate number of splits
  number_of_splits <- ceiling(object.size(value)[1]/maximum_batch_size)

  message(paste('Splitting data frame into', number_of_splits, 'chunck(s)'))

  # get row indizes
  row_indizes <- 1:nrow(value)

  # split row indizes in number_of_splits equal parts
  if(number_of_splits > 1){
    splits <- split(row_indizes, cut(row_indizes, number_of_splits, labels = FALSE))
  } else {
    splits <- list(row_indizes)
  }

  for (i in 1:length(splits)){
    message(paste('Currently writing split number', i))
    dbWriteTable(conn = conn, name = name, value = value[splits[[i]],], ... = ...)
  }

}



#' Detatch all packages
#'
#' \code{detachAllPackages} detaches all currently loaded R packages except the
#' base packages.
#'
#' @examples
#'
#' \dontrun{
#' detachAllPackages()
#' }
#' @export

detachAllPackages <- function() {

  basic.packages <- paste0("package:", sessionInfo()$basePkgs)

  package.list <- search()[ifelse(unlist(gregexpr("package:",search()))==1,TRUE,FALSE)]

  package.list <- setdiff(package.list,basic.packages)

  if (length(package.list)>0)  for (package in package.list) detach(package, character.only=TRUE)

}
