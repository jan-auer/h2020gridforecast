#' Safe version of quantile regression
#'
#' There are problems with singular design matrices when using \link[quantreg]{rq}.
#' Here, error-handling is used to switch to using \link{lm} in case of problems with the robust alternative.
#'
#' There is no value in this function at the moment. (30 Aug 2017)
#' It was thought to solve a problem with a singular design matrix the quantile regression couldn't handle.
#' This problem, however, does not only appear in the quantile regression.
#' The current solution is using \link{try} in \link{forecast_auto_arx}. (30 Aug 2017)
#'
#' This function is not used anymore.
#'
#' @param df Data_frame of regression inputs (usually, value, dummies, lags)
#'
#' @return Object of class rq or lm.
#' @export
#'
safe_rq <- function(df = NULL){
  tryCatch({
    qq <- quantreg::rq(formula = value ~ . - 1,
                 data = df,
                 method = "fn",
                 singular.ok = FALSE,
                 na.action = na.exclude)
    return(qq)
  },
  condition = {qq <- stats::lm(value ~ . - 1,
                               data = df,
                               singular.ok = FALSE,
                               na.action = na.exclude)
  return(qq)} )

}
