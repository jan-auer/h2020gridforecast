#' Calculate naive forecast without holiday effects
#'
#' \code{naive_seasonal} returns the naive seasonal forecast for the timeseries
#' in \code{df}.
#'
#' The naive seasonal forecast is calculated by shifting the timeseries exactly
#' one week. The missing values are filled with \code{NA}. The returned data
#' frame column names are 'timestamp' and 'value'. For more details see
#' \href{https://confluence.mantigma.com/display/EWE/Naive+Models}{Confluence}.
#'
#' @param df Data frame with variable names 'timestamp' and 'value' of the
#'   observed time series.
#' @param from starting date of the forecast period. Default results in the
#'   whole observation time. This includes NAs
#' @param to end date of the forecast period. Default results in the whole
#'   observation time. This includes NAs
#' @return Data frame with names 'timestamp' and 'value' of the naive forecast.
#'
#' @import dplyr
#' @importFrom lubridate ymd_hms
#' @export

naive_seasonal <- function(df, from = NULL, to = NULL){

  # Check inputs
  if(ncol(df) != 2) stop('df should have two columns')
  if(! 'timestamp' %in% names(df)) stop('df doesn\'t have column timestamp')
  if(! 'value' %in% names(df)) stop('df doesn\'t have column value')

  # get from
  if(is.null(from)){
    from <- min(df$timestamp)
  } else {
    from <- as_datetime(from)
  }

  # get to
  if(is.null(to)){
    to <- max(df$timestamp)
  } else {
    to <- as_datetime(to)
  }

  # compute forecast by lagging exactly one week
  df_naive <- df
  df_naive$value <- lag(df$value, n = 96*7)

  # filter forecast period
  df_naive %>% filter(timestamp >= from, timestamp <= to)

}


#' Calculate naive forecast with holiday effects
#'
#' \code{naive_seasonal_holiday} returns the naive seasonal forecast for the
#' timeseries in \code{df} accounting for holiday effects.
#'
#' The naive seasonal forecast is calculated by shifting the timeseries
#' according to the holiday adjusted dates with respect to the postal code.
#' Accounting for holidays is done in the following way:
#' \itemize{
#'   \item Saturdays and Sundays are shifted exactly 7 days,
#'   \item Holidays are shifted to the last Sunday,
#'   \item Businessdays are shifted to the last businessday which is the same
#'   weekday.
#' }
#' The missing values are filled with \code{NA}. The returned data frame column
#' names are 'timestamp' and 'value'. For more details see
#' \href{https://confluence.mantigma.com/display/EWE/Naive+Models}{Confluence}.
#'
#' @param df Data frame with variable names 'timestamp' and 'value' of the
#'   observed time series.
#' @param postal_code_or_state character or integer of the postal code or the state. If
#'   'all' then all german holidays are used.
#' @param from starting date of the forecast period. Default results in the
#'   whole observation time. This includes NAs.
#' @param to end date of the forecast period. Default results in the whole
#'   observation time. This includes NAs.
#' @return Data frame with names 'timestamp' and 'value' of the naive forecast.
#'
#' @import dplyr
#' @importFrom lubridate ymd_hms
#' @importFrom lubridate as_datetime
#' @export

naive_seasonal_holiday <- function(df, postal_code_or_state, from = NULL, to = NULL){

  # Check inputs
  if(ncol(df) != 2) stop('df should have two columns')
  if(! 'timestamp' %in% names(df)) stop('df doesn\'t have column timestamp')
  if(! 'value' %in% names(df)) stop('df doesn\'t have column value')

  # get from
  if(is.null(from)){
    from <- min(df$timestamp)
  } else {
    from <- as_datetime(from)
  }

  # get to
  if(is.null(to)){
    to <- max(df$timestamp)
  } else {
    to <- as_datetime(to)
  }

  # compute forecast by lagging one week with "holiday correction" as specified in the description

  df_naive_seasonal <-
    get_shifted_timestamps_using_holiday_data(postal_code_or_state) %>%
    left_join(df %>% rename(shifted_timestamp = timestamp), by = 'shifted_timestamp') %>%
    select(original_timestamp, value) %>%
    rename(timestamp = original_timestamp) %>%
    right_join(df %>% select(timestamp), by = 'timestamp')

  # filter forecast period
  df_naive_seasonal %>% filter(timestamp >= from, timestamp <= to)

}


#' Calculate naive forecast with holiday effects
#'
#' \code{naive_seasonal_holiday} returns the naive seasonal forecast for the
#' timeseries in \code{df} accounting for holiday effects.
#'
#' The naive seasonal forecast is calculated by shifting the timeseries
#' according to the holiday adjusted dates with respect to the postal code or
#' specific holidays if they are given.
#' Accounting for holidays is done in the following way:
#' \itemize{
#'   \item Saturdays and Sundays are shifted exactly 7 days,
#'   \item Holidays are shifted to the last Sunday,
#'   \item Businessdays are shifted to the last businessday which is the same
#'   weekday.
#' }
#' The missing values are filled with \code{NA}. The returned data frame column
#' names are 'timestamp' and 'value'. For more details see
#' \href{https://confluence.mantigma.com/display/EWE/Naive+Models}{Confluence}.
#'
#' @param df Data frame with variable names 'timestamp' and 'value' of the
#'   observed time series.
#' @param postal_code_or_state character or integer of the postal code or the state. If
#'   'all' then all german holidays are used.
#' @param holidays a vector of days to treat as holidays. Can only be given if
#'   \code{postal_code_or_state} is not given.
#' @param generate_holidays_data_driven generate the holidays in a data driven manner.
#'   See \link{get_holidays_from_timeseries}.
#' @param from starting date of the forecast period. This is crucial not to train the
#'   holidays on the forecast period.
#' @param to end date of the forecast period.
#' @param verbose verbose.
#' @param return_all parameter to return the whole observation and forecast period.
#'
#' @return Data frame with names 'timestamp' and 'value' of the naive forecast.
#'
#' @import dplyr
#' @importFrom lubridate ymd_hms
#' @export

naive_seasonal_holiday_version_2 <- function(df, postal_code_or_state = NULL, holidays = NULL, generate_holidays_data_driven = FALSE, from = NULL, to = NULL, verbose = FALSE, return_all = FALSE){

  if(verbose) message(postal_code_or_state)

  # check conbination of postal_code_or_state
  if(is.null(postal_code_or_state) & is.null(holidays)) stop('At least postal_code_or_state or holidays must be given.')
  if(!is.null(postal_code_or_state) & !is.null(holidays)) stop('Not both postal_code_or_state and holidays can be given at the same time.')

  # Check further inputs
  if(ncol(df) != 2) stop('df should have two columns')
  if(! 'timestamp' %in% names(df)) stop('df doesn\'t have column timestamp')
  if(! 'value' %in% names(df)) stop('df doesn\'t have column value')

  # get holidays if only postal_code_or_state is given
  if(is.null(holidays)){
    holidays <- get_holidays_from_postal_code(postal_code_or_state = postal_code_or_state)
  }

  # get from
  if(is.null(from)){
    from <- min(df$timestamp)
  } else {
    from <- as_datetime(from)
  }

  # get to
  if(is.null(to)){
    to <- max(df$timestamp)
  } else {
    to <- as_datetime(to)
  }

  # generate holidays from the timeseries itself
  if(generate_holidays_data_driven){
    holidays <- get_holidays_from_timeseries(df = df, postal_code_or_state = postal_code_or_state, forecast_start_date = from)
  }

  # compute forecast by lagging one week with "holiday correction" as specified in the description

  df_naive_seasonal <-
    get_shifted_datetimes_from_holidays(original_days_to_shift = seq(ymd(substr(min(df$timestamp), 1, 10)), ymd(substr(max(df$timestamp), 1, 10)), by = 'day'),
                                        holidays = holidays) %>%
    left_join(df %>% rename(shifted_timestamp = timestamp), by = 'shifted_timestamp') %>%
    select(original_timestamp, value) %>%
    rename(timestamp = original_timestamp) %>%
    right_join(df %>% select(timestamp), by = 'timestamp')


  if(return_all){
    return(df_naive_seasonal)
  } else {
    df_naive_seasonal %>% filter(timestamp >= from, timestamp <= to)
  }

}



#' Calculate naive forecast with holiday effects averaged over two weeks
#'
#' \code{naive_seasonal_holiday_2_week_average} returns the naive seasonal
#' forecast for the timeseries in \code{df} accounting for holiday effects.
#'
#' The naive seasonal forecast is calculated by shifting the timeseries
#' according to the holiday adjusted dates with respect to the postal code.
#' Accounting for holidays is done in the following way:
#' \itemize{
#'   \item Saturdays and Sundays are shifted exactly 7 days,
#'   \item Holidays are shifted to the last Sunday,
#'   \item Businessdays are shifted to the last businessday which is the same weekday.
#'   }
#' And then averaged with another shift like above.
#' The missing values are filled with \code{NA}. The returned data frame column
#' names are 'timestamp' and 'value'. For more details see
#' \href{https://confluence.mantigma.com/display/EWE/Naive+Models}{Confluence}.
#'
#' @param df Data frame with variable names 'timestamp' and 'value' of the
#'   observed time series.
#' @param postal_code_or_state character or integer of the postal code or the state. If
#'   'all' then all german holidays are used.
#' @param from starting date of the forecast period. Default results in the
#'   whole observation time. This includes NAs.
#' @param to end date of the forecast period. Default results in the whole
#'   observation time. This includes NAs.
#' @return Data frame with names 'timestamp' and 'value' of the naive forecast.
#'
#' @import dplyr
#' @importFrom lubridate ymd_hms
#' @export

naive_seasonal_holiday_2_week_average <- function(df, postal_code_or_state, from = NULL, to = NULL){

  # Check inputs
  if(ncol(df) != 2) stop('df should have two columns')
  if(! 'timestamp' %in% names(df)) stop('df doesn\'t have column timestamp')
  if(! 'value' %in% names(df)) stop('df doesn\'t have column value')

  # get from
  if(is.null(from)){
    from <- min(df$timestamp)
  } else {
    from <- as_datetime(from)
  }

  # get to
  if(is.null(to)){
    to <- max(df$timestamp)
  } else {
    to <- as_datetime(to)
  }

  # compute forecast by lagging "holiday adjusted" one week and two weeks and taking the mean

  df_naive_seasonal_1_week <-
    get_shifted_timestamps_using_holiday_data(postal_code_or_state) %>%
    left_join(df %>% rename(shifted_timestamp = timestamp), by = 'shifted_timestamp') %>%
    select(original_timestamp, value) %>%
    rename(timestamp = original_timestamp) %>%
    right_join(df %>% select(timestamp), by = 'timestamp')

  df_naive_seasonal_2_week <-
    get_shifted_timestamps_using_holiday_data(postal_code_or_state) %>%
    left_join(df_naive_seasonal_1_week %>% rename(shifted_timestamp = timestamp), by = 'shifted_timestamp') %>%
    select(original_timestamp, value) %>%
    rename(timestamp = original_timestamp) %>%
    right_join(df %>% select(timestamp), by = 'timestamp')

  # filter forecast period
  df_naive_seasonal <-
    data_frame(timestamp = df_naive_seasonal_1_week$timestamp,
               value = (df_naive_seasonal_1_week$value + df_naive_seasonal_2_week$value)/2) %>%
    filter(timestamp >= from, timestamp <= to)

  return(df_naive_seasonal)

}

#' Calculate naive forecast with holiday and bridging day effects
#'
#' \code{naive_seasonal_holiday_with_bridging_days} returns the naive seasonal forecast for the
#' timeseries in \code{df} accounting for holiday and bridging day effects.
#'
#' The naive seasonal forecast is calculated by shifting the timeseries
#' according to the holiday and bridging day adjusted dates with respect to the postal code.
#' Accounting for holidays and bridging days is done in the following way:
#' \itemize{
#'   \item Saturdays and Sundays are shifted exactly 7 days,
#'   \item Holidays and Bridging days are shifted to the last Sunday,
#'   \item Businessdays are shifted to the last businessday which is the same
#'   weekday which is neither a holiday nor bridging day.
#' }
#' The missing values are filled with \code{NA}. The returned data frame column
#' names are 'timestamp' and 'value'. For more details see
#' \href{https://confluence.mantigma.com/display/EWE/Naive+Models}{Confluence}.
#'
#' @param df Data frame with variable names 'timestamp' and 'value' of the
#'   observed time series.
#' @param postal_code_or_state character or integer of the postal code or the state. If
#'   'all' then all german holidays are used.
#' @param from starting date of the forecast period. Default results in the
#'   whole observation time. This includes NAs.
#' @param to end date of the forecast period. Default results in the whole
#'   observation time. This includes NAs.
#' @return Data frame with names 'timestamp' and 'value' of the naive forecast.
#'
#' @import dplyr
#' @importFrom lubridate ymd_hms
#' @export

naive_seasonal_holiday_with_bridging_days <- function(df, postal_code_or_state, from = NULL, to = NULL){

  # Check inputs
  if(ncol(df) != 2) stop('df should have two columns')
  if(! 'timestamp' %in% names(df)) stop('df doesn\'t have column timestamp')
  if(! 'value' %in% names(df)) stop('df doesn\'t have column value')

  # get from
  if(is.null(from)){
    from <- min(df$timestamp)
  } else {
    from <- as_datetime(from)
  }

  # get to
  if(is.null(to)){
    to <- max(df$timestamp)
  } else {
    to <- as_datetime(to)
  }

  # compute forecast by lagging one week with "holiday correction" as specified in the description

  df_naive_seasonal <-
    get_shifted_timestamps_using_holiday_and_bridging_day_data(postal_code_or_state) %>%
    left_join(df %>% rename(shifted_timestamp = timestamp), by = 'shifted_timestamp') %>%
    select(original_timestamp, value) %>%
    rename(timestamp = original_timestamp) %>%
    right_join(df %>% select(timestamp), by = 'timestamp')

  # filter forecast period
  df_naive_seasonal %>% filter(timestamp >= from, timestamp <= to)

}


#' Calculate naive yearly forecast without holiday effects
#'
#' \code{naive_yearly} returns the naive seasonal forecast for the timeseries
#' in \code{df}.
#'
#' The naive seasonal forecast is calculated by shifting the timeseries exactly
#' one year. The missing values are filled with \code{NA}. The returned data
#' frame column names are 'timestamp' and 'value'. For more details see
#' \href{https://confluence.mantigma.com/display/EWE/Naive+Models}{Confluence}.
#'
#' @param df Data frame with variable names 'timestamp' and 'value' of the
#'   observed time series.
#' @param from starting date of the forecast period. Default results in the
#'   whole observation time. This includes NAs
#' @param to end date of the forecast period. Default results in the whole
#'   observation time. This includes NAs
#' @return Data frame with names 'timestamp' and 'value' of the naive forecast.
#'
#' @import dplyr
#' @importFrom lubridate ymd_hms
#' @export

naive_yearly <- function(df, from = NULL, to = NULL){

  # Check inputs
  if(ncol(df) != 2) stop('df should have two columns')
  if(! 'timestamp' %in% names(df)) stop('df doesn\'t have column timestamp')
  if(! 'value' %in% names(df)) stop('df doesn\'t have column value')

  # get from
  if(is.null(from)){
    from <- min(df$timestamp)
  } else {
    from <- as_datetime(from)
  }

  # get to
  if(is.null(to)){
    to <- max(df$timestamp)
  } else {
    to <- as_datetime(to)
  }

  # compute forecast by lagging exactly one year
  df_naive <- df
  df_naive$value <- lag(df$value, n = 96*7*52)

  # filter forecast period
  df_naive %>% filter(timestamp >= from, timestamp <= to)

}

#' Calculate convex combination of arbitrary many forecasts.
#'
#' \code{convex_combine_forecasts} returns the convex combinatoin of all
#' forecasts given.
#'
#' Given arbitraryly many forecasts in \code{...} the convex combination
#' using the wights in \code{lambda}. If \code{lambda} is not given. The
#' average of the forecasts are calculated.
#'
#' @param forecast_list Arbitrary number of forecasts in a list
#' @param lambda weights of convex combination. Defaults to \code{NULL}.
#'   If \code{NULL} the average is caluclated.
#' @return Data frame with names 'timestamp' and 'value'.
#'
#' @import dplyr
#' @export

convex_combine_forecasts <- function(forecast_list, lambda = NULL){

  # get all data frames passed in
  number_of_forecasts <- length(forecast_list)

  # check if they have the same length
  if(length(unique(unlist(map(forecast_list, nrow)))) > 1){
    stop('Some forecasts have different lengths.')
  }

  # if no convex combination is supplied use the average of all forecasts to be returned
  # otherwise check if it is a true convex combination
  if(is.null(lambda)){
    lambda <- rep(1/number_of_forecasts, number_of_forecasts)
  } else {
    if(length(lambda) != number_of_forecasts){
      stop('incorrect number of weights!')
    }
    if(any(lambda < 0) | sum(lambda) != 1){
      stop('lambda does not define the coefficients of a convex combination.')
    }
  }

  # initialize value
  value <- 0*forecast_list[[1]]$value

  # convex combine all
  for (i in 1:number_of_forecasts){
    value <- value + lambda[i]*forecast_list[[i]]$value
  }

  # return convex combination
  return(data_frame(timestamp = forecast_list[[1]]$timestamp, value = value))

}

