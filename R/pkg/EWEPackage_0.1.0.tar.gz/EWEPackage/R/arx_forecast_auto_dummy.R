#' Automated Dummy model
#'
#' For every 15 min period, choose the best model according to AIC (training data = 2 years) and use it to forecast.
#'
#' @inheritParams create_arx_regression
#' @param from Start of forecasting period
#' @param to End of forecasting period
#'
#' @return something
#' @export
#'
forecast_auto_dummy <- function(my_df_load, my_postal_code, from, to){

  my_df_load <- dplyr::enquo(my_df_load)
  my_postal_code <- dplyr::enquo(my_postal_code)
  from <- dplyr::enquo(from)
  to <- dplyr::enquo(to)

  all_dummies_grid <- list(
    list(c(2,3,4,5,6), c(7,1,8,9)), # (Monday to Friday), (Sat, Sun, Holi, Bridge)
    list(c(2,3,4,5,6), c(7,9), c(1,8)), # (Monday to Friday), (Sat, Bridge), (Sun, Holi)
    list(c(2,3,4,5,6), 7, 9, c(1,8)), # (Monday to Friday), (Sat), (Bridge), (Sun, Holi)

    list(2, c(3,4,5), 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Sun, Holi, Bridge)
    list(2, c(3,4,5), 6, c(7,9), c(1,8)), # (Monday), (Friday), (Tuesday to Thursday), (Sat, Bridge), (Sun, Holi)
    list(2, c(3,4,5), 6, 7, 9, c(1,8)), # (Monday), (Friday), (Tuesday to Thursday), (Sat), (Bridge), (Sun, Holi)

    list(2, 3, 4, 5, 6, c(7,1,8,9)), # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Sun, Holi, Bridge)
    list(2, 3, 4, 5, 6, c(7,9), c(1,8)), # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat, Bridge), (Sun, Holi)
    list(2, 3, 4, 5, 6, 7, 9, c(1,8)) # (Monday), (Friday), (Tuesday), (Wednesday), (Thursday), (Sat), (Bridge), (Sun, Holi)
  )



  # lags inputs for pmap (choose best aic)

  all_lags_grid <- all_lags <-  NULL
  n_models <- length(all_dummies_grid)
  out <- dplyr::tibble(model_id = 1:n_models)
  out1 <- out %>%
    dplyr::mutate(data_all = purrr::map(all_dummies_grid, ~create_arx_regression(my_df_load = rlang::UQ(my_df_load),
                                                                                 my_postal_code = rlang::UQ(my_postal_code),
                                                                                 my_dummies_wday_hb = .x,
                                                                                 my_lags = NULL)))
  out2 <- out1 %>%
    tidyr::unnest(data_all) %>%
    dplyr::group_by(model_id) %>%
    dplyr::mutate(q_hour_id = 1:n()) %>%
    dplyr::ungroup()

  out3 <- out2 %>%
    dplyr::mutate(data_train = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < rlang::UQ(from)))) %>%
    dplyr::mutate(data_test = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp >= rlang::UQ(from))))

  out4 <- out3 %>%
    dplyr::select(-univ_regr) %>%
    dplyr::mutate(lm_model = purrr::map(data_train, ~ stats::lm(value ~ . - 1, data = .x %>% dplyr::select(-timestamp), na.action = na.exclude))) %>%
    dplyr::select(-data_train)

  out5 <- out4 %>%
    dplyr::mutate(my_glance = purrr::map(lm_model, ~broom::glance(.x))) %>%
    tidyr::unnest(my_glance) %>%
    dplyr::group_by(q_hour_id)

  out6 <- out5 %>%
    dplyr::slice(which.min(AIC)) %>%
    dplyr::ungroup() %>%
    dplyr::select(lm_model, data_test)

  out7 <- out6 %>%
    dplyr::mutate(my_prediction_value = purrr::map2(lm_model, data_test, ~stats::predict.lm(object = .x, newdata = .y %>% select(-timestamp, -value)))) %>%
    dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test, ~.x %>% dplyr::select(timestamp))) %>%
    dplyr::mutate(my_prediction =  purrr::map2(my_prediction_timestamp, my_prediction_value, ~tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)))

  out8 <- out7 %>%
    tidyr::unnest(my_prediction) %>%
    dplyr::arrange(timestamp) %>%
    dplyr::filter(timestamp >= rlang::UQ(from) & timestamp <= rlang::UQ(to))

  return(out8)
}
