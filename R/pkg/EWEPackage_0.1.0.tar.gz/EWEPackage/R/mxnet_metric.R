#' Custom evaluation metric using mxnet for load forecasting.
#'
#' @importFrom mxnet mx.metric.custom
#' @export

mx.metric.mae.ewe <- mx.metric.custom(
  "mae",
  function(label, pred) {
    res <- 96*mean(abs(label-pred))
    return(res)
  }
)
