#' Creates daily or quarter-hourly dummies for holidays
#'
#' \code{create_holiday_dummy} creates a dataframe with columns "timestamp" and "value".
#' Used for generating dummies in ARX regression which are saved in the \code{data} directory of the package.
#'
#' @inheritParams get_holidays_from_postal_code
#' @param date_start Date object. Default set to \code{"2014-01-01"}. Indicates date from which onwards the dummy is created.
#' @param date_end Date object. Default set to \code{"2018-12-31"}. Indicates date until which the dummy is created.
#' @param quarter_hour Boolean value, indicating whether the periodicity of the timestamp is quarter-hourly or daily. Default is set to "FALSE", i.e. by default the periodicity is daily.
#'
#' @return Data_frame with columns "timestamp" and "value".
#' @importFrom purrr %>%
#' @export
#'
#' @examples
#' create_holiday_dummy("Sachsen")
create_holiday_dummy <- function(postal_code_or_state,
                                 date_start = lubridate::ymd("2014-01-01"),
                                 date_end = lubridate::ymd("2018-12-31"),
                                 quarter_hour = FALSE){

  # my_holidays contains a vector of dates
  my_holidays <- get_holidays_from_postal_code(postal_code_or_state)

  my_dummies_daily <- dplyr::data_frame(timestamp = seq(from = date_start, to = date_end, by = "1 day")) %>%
    dplyr::mutate(value = purrr::map_dbl(timestamp, ~is_holiday(.x, holidays = my_holidays) && lubridate::wday(.x) != 1 && lubridate::wday(.x) != 7))

  if (quarter_hour){

    # CODE REVIEW (September 2017): Mapping table does something slightly different at midnight!!!
    # Additional note (14 Mar 2018): The "..._day_to_datetime" tibble is correct without manipulation (sometimes "timestamp - lubridate::minutes(15)" is used for adjusting for "..._datetime_to_day" at midnight.
    my_dummies_quarterly <- my_dummies_daily %>%
      dplyr::rename(day = timestamp) %>%
      dplyr::left_join(mapping_table_day_to_datetime, by = "day") %>%
      dplyr::select(datetime, value) %>%
      dplyr::rename(timestamp = datetime) %>%
      tidyr::unnest() %>%
      dplyr::select(timestamp, value)

    return(my_dummies_quarterly)

  } else{
    return(my_dummies_daily)
  }

}


#' Creates daily or quarter-hourly dummies for holidays in a data-driven way
#'
#' \code{create_holiday_dummy_datadriven} creates a dataframe with columns "timestamp" and "value".
#' Used for generating dummies in ARX regression which are saved in the \code{data} directory of the package.
#'
#' @inheritParams get_holidays_from_postal_code
#' @param df_load Load data frame of usual form from which the data-driven holidays are created
#' @param forecast_start_date Parameter needed as input for \link{get_holidays_from_timeseries}
#' @param quarter_hour Boolean value, indicating whether the periodicity of the timestamp is quarter-hourly or daily. Default is set to "FALSE", i.e. by default the periodicity is daily.
#'
#' @return Data_frame with columns "timestamp" and "value".
#' @importFrom purrr %>%
#' @export
#'

create_holiday_dummy_datadriven <- function(df_load, postal_code_or_state,
                                 forecast_start_date = lubridate::ymd("2016-01-01") ,
                                 quarter_hour = FALSE){

  # my_holidays contains a vector of dates
  my_holidays <- get_holidays_from_timeseries(df_load, postal_code_or_state, forecast_start_date)

  my_dummies_daily <- dplyr::data_frame(timestamp = seq(from = lubridate::ymd("2014-01-01"), to = lubridate::ymd("2018-01-01"), by = "1 day")) %>%
    dplyr::mutate(value = purrr::map_dbl(timestamp, ~is_holiday(.x, holidays = my_holidays) && lubridate::wday(.x) != 1 && lubridate::wday(.x) != 7))

  if (quarter_hour){

    # CODE REVIEW (Sep 2017): Mapping table does something slightly different at midnight!!!
    # Additional note (14 Mar 2018): The "..._day_to_datetime" tibble is correct without manipulation (sometimes "timestamp - lubridate::minutes(15)" is used for adjusting for "..._datetime_to_day" at midnight.
    my_dummies_quarterly <- my_dummies_daily %>%
      dplyr::rename(day = timestamp) %>%
      dplyr::left_join(mapping_table_day_to_datetime, by = "day") %>%
      dplyr::select(datetime, value) %>%
      dplyr::rename(timestamp = datetime) %>%
      tidyr::unnest() %>%
      dplyr::select(timestamp, value)


    return(my_dummies_quarterly)

  } else{
    return(my_dummies_daily)
  }

}


#
#' Creates daily or quarter-hourly dummies for bridging days
#'
#' \code{create_bridgingday_dummy} creates a dataframe with columns "timestamp" and "value".
#'
#' @inheritParams get_holidays_from_postal_code
#' @param date_start Date object. Default set to \code{"2014-01-01"}. Indicates date from which onwards the dummy is created.
#' @param date_end Date object. Default set to \code{"2018-01-01"}. Indicates date until which the dummy is created.
#' @param quarter_hour Boolean value, indicating whether the periodicity of the timestamp is quarter-hourly or daily. Default is set to "FALSE", i.e. by default the periodicity is daily.
#' @param holidays_given Vector of days containing holidays. Default set to NULL, in which case the holidays are calculated by using the postal code.
#' @return Data_frame with columns "timestamp" and "value".
#' @importFrom purrr %>%
#' @export
#'
#' @examples
#' #create_bridgingday_dummy("Sachsen")
create_bridgingday_dummy <- function(postal_code_or_state,
                                 date_start = lubridate::ymd("2014-01-01"),
                                 date_end = lubridate::ymd("2018-01-01"),
                                 holidays_given = NULL,
                                 quarter_hour = FALSE){

  # my_holidays contains a vector of dates
  # Bridging days are created from holidays
  if (is.null(holidays_given)){
    my_holidays <- get_holidays_from_postal_code(postal_code_or_state)
  } else {
    my_holidays <- holidays_given
  }

  my_dummies_daily <- dplyr::data_frame(timestamp = seq(from = date_start, to = date_end, by = "1 day")) %>%
    dplyr::mutate(value = purrr::map_lgl(timestamp, ~is_bridging_day(.x, holidays = my_holidays)))

  if (quarter_hour){

    # CODE REVIEW: Mapping table does something slightly different at midnight!!!
    # Not a big deal, but be aware because of consistency...
    my_dummies_quarterly <- my_dummies_daily %>%
      dplyr::rename(day = timestamp) %>%
      dplyr::left_join(mapping_table_day_to_datetime, by = "day") %>%
      dplyr::select(datetime, value) %>%
      dplyr::rename(timestamp = datetime) %>%
      tidyr::unnest() %>%
      dplyr::select(timestamp, value)


    # idx_hour <- map_chr(0:23, ~ifelse(str_length(.x) < 2, paste0("0", .x), paste(.x)))
    # idx_15min <- c("00", "15", "30", "45")
    # grid <- expand.grid(minute = idx_15min, hour = idx_hour, stringsAsFactors = FALSE) %>% select(hour, minute) %>% t() %>% as_data_frame()
    # time_of_day <- map_chr(grid, function(x) paste0(x[1], ":", x[2], ":00"))
    # names(time_of_day) <- NULL
    #
    # my_dummies_quarterly <- my_dummies_daily %>%
    #   mutate(timestamp_hms = map(timestamp, ~add_hms(.x))) %>%
    #   mutate(value_hms = map(value, ~rep(1,96)*.x)) %>%
    #   select(-timestamp, -value) %>%
    #   unnest() %>%
    #   rename(timestamp = timestamp_hms, value = value_hms)

    return(my_dummies_quarterly)

  } else{
    return(my_dummies_daily)
  }
}

#' Add 15 minutes times to a daily date stamp
#'
#' \code{add_hms} adds "00:00:00", "00:15:00", ... , "23:45:00" to a daily timestamp.
#'
#' @param date_ymd One-dimensional date object in format "ymd"
#'
#' @return 96-dimensional date object in format "ymd". Converted wit \link[lubridate]{ymd_hms}
#' @export

add_hms <- function(date_ymd){
  idx_hour <- purrr::map_chr(0:23, ~ifelse(stringr::str_length(.x) < 2, paste0("0", .x), paste(.x)))
  idx_15min <- c("00", "15", "30", "45")
  grid <- expand.grid(minute = idx_15min, hour = idx_hour, stringsAsFactors = FALSE) %>%
    dplyr::select(hour, minute) %>%
    base::t() %>%
    dplyr::as_data_frame()
  time_of_day <- purrr::map_chr(grid, function(x) paste0(x[1], ":", x[2], ":00"))
  names(time_of_day) <- NULL

  new_date <- purrr::map_chr(time_of_day, ~paste(date_ymd, .x))
  return(lubridate::ymd_hms(new_date))
}
