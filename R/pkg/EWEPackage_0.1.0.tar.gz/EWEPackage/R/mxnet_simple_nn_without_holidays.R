#' input generation of simple nn without any holiday effects.
#'
#' DID NOT PERFORM!! USE \link{simple_nn_with_holiday_forecast}
#'
#' @param df timeseries data frame.
#' @param from forecast starting date.
#' @param weeks_to_use weeks to use as lagged input.
#' @param days_to_use days to use as lagged input
#'
#' @import dplyr
#' @importFrom lubridate ymd
#' @importFrom lubridate ymd_hms
#' @importFrom lubridate minutes
#' @importFrom lubridate as_datetime
#' @importFrom lubridate ceiling_date
#'
#' @export

simple_nn_without_holiday_input_generation <- function(df, from, weeks_to_use = 1, days_to_use = NULL){

  # get first full day
  first_date_in_df <- min(df$timestamp)
  first_full_day <- first_date_in_df %>% ceiling_date(unit = 'day') %>% paste('00:15:00') %>% ymd_hms
  df <- df %>% filter(timestamp >= first_full_day)

  from <- as_datetime(from)

  # get forecast interval
  fc_interval <- df %>% filter(timestamp >= from) %>% pull(timestamp)

  # trimm forecast starting date to the actual day
  from <- ymd(substr(from, 1, 10))

  # get dates of timeseries
  dates <-
    df %>%
    mutate(timestamp = timestamp - minutes(15)) %>%
    select(timestamp) %>%
    left_join(mapping_table_datetime_to_day, by = 'timestamp') %>%
    pull(timestamp_new) %>%
    unique()

  # get indizes of observation and forecast periods
  observation_idx <- which(dates < from)
  forecast_idx <- which(dates >= from)

  # get lagged values of corresponding weeks
  for (i in seq_along(weeks_to_use)){

    last_week <- matrix(lag(df$value, 96*7*weeks_to_use[i]), ncol = 96, byrow = TRUE)
    if (i == 1){
      all_data_x <- last_week
    } else {
      all_data_x <- cbind(all_data_x, last_week)
    }

  }

  # get lagged values of corresponding days
  for (i in seq_along(days_to_use)){

    last_day <- matrix(lag(df$value, 96*days_to_use[i]), ncol = 96, byrow = TRUE)
    all_data_x <- cbind(all_data_x, last_day)

  }

  # generate y values
  all_data_y <- matrix(df$value, ncol = 96, byrow = TRUE)

  # set up train and test set
  train_x <- all_data_x[observation_idx,] %>% data.matrix()
  train_y <- all_data_y[observation_idx,] %>% data.matrix()
  test_x  <- all_data_x[forecast_idx,] %>% data.matrix()
  test_y  <- all_data_y[forecast_idx,] %>% data.matrix()

  na_row_indizes <- 1:ncol(train_x) %>% map(~which(is.na(train_x[,.x]))) %>% unlist() %>% unique()

  # remove NAs due to lagging
  train_x <- train_x[-na_row_indizes,]
  train_y <- train_y[-na_row_indizes,]

  return(list(train_x = train_x, train_y = train_y, test_x = test_x, test_y = test_y, fc_interval = fc_interval))

}

#' forecast using simple nn without holiday effects
#'
#' DID NOT PERFORM!! USE \link{simple_nn_with_holiday_forecast}
#'
#' @param df timeseries data frame.
#' @param net neurel network specification.
#' @param from forecast starting date.
#' @param model_selection flag to perform model selection based on validation
#'   errors.
#' @param weeks_to_use weeks to use as lagged input.
#' @param days_to_use days to use as lagged input.
#' @param number_of_folds number of folds to be used in
#'   \link{mx.crossvalidation}.
#' @param postal_code postal code of current timeseries.
#' @param verbose print during cross validation.
#' @param verbose_mxnet Print during mxnet training.
#' @param ... other parameters passed to \link{mx.crossvalidation}.
#'
#' @import dplyr
#' @importFrom lubridate as_datetime
#'
#' @export

simple_nn_without_holiday_forecast <- function(df,
                                               net = NULL,
                                               from,
                                               model_selection = FALSE,
                                               weeks_to_use = 1,
                                               days_to_use = NULL,
                                               number_of_folds = 5,
                                               postal_code,
                                               verbose = TRUE,
                                               verbose_mxnet = FALSE, ...){

  if(is.null(net)) net <- get_default_networks()

  from <- as_datetime(from)

  input_data <-
    simple_nn_without_holiday_input_generation(df = df, from = from, weeks_to_use = weeks_to_use, days_to_use = days_to_use)

  train_x <- input_data$train_x
  train_y <- input_data$train_y
  test_x  <- input_data$test_x
  test_y  <- input_data$test_y
  fc_interval <- input_data$fc_interval

  additional_model_slug <- paste0('simple_nn_without_holiday_weeks_',weeks_to_use)

  result_df <- mx.crossvalidation(net = net,
                                  train_x = train_x,
                                  train_y = train_y,
                                  number_of_folds = number_of_folds,
                                  verbose = verbose,
                                  verbose_mxnet = verbose_mxnet,
                                  additional_model_slug = additional_model_slug,
                                  ...)

  result_df <-
    result_df %>%
    mutate(forecast = map(model, ~mx.data.output.generation(model = .x, test_x = test_x, test_y = test_y, fc_interval = fc_interval))) %>%
    mutate(na_in_forecast = map_int(forecast, ~sum(is.na(.x$value)))) %>% filter(na_in_forecast == 0)

  naive_result_df <- naive_model_validation(df = df, from = from, postal_code = postal_code)

  result_df <- bind_rows(result_df, naive_result_df)

  if (model_selection) {

    return(nn_model_selection(result_df))

  }

  return(result_df)

}

#' naive model validation function for neural networks as benchmark
#'
#' @param df timeseries data frame.
#' @param from forecast starting date.
#' @param postal_code postal code of current timeseries.
#'
#' @import dplyr

naive_model_validation <- function(df, from, postal_code){

  df_validate <- df %>% filter(timestamp < from)

  naive_seasonal_fc                     <- naive_seasonal(df = df)
  naive_seasonal_holiday_fc             <- naive_seasonal_holiday(df = df, postal_code_or_state = postal_code)
  naive_seasonal_holiday_data_driven_fc <- naive_seasonal_holiday_version_2(df = df, postal_code_or_state = postal_code, generate_holidays_data_driven = TRUE, from = from, return_all = TRUE)

  naive_seasonal_fc_validation_error                     <- 96*mean(abs(naive_seasonal_fc %>% filter(timestamp < from) %>% pull(value)         - df_validate$value), na.rm = T)
  naive_seasonal_holiday_fc_validation_error             <- 96*mean(abs(naive_seasonal_holiday_fc %>% filter(timestamp < from) %>% pull(value) - df_validate$value), na.rm = T)
  naive_seasonal_holiday_data_driven_fc_validation_error <- 96*mean(abs(naive_seasonal_holiday_data_driven_fc %>% filter(timestamp < from) %>% pull(value) - df_validate$value), na.rm = T)

  result_df <- data_frame(model_slug = c('naive_seasonal', 'naive_seasonal_holiday', 'naive_seasonal_holiday_data_driven'),
                          validation_error = c(naive_seasonal_fc_validation_error,
                                               naive_seasonal_holiday_fc_validation_error,
                                               naive_seasonal_holiday_data_driven_fc_validation_error),
                          forecast = list(naive_seasonal_fc %>% filter(timestamp >= from),
                                          naive_seasonal_holiday_fc %>% filter(timestamp >= from),
                                          naive_seasonal_holiday_data_driven_fc %>% filter(timestamp >= from)))

}



#' model selection for NN models based on cv errors
#'
#' @param result_df returned by a nn model function.
#' @param convex_combine parameter to convex combine all
#'  forecasts better than the naive model
#'
#' @import dplyr
#' @importFrom tidyr unnest

nn_model_selection <- function(result_df, convex_combine = FALSE){

  number_models_with_minimal_val_error <- result_df %>% filter(validation_error == min(validation_error)) %>% nrow()


  # if there is more than one model with minimal validation score
  # this indicates something weird. therefore we then choose the most robust model
  # in this cas a naive one. otherwise we chose the one with minimal validation
  # error

  if( number_models_with_minimal_val_error > 1 ){

    forecast_to_return <- result_df %>%
      filter(model_slug %in% c('naive_seasonal_holiday', 'naive_seasonal_holiday_data_driven')) %>%
      arrange(validation_error) %>%
      slice(1) %>%
      select(forecast) %>%
      unnest()

    return(forecast_to_return)


  } else {

    forecast_to_return <- result_df %>%
      arrange(validation_error) %>%
      slice(1) %>%
      select(forecast) %>%
      unnest()

  }

  if (convex_combine){

    naive_forecast_validation_score <- result_df %>%
      filter(model_slug == 'naive_seasonal') %>%
      pull(validation_error)

    result_df <- result_df %>%
      filter(validation_error <= naive_forecast_validation_score)

    if( nrow(result_df) > 1 ){
      result_df <- result_df %>% filter(model_slug != 'naive_seasonal')
    }

    forecast_to_return <- convex_combine_forecasts(result_df %>% pull(forecast))

  }

  return(forecast_to_return)

}

#' generate good default networks
#'
#' @importFrom mxnet mx.symbol.Variable
#' @importFrom mxnet mx.symbol.FullyConnected
#' @importFrom mxnet mx.symbol.Activation
#' @importFrom mxnet mx.symbol.LinearRegressionOutput
#' @importFrom tidyr unnest
#'
#' @export

get_default_networks <- function(){

  label <- mx.symbol.Variable('label')
  data  <- mx.symbol.Variable('data')
  fc_1  <- mx.symbol.FullyConnected(data = data, num_hidden = 12, no.bias = F)
  act_1 <- mx.symbol.Activation(data = fc_1, act.type = 'relu')
  fc_2  <- mx.symbol.FullyConnected(data = act_1, num_hidden = 96, no.bias = F)
  net1  <- mx.symbol.LinearRegressionOutput(data = fc_2, label = label)

  label <- mx.symbol.Variable('label')
  data  <- mx.symbol.Variable('data')
  fc_1  <- mx.symbol.FullyConnected(data = data, num_hidden = 24, no.bias = F)
  act_1 <- mx.symbol.Activation(data = fc_1, act.type = 'relu')
  fc_2  <- mx.symbol.FullyConnected(data = act_1, num_hidden = 96, no.bias = F)
  net2  <- mx.symbol.LinearRegressionOutput(data = fc_2, label = label)

  label <- mx.symbol.Variable('label')
  data  <- mx.symbol.Variable('data')
  fc_1  <- mx.symbol.FullyConnected(data = data, num_hidden = 96, no.bias = F)
  net3  <- mx.symbol.LinearRegressionOutput(data = fc_1, label = label)

  net <- list(net1 = net1, net2 = net2, net3 = net3)

  return(net)
}
