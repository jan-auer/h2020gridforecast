#' Get holidays from postal code
#'
#' \code{get_holidays_from_postal_code} returns the holidays in a specific state
#' of Germany given its postal code \code{postal_code}.
#'
#' Returns all holidays except weekends given a specific postal code.
#'
#' @param postal_code_or_state Three possible input types:
#'   \itemize{
#'     \item Character or integer of the
#'     postal code or the state.
#'     \item Vector of states (as string):
#'     Returns the union of the holdiays for all indicated states.
#'     \item If \code{postal_code_or_state = "all"},
#'     then all German holidays are returned.
#'     }
#'  The holidays for the appropriate input types are returned.
#' @return Vector containing dates.
#' Holidays in a given state of Germany between
#'   01 Jan 2014 and 31 Dec 2018.
#'
#' @examples
#' get_holidays_from_postal_code('01156')
#' get_holidays_from_postal_code(48155)
#' get_holidays_from_postal_code('Sachsen')
#' get_holidays_from_postal_code('Bremen')
#' get_holidays_from_postal_code(c('Sachsen', 'Bremen'))
#' get_holidays_from_postal_code('all')
#'
#' @import dplyr
#' @importFrom purrr map
#' @importFrom purrr reduce
#' @importFrom lubridate ymd
#' @export

get_holidays_from_postal_code <- function(postal_code_or_state){

  # convert input to character vector
  postal_code_or_state <- as.character(postal_code_or_state)

  # input is a vector
  if(length(postal_code_or_state) > 1){
    return( postal_code_or_state %>% map(get_holidays_from_postal_code) %>% reduce(c) %>% unique() )
  }


  # input is not a vector
  # Control sequence
  if (postal_code_or_state == 'all') {

    return( unique(mapping_table_state_to_holiday$date) %>% ymd )

  } else if (postal_code_or_state %in% mapping_table_state_to_holiday$state){

    return(mapping_table_state_to_holiday %>% filter(state == postal_code_or_state) %>% pull(date) %>% ymd)

  } else if (postal_code_or_state %in% mapping_table_postal_code_to_state$postal_code){

    current_state <- mapping_table_postal_code_to_state %>% filter(postal_code == postal_code_or_state) %>% pull(state)
    return(mapping_table_state_to_holiday %>% filter(state == current_state) %>% pull(date) %>% ymd)

  } else {

    warning('postal_code_or_state was not found. using all holidays')
    get_holidays_from_postal_code(postal_code_or_state = 'all')

  }

}

#' Get holidays from timeseries
#'
#' \code{get_holidays_from_timeseries} returns the holidays from the timeseries
#' and the postal code.
#'
#' Using basic inner quantile range heuristics, the holiday data from the postal
#' code is augmented by days which seem like they are holidays, but are in fact
#' normal working days. These are special days like the 24.12. or certain
#' bridging days. The method tries to find those anomal days and adds them to
#' the array of holidays already given by the postal code. At the current
#' status, holidays which behave like normal working days are not handled.
#' Furthermore it is evaluated wether or not bridging days should be modeled as
#' holidays or not.
#'
#' @param df time series data frame.
#' @param postal_code_or_state Three possible input types:
#' \itemize{
#' \item Character of the postal code or the state.
#' \item If \code{postal_code_or_state = "all"},
#' then all German holidays are used.
#' }
#' @param forecast_start_date datetime where the forecast starts.
#'
#' @return Vector containing dates.
#'
#' @import dplyr
#' @importFrom purrr map_lgl
#' @importFrom lubridate ymd
#' @importFrom lubridate ymd
#' @importFrom lubridate as_datetime
#' @importFrom lubridate as_date
#' @export

get_holidays_from_timeseries <- function(df, postal_code_or_state, forecast_start_date){
  
  forecast_start_date <- as_datetime(forecast_start_date)
  
  # helper function to calculate the lower threshold of an unusual day.
  # This is based on the inner quantile range and a certain scaling factor
  calulate_lower_threshold <- function(x, scaling_factor = 1.5){
    
    # remove zeros from the data
    x <- x[x > 0]
    
    # caluclate upper and lower qunatile
    upper_quantile <- quantile(x, probs = 0.75)
    lower_quantile <- quantile(x, probs = 0.25)
    # caluclate inner quantile range
    iqr <- upper_quantile - lower_quantile
    
    # calculate lower threshold
    lower_threshold <- lower_quantile - (iqr * scaling_factor)
    
    return(lower_threshold)
    
  }
  
  # helper function to calculate quantile of strictly positive data
  calulate_quantile <- function(x, probs){
    quantile(x[x > 0], probs = probs)
  }
  
  # trim froecast start date to day format
  forecast_start_date <- as_date(forecast_start_date)
  
  # caluclate daily volume, day of the week, day of the year from whole data
  df_daily_all <- df %>%
    mutate(timestamp = timestamp - minutes(15)) %>%
    mutate(timestamp = as_date(timestamp)) %>%
    group_by(timestamp) %>%
    summarise(value = sum(value)) %>%
    mutate(day_of_week = wday(timestamp, label = T, abbr = F)) %>%
    mutate(day_of_week =
             ordered(day_of_week,
                     levels = c('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'))) %>%
    mutate(day_of_year = substr(timestamp, 6,10))
  
  # get observation period data
  df_daily <- df_daily_all %>% filter(timestamp < forecast_start_date)
  
  # get holidays from postal code
  holidays_all <- get_holidays_from_postal_code(postal_code_or_state = postal_code_or_state)
  # get holidays in the observation period
  holidays_obs <- holidays_all[holidays_all <= max(df_daily$timestamp)]
  
  # get bridging days in the observation period from the holidays in the observation period
  bridging_days_from_holidays <- which_days_are_bridging_days(df_daily$timestamp, holidays = holidays_obs)
  
  # caluculate per day of the week the following summary statistics:
  # the lower threshold, the lower and upper quantile, a flag indicating if it is a anomal day, holiday and briding day
  daily_summaries <- df_daily %>%
    group_by(day_of_week) %>%
    mutate(lower_threshold = calulate_lower_threshold(value),
           lower_quantile = calulate_quantile(value, probs = 0.25),
           upper_quantile = calulate_quantile(value, probs = 0.75)) %>%
    mutate(is_anomal = (value < lower_threshold & value > 0)) %>%
    mutate(is_holiday = timestamp %in% holidays_obs) %>%
    bind_cols(is_bridging_day_from_holidays = bridging_days_from_holidays)
  
  # get fake holidays
  # FUTURE TODO USE THE FOLLOWING DAYS
  days_which_are_holidays_but_are_perfectly_normal <- daily_summaries %>% filter(is_holiday) %>% filter(value > lower_quantile)
  
  # filter the briding days from the data frame
  briding_day_behaviour_df <- daily_summaries %>% filter(is_bridging_day_from_holidays)
  
  if(nrow(briding_day_behaviour_df) > 0){
    
    # decide wether to model bridging days as holidays or not
    if( sum(briding_day_behaviour_df$is_anomal) / nrow(briding_day_behaviour_df) >= 0.75 ){
      model_bridging_days_as_holidays <- TRUE
    } else {
      model_bridging_days_as_holidays <- FALSE
    }
    
  } else {
    model_bridging_days_as_holidays <- TRUE
  }
  
  # initialise the array of data driven holidays
  new_holidays <- c()
  
  # check if there are any anomal holidays appart from holidays and bridging days
  
  if((daily_summaries %>% filter(is_anomal, !is_holiday, !is_bridging_day_from_holidays) %>% nrow()) > 0){
    
    # these days are given as all anomal days which are not holidays and not briding days
    for (current_year in unique(substr(holidays_all, 1, 5))){
      new_holidays <- c(new_holidays,
                        daily_summaries %>%
                          filter(is_anomal, !is_holiday, !is_bridging_day_from_holidays) %>%
                          pull(day_of_year) %>%
                          paste0(current_year ,.) %>%
                          ymd
      )
    }
    
  }
  
  # bind all holidays together
  new_holidays <- unique(c(holidays_all, new_holidays))
  
  # if too few observations better use the old holidays lets say less than a year
  if (nrow(df_daily) < 360){
    new_holidays <- holidays_all
  }
  
  # get briging days from new holidays
  bridging_days_from_new_holidays <- which_days_are_bridging_days(df_daily_all$timestamp, holidays = new_holidays)
  
  # add the briding days to the holiday data if they should be modeled as such
  if(model_bridging_days_as_holidays){
    holidays <- c(new_holidays, df_daily_all %>% filter(bridging_days_from_new_holidays) %>% pull(timestamp))
  } else {
    holidays <- new_holidays
  }
  
  # sort holidays
  holidays <- sort(holidays)
  
  return(holidays)
  
}

#' Check whether current_day is a holiday
#'
#' \code{is_holiday} checks whether one day, i.e. \code{current_day}, is a holiday in the region described by the given postal code \code{postal_code}.
#'
#' @inheritParams is_bridging_day
#'
#' @return Boolean value, indicating whether \code{current_day} is a holiday.
#' @export
#'
#' @examples
#' is_holiday(lubridate::ymd("2015-03-18"), postal_code_or_state = "Sachsen")

is_holiday <- function(current_day, holidays = NULL, postal_code_or_state = NULL){

  # One of "holidays" or "postal_code_or_state" must be non-empty
  if(is.null(holidays) & is.null(postal_code_or_state)) stop('holidays and postal_code_or_state cannot be missing at the same time!')

  if(is.null(holidays)){
    holidays <- get_holidays_from_postal_code(postal_code_or_state)
  }

  return(
    ifelse(current_day %in% holidays, TRUE, FALSE)
  )
}

#' Check if a specific day is a bridging day
#'
#' \code{is_bridging_day} returns whether or not a specific day is a bridging day or not.
#'
#' Returns whether or not a specific day is a bridging day or not.
#'
#' @param current_day Date object: check if the given day corresponds to a bridging day or not.
#' @param holidays Vector of date objects: Contains all holidays in from 01 Jan 2014 until 31 Dec 2017.
#'   Default is NULL.
#'   Usually filled by \link{get_holidays_from_postal_code}.
#'   Providing this argument speeds up computation if \code{is_bridging_day} is called often.
#' @param postal_code_or_state Character or integer representing a postal code, or a string representing a state.
#'   Default is NULL.
#'   If a value is supplied, the function \link{get_holidays_from_postal_code} retrieves the holidays for the given state or postal code.
#' @return Boolean value, indicating whether \code{current_day} is a bridging day.
#'
#' @examples
#' is_bridging_day(current_day = lubridate::ymd('2016-05-06'),
#'                 postal_code_or_state = 'Baden-Württemberg')
#'
#' @export

is_bridging_day <- function(current_day, holidays = NULL, postal_code_or_state = NULL){

  # One of "holidays" or "postal_code_or_state" must be non-empty
  if(is.null(holidays) & is.null(postal_code_or_state)) stop('holidays and postal_code_or_state cannot be missing at the same time!')

  if(is.null(holidays)){
    holidays <- get_holidays_from_postal_code(postal_code_or_state)
  }

  if (current_day %in% holidays){ # every holiday should be a holiday and not a bridging day
    return(FALSE)
  }

  if (wday(current_day) %in% c(7,1)){ # saturday and sunday cannot be bridging days
    return(FALSE)
  }

  # get day before and after
  previous_day <- current_day - lubridate::days(1)
  next_day     <- current_day + lubridate::days(1)

  if (lubridate::wday(previous_day) == 1 & next_day %in% holidays){ # check if previous day is a sunday and the next day is holiday
    return(TRUE)
  } else if (previous_day %in% holidays & lubridate::wday(next_day) == 7){ # check if previous day is a holiday and the next day is a saturday
    return(TRUE)
  } else if ( previous_day %in% holidays & next_day %in% holidays ){ # check if previous and next day are a holiday
    return(TRUE)
  } else { # else it lies between two strict workdays
    return(FALSE)
  }

}

#' Check for each day in a vector of consecutive days whether this day is a bridging day or not
#'
#' \code{which_days_are_bridging_days} checks for each day of a given vector of consecutive days if it is a bridging day in the region described by the given
#' postal code \code{postal_code} or the list of holidays \code{postal_code}.
#' The sole purpose of this function is to speed up the computation if the function \code{is_bridging_day} is called in a loop for many consecutive days.
#'
#' @param days_to_check vector of Date object:
#' @param holidays Vector of date objects: Contains all holidays in from 01 Jan 2014 until 31 Dec 2017.
#'   Default is NULL.
#'   Usually filled by \link{get_holidays_from_postal_code}.
#'   Providing this argument speeds up computation if \code{is_bridging_day} is called often.
#' @param postal_code_or_state Character or integer representing a postal code, or a string representing a state.
#'   Default is NULL.
#'   If a value is supplied, the function \link{get_holidays_from_postal_code} retrieves the holidays or the given state or postal code.
#'
#' @return vector of logicals, indicating which days of \code{days_to_check} are bridging days.
#'
#' @importFrom purrr map_lgl
#' @importFrom lubridate wday
#' @importFrom lubridate days
#' @export
#'
#' @examples
#' days_to_check <- seq(lubridate::ymd('2016-01-01'), lubridate::ymd('2017-01-01'), by = 'day')
#' holidays <- get_holidays_from_postal_code("all")
#' days_to_check[which_days_are_bridging_days(days_to_check, holidays)]

which_days_are_bridging_days <- function(days_to_check, holidays=NULL, postal_code_or_state=NULL) {

  ## argument check
  # One of "holidays" or "postal_code_or_state" must be non-empty
  if(is.null(holidays) & is.null(postal_code_or_state)) stop('holidays and postal_code_or_state cannot be missing at the same time!')

  if(is.null(holidays)){
    holidays <- get_holidays_from_postal_code(postal_code_or_state)
  }

  ## actual code
  # add day before first day
  is_hol <- map_lgl(days_to_check, ~ (.x %in% holidays || wday(.x) %in% c(1,7)))
  is_no_we <- map_lgl(days_to_check, ~ !(wday(.x) %in% c(1,7)))

  tmp_lag <- lag(is_hol,1)
  # check day before first day
  tmp_lag[1] <- (days_to_check[1] - days(1)) %>% (function(x) x %in% holidays || wday(x) %in% c(1,7))

  tmp_lead <- lead(is_hol,1)
  # check day after last day
  tmp_lead[length(tmp_lead)] <- (days_to_check[length(days_to_check)] + days(1)) %>%  (function(x) x %in% holidays || wday(x) %in% c(1,7))


  return(apply(cbind(tmp_lag,tmp_lead,is_no_we,!is_hol),1, all))
}

