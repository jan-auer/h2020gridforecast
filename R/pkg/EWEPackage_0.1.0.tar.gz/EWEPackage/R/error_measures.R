#' Calculate daily absolute error
#'
#' The function \code{daily_absolute_error} returns the daily absolute error
#' between the dataframes \code{df_actual} and \code{df_forecast} which both
#' contain the columns "timestamp" and "value". To be more precise, the sum
#' across all absolute differences between values in one day is calculated.
#'
#' The dataframes of the "actual" and "forecast" time series are trimmed such
#' that they cover the same time span. The absolute error for each timestamp is
#' calculated and aggregated on a daily basis. Therefore, the returned dataframe
#' contains the columns 'timestamp' and 'value' (in the same way as the input
#' dataframes). For more details see
#' \href{https://confluence.mantigma.com/display/EWE/Error+Measures}{Confluence}.
#'
#' @param df_actual Dataframe with variable names 'timestamp' and 'value' of the
#'   observed time series.
#' @param df_forecast Dataframe with variable names 'timestamp' and 'value' of
#'   time series forecast.
#' @param forecast_start_date Date object: Start date of the forecast horizon.
#'   Default is NULL (in which case the error is calculated across the maximal
#'   available overlapping period). If argument is provided, then both
#'   dataframes are filtered such that only data from \code{forecast_start_date}
#'   onwards are included.
#' @param use_mapping_table Boolean value indicating whether or not the internal
#'   mapping table should be used. This increases the speed of the function
#'   significantly.
#' @return Data frame with columns 'timestamp' and 'value' of the daily absolute
#'   error.
#'
#' @import dplyr
#' @importFrom lubridate ymd
#' @importFrom lubridate minutes
#' @export

daily_absolute_error <- function(df_actual,
                                 df_forecast,
                                 forecast_start_date = NULL,
                                 use_mapping_table = FALSE){

  # Check inputs
  if (ncol(df_actual) != 2) stop('df_actual should have two columns')
  if (ncol(df_forecast) != 2) stop('df_forecast should have two columns')
  if (! 'timestamp' %in% names(df_actual)) stop('df_actual doesn\'t have column timestamp')
  if (! 'value' %in% names(df_actual)) stop('df_actual doesn\'t have column value')
  if (! 'timestamp' %in% names(df_forecast)) stop('df_forecast doesn\'t have column timestamp')
  if (! 'value' %in% names(df_forecast)) stop('df_forecast doesn\'t have column value')


  if (!is.null(forecast_start_date)){

    df_actual <- df_actual %>%
      filter(timestamp >= forecast_start_date)

    df_forecast <- df_forecast %>%
      filter(timestamp >= forecast_start_date)

  }


  # if different time horizons are given we trim them to be the same
  if (nrow(df_actual) != nrow(df_forecast)){

    first_date_df_actual <- min(df_actual$timestamp)
    last_date_df_actual  <- max(df_actual$timestamp)

    first_date_df_forecast <- min(df_forecast$timestamp)
    last_date_df_forecast  <- max(df_forecast$timestamp)

    first_date <- max(first_date_df_actual, first_date_df_forecast)
    last_date  <- min(last_date_df_actual, last_date_df_forecast)

    df_actual <- df_actual %>%
      filter(timestamp >= first_date, timestamp <= last_date)

    df_forecast <- df_forecast %>%
      filter(timestamp >= first_date, timestamp <= last_date)
    
    if (nrow(df_actual) == 0 | nrow(df_forecast) == 0){
      stop("time horizons of actual ts and forecast df do not overlap")
    }

  }

  if (!use_mapping_table){

    output <-
      data_frame(timestamp = df_actual$timestamp,
                 differences = df_actual$value - df_forecast$value) %>%
      mutate(timestamp = timestamp - minutes(15)) %>%
      mutate(timestamp = substr(timestamp,1,10)) %>%
      group_by(timestamp) %>%
      summarise(value = sum(abs(differences))) %>%
      mutate(timestamp = ymd(timestamp))

  } else {

    output <-
      data_frame(timestamp = df_actual$timestamp,
                 differences = df_actual$value - df_forecast$value) %>%
      mutate(timestamp = timestamp - minutes(15))

    output <-
      output %>%
      left_join(mapping_table_datetime_to_day, by = 'timestamp') %>%
      rename(timestamp_old = timestamp) %>%
      select(-timestamp_old) %>%
      rename(timestamp = timestamp_new) %>%
      group_by(timestamp) %>%
      summarise(value = sum(abs(differences))) %>%
      mutate(timestamp = ymd(timestamp))

  }

  return(output)

}



#' Calculate daily absolute percentage error
#'
#' \code{daily_absolute_percentage_error} returns the daily absolute percentage
#' error between \code{df_actual} and \code{df_forecast}.
#'
#' The input data frames filtered to only contain the timestamps which appear in
#' both. The absolute percentage error for each day is calculated. Therefore,
#' the returned data frame column names are 'timestamp' and 'value'. For more
#' details see
#' \href{https://confluence.mantigma.com/display/EWE/Error+Measures}{Confluence}.
#'
#' @inheritParams daily_absolute_error
#'
#' @import dplyr
#' @importFrom lubridate ymd
#' @importFrom lubridate minutes
#' @export

daily_absolute_percentage_error <- function(df_actual,
                                            df_forecast,
                                            forecast_start_date = NULL,
                                            use_mapping_table = FALSE){

  # Check inputs
  if (ncol(df_actual) != 2) stop('df_actual should have two columns')
  if (ncol(df_forecast) != 2) stop('df_forecast should have two columns')
  if (! 'timestamp' %in% names(df_actual)) stop('df_actual doesn\'t have column timestamp')
  if (! 'value' %in% names(df_actual)) stop('df_actual doesn\'t have column value')
  if (! 'timestamp' %in% names(df_forecast)) stop('df_forecast doesn\'t have column timestamp')
  if (! 'value' %in% names(df_forecast)) stop('df_forecast doesn\'t have column value')


  if (!is.null(forecast_start_date)){

    df_actual <- df_actual %>%
      filter(timestamp >= forecast_start_date)

    df_forecast <- df_forecast %>%
      filter(timestamp >= forecast_start_date)

  }


  # if different time horizons are given we trim them to be the same
  if (nrow(df_actual) != nrow(df_forecast)){

    first_date_df_actual <- min(df_actual$timestamp)
    last_date_df_actual  <- max(df_actual$timestamp)

    first_date_df_forecast <- min(df_forecast$timestamp)
    last_date_df_forecast  <- max(df_forecast$timestamp)

    first_date <- max(first_date_df_actual, first_date_df_forecast)
    last_date  <- min(last_date_df_actual, last_date_df_forecast)

    df_actual <- df_actual %>%
      filter(timestamp >= first_date, timestamp <= last_date)

    df_forecast <- df_forecast %>%
      filter(timestamp >= first_date, timestamp <= last_date)

  }

  if(!use_mapping_table){

    output <-
      data_frame(timestamp = df_actual$timestamp,
                 differences = df_actual$value - df_forecast$value,
                 actual = df_actual$value) %>%
      mutate(timestamp = timestamp - minutes(15)) %>%
      mutate(timestamp = substr(timestamp,1,10)) %>%
      group_by(timestamp) %>%
      summarise(value = 100 * mean(abs(differences/actual))) %>%
      mutate(timestamp = ymd(timestamp))

  } else {

    output <-
      data_frame(timestamp = df_actual$timestamp,
                 differences = df_actual$value - df_forecast$value,
                 actual = df_actual$value) %>%
      mutate(timestamp = timestamp - minutes(15))

    output <-
      output %>%
      left_join(mapping_table_datetime_to_day, by = 'timestamp') %>%
      rename(timestamp_old = timestamp) %>%
      select(-timestamp_old) %>%
      rename(timestamp = timestamp_new) %>%
      group_by(timestamp) %>%
      summarise(value = 100 * mean(abs(differences/actual))) %>%
      mutate(timestamp = ymd(timestamp))

  }

  return(output)

}

