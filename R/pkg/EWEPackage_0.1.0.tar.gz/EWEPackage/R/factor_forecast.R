#' Automated forecasting with GDFMs
#'
#' comment_bf: docu missing
#'
#' @param df Tibble with columns (timestamp, value).
#' @param postal_code Character containing postal code of one particular meter point.
#' @param var_expl Double. Threshold for variance explained by PCA
#' @param n_factors Int. Number of factors used for forecasting. Can be used instead of var_expl.
#' @param from Date (comment_bf: or datetime?). Starting date of forecasting period
#' @param to Date (comment_bf: or datetime?). End date of forecasting period
#'
#' @return Tibble with columns (timestamp, value), containing the forecast.
#'
#' @export
forecast_fm <- function(df,
                        postal_code,
                        var_expl = 0.9,
                        n_factors=NULL,
                        from,
                        to) {


  ## __ obtain train and test dataset (<from, >=from) ####
  from <- dplyr::enquo(from)
  to <- dplyr::enquo(to)

  df_train <- df %>%
              dplyr::filter(timestamp < rlang::UQ(from))

  ## __ truncate training dataset ####
 if (nrow(df_train) %% 96){
    df_train <- truncate_ts_day(df_train)
  }

 ## __ df_train: dummies ####
  postal_code_enquo <- rlang::enquo(postal_code)

  b_state <- mapping_table_postal_code_to_state %>%
    dplyr::filter(postal_code == rlang::UQ(postal_code)) %>%
    dplyr::pull(state)

  dummies_holi <- dummies_listcol %>%
    dplyr::filter(state == b_state) %>%
    tidyr::unnest(dummy_holidays) %>%
    dplyr::select(-state) %>%
    dplyr::rename(dummy_hol = value)

  dummies_bridge <- dummies_listcol %>% # comment_bf: copied code
    dplyr::filter(state == b_state) %>%
    tidyr::unnest(dummy_bridgingdays) %>%
    dplyr::select(-state) %>%
    dplyr::rename(dummy_bridge = value) %>%
    dplyr::mutate(dummy_bridge = as.numeric(dummy_bridge))

  ## __ df_train: Choose dummies ####
  df_train <- df_train %>%
    dplyr::left_join(dummies_wday, by = "timestamp") %>%
    dplyr::mutate(dummy_wd = dummy_tue + dummy_wed + dummy_thu ) %>% # comment_bf: hard coded
    dplyr::select(-c(dummy_tue, dummy_wed, dummy_thu)) %>%
    dplyr::left_join(dummies_holi, by = "timestamp") %>%
    dplyr::left_join(dummies_bridge, by = "timestamp")

  ## __ df_train: regression -> dummy_coef, res_train ####
  res_lm <- lm(value ~ . -1, data = df_train %>% select(-timestamp))

  df_train$resid <- res_lm %>% residuals()

  ##
  coef_dummies <- res_lm %>% coefficients() %>% matrix(ncol=1)

  ## __ PCA on res_train ####
  mat_resid <- matrix(df_train$resid, ncol = 96, byrow = TRUE)
  mat_resid_means <- apply(mat_resid, 2, mean)
  pca_obj <- prcomp(mat_resid, center = TRUE)

  ## __ choose number of factors (by var_expl or nfactors) ####
  if (!is.null(n_factors)) {
    pca_idx <- 1:n_factors
  } else {
   pv <- (pca_obj$sdev)^2
   pca_idx <- which ( cumsum(pv/sum(pv)) < var_expl )
   if(length(pca_idx)<1) {
     ##  cat('\n Factor threshold problem: ', paste(cumsum(pv/sum(pv)), collapse=', '), '\n')
     pca_idx <- c(1)
   } else {
     pca_idx <- c(pca_idx, max(pca_idx)+1)
   }
  }

  mat_factors <- pca_obj$x[, pca_idx, drop = FALSE]

  print(dim(mat_factors))
  ## __ lm(res_train ~ lag(factors)) ####

  ## mat_factors_lagged
  mat_factors_lagged <- mat_factors %>% as_tibble() %>%
    mutate_all(funs(lag_02 = lag(., n=2))) %>%
    mutate_at(.vars = vars(-contains("_lag_")), .funs = funs(lag_03 = lag(., n=3))) %>%
    mutate_at(.vars = vars(-contains("_lag_")), .funs = funs(lag_07 = lag(., n=7))) %>%
    select(contains("lag")) %>%
    as.matrix()

  beta <- coef(lm(matrix(df_train$resid, ncol=96, byrow=TRUE)~0+mat_factors_lagged, na.action=na.exclude))
  ## gives us beta

  ## __ Forecast w. (beta, coef_dummies, f_{d+h})

  df_test <- df %>%
    dplyr::filter(timestamp >= rlang::UQ(from))

  ## df_test
  df_test <- df_test %>%
    dplyr::left_join(dummies_wday, by = "timestamp") %>%
    dplyr::mutate(dummy_wd = dummy_tue + dummy_wed + dummy_thu ) %>% # comment_bf: hard coded
    dplyr::select(-c(dummy_tue, dummy_wed, dummy_thu)) %>%
    dplyr::left_join(dummies_holi, by = "timestamp") %>%
    dplyr::left_join(dummies_bridge, by = "timestamp")

  #
  ## f_{d+h} = V_1' (y_{d+h} - ''dummies'')
  mat_test <- df_test %>% select(-c(timestamp, value)) %>% as.matrix()

  pred_resid_mean <- matrix(rep(mat_resid_means, nrow(mat_test)/96))
  pred_dummies <- mat_test %*% coef_dummies
  df_test$resid <- df_test$value - pred_dummies

  test_factors <- matrix(df_test$resid, byrow=TRUE, ncol=96) %*% pca_obj$rotation[,1:length(pca_idx), drop=FALSE]
  ## print(dim(test_factors))
  ## add factors from the past

  test_factors <- rbind(mat_factors[(nrow(mat_factors)-6):nrow(mat_factors),,drop=FALSE],
                        test_factors)

  test_factors_lagged <- test_factors %>% as_tibble() %>%
    mutate_all(funs(lag_02 = lag(., n=2))) %>%
    mutate_at(.vars = vars(-contains("_lag_")), .funs = funs(lag_03 = lag(., n=3))) %>%
    mutate_at(.vars = vars(-contains("_lag_")), .funs = funs(lag_07 = lag(., n=7))) %>%
    select(contains("lag_")) %>%
    filter_all(all_vars(!is.na(.))) %>%
    as.matrix()

  ## any(is.na(test_factors_lagged))
  ## Return list:

  ## print(dim(test_factors_lagged))
  ##print(dim(beta))

  ##  print(length(matrix(pred_dummies)))
  ##  print(length(matrix(test_factors_lagged %*% beta)))

  df_pred <- tibble(timestamp=df_test$timestamp,
                    value=as.numeric(pred_resid_mean+matrix(pred_dummies) + matrix(test_factors_lagged %*% beta)))


  return(df_pred)

}

#' Create regessors for factor forecast
#'
#' \code{create_factor_regression} generates all variables necessary for factor forecasting.
#' The regressors comprise
#' \itemize{
#'   \item estimate (lagged) factors (for which \code{my_lags} is needed)
#'   \item dummies for holidays (for which \code{postal_code} is needed)
#'   \item dummies for the days of the week
#' }
#'
#' @param my_df_load Data_frame object. Generic load time series with columns "timestamp" and "value"
#' @param my_postal_code Character or integer, indicating the postal code pertaining to a given load time series, needed to retrieve holidays for a given postal code.
#' @param my_lags Data_frame object. Columns are "lag_day" and "lag_q_hour".
#'   Default is set to daily lags at days \code{1, 2, 3, 7, 14, 21}.
#'   Can be set to NULL, in which case no lags are included.
#' @param my_dummies_wday_hb List object containing integers referring to weekdays and "special" days (1 to 7 = Sunday to Saturday, 8 = Holidays, 9 = Bridging days, 10 = School holidays).
#'   One list element corresponds to one dummy variable, i.e. if one wants different dummies for all weekdays, then the first seven list elements must contain the integers 1 to 7.
#'   The list can be of length 7 to 10, depending on whether one wants to treat holidays (8), bridging days (9), and school holidays (10).
#'   Including the integers 8 and 9 (representing holidays and bridging days) allows for flexible combining of different calendar effect dummies.
#'   Note: 1 corresponds to Sunday!
#'   Default is \code{list(1,2,3,4,5,6,7,8,9)}, i.e. every weekday has its own intercept and holidays and bridging days are treated separately.
#'   School holidays are not included as default because they do not lead to improved forecasting precision.
#'
#' @return List column containing the time series and the regressors for each quarter hour separately.
#'   One list contains a data_frame with columns "timestamp", "value", "value_lag_DD_QQ" (see \link{get_lags}), "dummy_holidays", "dummy_bridging", "dummy_sun", ... "dummy_sat".
#' @importFrom purrr %>%
#' @export
#'
create_factor_regression <- function(df,
                                     postal_code,
                                     var_expl,
                                     from,
                                     to){

 # print(nrow(df))
  if (nrow(df) %% 96){
    df <- truncate_ts_day(df)

  }

  postal_code_enquo <- rlang::enquo(postal_code)

  b_state <- mapping_table_postal_code_to_state %>%
    dplyr::filter(postal_code == rlang::UQ(postal_code)) %>%
    dplyr::pull(state)

#  print(b_state)

  dummies_holi <- dummies_listcol %>%
    dplyr::filter(state == b_state) %>%
    tidyr::unnest(dummy_holidays) %>%
    dplyr::select(-state) %>%
    dplyr::rename(dummy_hol = value)

 # print('x')

  dummies_bridge <- dummies_listcol %>% # comment_bf: copied code
    dplyr::filter(state == b_state) %>%
    tidyr::unnest(dummy_bridgingdays) %>%
    dplyr::select(-state) %>%
    dplyr::rename(dummy_bridge = value) %>%
    dplyr::mutate(dummy_bridge = as.numeric(dummy_bridge))

 # print('y')

  df <- df %>%
    dplyr::left_join(dummies_wday, by = "timestamp") %>%
    dplyr::mutate(dummy_wd = dummy_tue + dummy_wed + dummy_thu ) %>% # comment_bf: hard coded
    dplyr::select(-c(dummy_tue, dummy_wed, dummy_thu)) %>%
    dplyr::left_join(dummies_holi, by = "timestamp") %>%
    dplyr::left_join(dummies_bridge, by = "timestamp")

 # print('z')

  df$resid <- lm(value ~ . -1, data = df %>% select(-timestamp)) %>% residuals()

  pca_obj <- prcomp(matrix(df$resid, ncol = 96, byrow = TRUE), center = FALSE)

  pv <- (pca_obj$sdev)^2
  pca_idx <- which ( cumsum(pv/sum(pv)) < var_expl )
  if(length(pca_idx)<1) {
  ##  cat('\n Factor threshold problem: ', paste(cumsum(pv/sum(pv)), collapse=', '), '\n')
    pca_idx <- c(1)
  } else {
    pca_idx <- c(pca_idx, max(pca_idx)+1)
  }
  pca_tibble <- pca_obj$x[, pca_idx, drop = FALSE] %>% as_tibble()

  ## print(dim(df)) # 105216 x 10 ... 105120 = 3*365*96 = 3 years of data
  ## print(dim(pca_tibble)) # 1096 x 2 ... 1096 = 105216 / 96, 1096 = 3 * 365 + 1(Schaltjahr)
  ## df <- dplyr::bind_cols(df, pca_tibble)

  return(list(df=df, pca_tibble=pca_tibble))

}

#' Truncate function for a single time series
#'
#' comment_bf: docu missing
#'
#' @param df Tibble with columns (timestamp, value)
#'
#' @return Tibble whose number of rows is a multiple of 96.
#' @export
truncate_ts_day <- function(df) {

  df2 <- df %>%
    dplyr::left_join(mapping_table_datetime_to_day_used, by = 'timestamp') %>%
    dplyr::group_by(timestamp_date) %>%
    tidyr::nest() %>%
    dplyr::mutate(fullblock = purrr::map_lgl(data, ~if_else(nrow(.x)==96, TRUE, FALSE))) %>%
    dplyr::filter(fullblock == TRUE) %>%
    dplyr::select(data) %>%
    tidyr::unnest()
  return(df2)
}
