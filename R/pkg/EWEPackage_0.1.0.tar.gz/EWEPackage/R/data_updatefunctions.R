#' Helper function to generate \link{mapping_table_day_to_datetime}
#'
#' @param from start date for the mapping table.
#' @param to end date for the mapping table.
#'
#' @import dplyr
#' @importFrom devtools use_data
#' @importFrom purrr map
#' @importFrom lubridate ymd

update_mapping_table_day_to_datetime <- function(from = ymd('2013-01-01'), to = ymd('2018-01-01')){

  mapping_table_day_to_datetime <-
    data_frame(day = seq(from, to, by = 'day')) %>%
    mutate(datetime = map(day, day_to_datetime))

  use_data(mapping_table_day_to_datetime, overwrite = TRUE)

}

#' Helper function to generate \link{mapping_table_postal_code_to_state}
#'
#' @import dplyr
#' @importFrom devtools use_data
#' @importFrom DBI dbDisconnect

update_mapping_table_postal_code_to_state <- function(){

  ewe_db <- connect_to_ewe_db()

  mapping_table_postal_code_to_state_new <- tbl(ewe_db$con, 'plz') %>%
    as_data_frame() %>%
    select(plz, state) %>%
    rename(postal_code = plz)

  dbDisconnect(ewe_db$con)

  use_data(mapping_table_postal_code_to_state, overwrite = TRUE)

}

# FUTURE TODO more update_mapping_table_* functions

# FUTURE TODO INITIALIZATION SCRIPT
