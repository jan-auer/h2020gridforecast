#' output generation of most mxnet functions.
#'
#' @param model fitted mxnet model.
#' @param test_x X of the test period.
#' @param test_y Y of the test period. Is automatically set to zero, just used
#'   to get the correct size of the forecast.
#' @param fc_interval The forecast interval.
#'
#' @import dplyr
#' @importFrom mxnet mx.io.arrayiter
#'
#' @export

mx.data.output.generation <- function(model, test_x, test_y, fc_interval){

  testIter <- mx.io.arrayiter(data = t(test_x), label = t(test_y*0))

  predictions <- predict(model, testIter) %>% as.vector()

  data_frame(timestamp = fc_interval, value = predictions)

}
