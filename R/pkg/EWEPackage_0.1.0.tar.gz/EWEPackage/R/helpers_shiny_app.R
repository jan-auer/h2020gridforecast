#' Name converter for frequently used column names of data frame.
#'
#' \code{name_converter} returns nicer looking names.
#'
#' Input should be a vector of characters. These are, if they match specific
#' names, converted to nicer looking names. So are for example 'ts_load' and
#' 'ts_fc_ewe' replaced by 'Load' and 'Robotron Forecast'. This function is just
#' a helper function for \link{plot_df_nested_with_dygraph}.
#'
#' @param names_of_timerseries_to_plot vector of characters with the names of
#'   the data to be plotted
#'
#' @return vector of characters with probably nicer looking names

name_converter <- function(names_of_timerseries_to_plot){

  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_load'] <- 'Load'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_ewe'] <- 'Robotron Forecast'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_ewe_trimmed'] <- 'Robotron Forecast'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_naive'] <- 'Naive Model'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_naive_holiday'] <- 'Naive Model Holiday'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_naive_holiday_averaged'] <- 'Naive Model Holiday Averaged'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_naive_holiday_data_driven'] <- 'Naive Model Holiday Data Driven'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_convex_TRUE'] <- 'NN Convex True'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_convex_FALSE'] <- 'NN Convex FALSE'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_auto_arx'] <- 'Auto ARX'
  names_of_timerseries_to_plot[names_of_timerseries_to_plot == 'ts_fc_auto_arx_data_driven'] <- 'Auto ARX data driven'

  return(names_of_timerseries_to_plot)
}

#' Plot nested data frame with dygraph
#'
#' \code{plot_df_nested_with_dygraph} plots the timeseris in the nested data
#' frame using dygraph.
#'
#' The input data frames should be a 1 x n nested data frame where each column
#' contains a data frame of the timeseries to be plotted. This timeseries itself
#' is again a data frame with column names 'timestamp' and 'value.'
#'
#' @param df_nested Nested data frame.
#' @param aggregation_level Character indicating the aggregation level of the
#'   timeseries. Should be one of the following: '15 minutes', '30 minutes',
#'   'hour', 'day', 'month'.
#' @param intersection_of_ts Flag indicating to plot just the intersection of
#'   the timeseries or not. Defaults to TRUE.
#' @param main Main plot title (optional).
#' @param group Group to associate this plot with. The x-axis zoom level of
#'   plots within a group is automatically synchronized.
#' @param colors Colors of the dygraph.
#' @return dygraph plot
#'
#' @import dplyr
#' @import dygraphs
#' @importFrom lubridate ymd_hms
#' @export

plot_df_nested_with_dygraph <- function(df_nested,
                                        aggregation_level = '15 minutes',
                                        intersection_of_ts = TRUE,
                                        main = NULL,
                                        group = NULL,
                                        colors = NULL){

  # detect null columns
  columns_to_keep <- df_nested %>% map_lgl(~is.null(unlist(.x))) != TRUE
  df_nested <- df_nested[columns_to_keep]

  if(intersection_of_ts){

    first_date <- c()
    last_date  <- c()

    for (i in 1:ncol(df_nested)){
      first_date <- c(first_date, df_nested[i] %>% unnest() %>% .$timestamp %>% min)
      last_date  <- c(last_date,  df_nested[i] %>% unnest() %>% .$timestamp %>% max)
    }

    first_date <- max(first_date)
    last_date  <- min(last_date)

  } else {
    first_date <- -Inf
    last_date <- Inf
  }

  timeseries_to_plot <- c()
  names_of_timerseries_to_plot <- names(df_nested)

  for (current_column in names_of_timerseries_to_plot){

    current_timeseries <-
      df_nested[current_column] %>%
      unnest() %>%
      filter(timestamp >= first_date, timestamp <= last_date) %>%
      mutate(timestamp = timestamp - minutes(15)) %>%
      mutate(timestamp = floor_date(timestamp, aggregation_level)) %>%
      group_by(timestamp) %>%
      summarise(value = sum(value)) %>%
      df_to_xts()

    timeseries_to_plot <- cbind(timeseries_to_plot, current_timeseries)

  }

  names_of_timerseries_to_plot <- name_converter(names_of_timerseries_to_plot)

  names(timeseries_to_plot) <- names_of_timerseries_to_plot

  timeseries_to_plot %>%
    dygraph(main = main, group = group) %>%
    dyRangeSelector(height = 20) %>%
    dyOptions(colors = colors)

}

#' Plot the residuals with dygraph
#'
#' \code{plot_residuals_with_dygraph} plots the timeseris of resiudals between
#' multiple timeseries data frames.
#'
#' The input data frames should be a 1 x n nested data frame where each column
#' contains a data frame of the timeseries. This timeseries itself is again a
#' data frame with column names 'timestamp' and 'value.' The first one is the
#' reference timeseries.
#'
#' @param df_nested Nested data frame.
#' @param aggregation_level Character indicating the aggregation level of the
#'   timeseries. Should be one of the following: '15 minutes', '30 minutes',
#'   'hour', 'day', 'month'.
#' @param absolute TRUE or FALSE indicating weather to show absolute residuals
#'   or not.
#' @param main Main plot title (optional).
#' @param group Group to associate this plot with. The x-axis zoom level of
#'   plots within a group is automatically synchronized.
#' @param colors Colors of the dygraph.
#' @return dygraph plot
#'
#' @import dplyr
#' @import dygraphs
#' @importFrom lubridate ymd_hms
#' @export

plot_residuals_with_dygraph <- function(df_nested,
                                        aggregation_level = '15 minutes',
                                        absolute = FALSE,
                                        main = NULL,
                                        group = NULL,
                                        colors = NULL){

  # detect null columns
  columns_to_keep <- df_nested %>% map_lgl(~is.null(unlist(.x))) != TRUE
  df_nested <- df_nested[columns_to_keep]

  # if only the reference timeseries data frame is not NULL we just return NULL
  if (ncol(df_nested) == 1) return(NULL)

  first_date <- c()
  last_date  <- c()

  for (i in 1:ncol(df_nested)){
    first_date <- c(first_date, df_nested[i] %>% unnest() %>% .$timestamp %>% min)
    last_date  <- c(last_date,  df_nested[i] %>% unnest() %>% .$timestamp %>% max)
  }

  first_date <- max(first_date)
  last_date  <- min(last_date)

  if(first_date > last_date) return(NULL)

  timeseries_to_plot <- c()
  names_of_timerseries_to_plot <- names(df_nested)

  reference_timeseries <-
    df_nested[names_of_timerseries_to_plot[1]] %>%
    unnest() %>%
    filter(timestamp >= first_date, timestamp <= last_date) %>%
    mutate(timestamp = timestamp - minutes(15)) %>%
    mutate(timestamp = floor_date(timestamp, aggregation_level)) %>%
    group_by(timestamp) %>%
    summarise(value = sum(value)) %>%
    df_to_xts()

  for (current_column in names_of_timerseries_to_plot[-1]){

    current_timeseries <-
      df_nested[current_column] %>%
      unnest() %>%
      filter(timestamp >= first_date, timestamp <= last_date) %>%
      mutate(timestamp = timestamp - minutes(15)) %>%
      mutate(timestamp = floor_date(timestamp, aggregation_level)) %>%
      group_by(timestamp) %>%
      summarise(value = sum(value)) %>%
      df_to_xts()

    if (absolute){
      timeseries_to_plot <- cbind(timeseries_to_plot, abs(reference_timeseries - current_timeseries))
    } else {
      timeseries_to_plot <- cbind(timeseries_to_plot, reference_timeseries - current_timeseries)
    }

  }

  names_of_timerseries_to_plot <- name_converter(names_of_timerseries_to_plot)

  names_of_timerseries_to_plot <- paste( names_of_timerseries_to_plot[1] , 'vs', names_of_timerseries_to_plot[-1])

  names(timeseries_to_plot) <- names_of_timerseries_to_plot

  timeseries_to_plot %>%
    dygraph(main = main, group = group) %>%
    dyRangeSelector(height = 20) %>%
    dyOptions(colors = colors)

}
