
#' Incrementally Forecast Load using various Exponential Smoothing methods
#'
#'\code{increm_day_ahead_ets_forecast} produces
#'
#' @param df Data frame with variable names 'timestamp' and 'value' of the
#'   observed time series.
#' @param postal_code Character or integer representing a postal code,
#'   or a string representing a state.
#' @param from starting date of the forecast period.
#' @param to end date of the forecast period.
#' @param fc_type The type of forecast chosen.
#' @param days_of_modelbuilding The number of days supposed to be used for estimating parameters.
#' @param model A list containing information about the fitted model.
#' @param reestimate An integer specifying after how many days the parameters should be reestimated
#' @param aggregate_hours An integer specifying how many quarter-hours should be aggregated. A value of \code{4} results in hourly data.
#'   should devide 96 without rest.
#' @param armethod If TRUE an additional AR-1 model for the errors is estimated in the (ds)HW models.
#' @param verbose If TRUE additional outputs about the progress of the computation are printed.
#'
#' @return Data frame with variable names 'timestamp' and 'value' of the specified forecast.
#'
#' @import dplyr
#' @importFrom lubridate days
#' @importFrom lubridate ymd
#' @importFrom lubridate floor_date
#' @importFrom lubridate hour
#' @importFrom lubridate minute
#'
#'
#' @export
#'
#' @examples
#'
#' \dontrun{
#' base_top %>%
#' mutate(fc_dshw = pmap(list(ts_load, postal_code, forecast_start_date, forecast_end_date),
#' increm_day_ahead_ets_forecast, fc_type = "mult_dshw"))
#' }
#'

increm_day_ahead_ets_forecast <- function(df, postal_code, from, to= NULL, fc_type, days_of_modelbuilding = 8*7, model = NULL, reestimate = 1000, aggregate_hours = 4, armethod=TRUE, verbose = FALSE){
  ## compute day ahead forecast for specified time horizon
  ## should be an integer number of days

  if (verbose) print('entered increm_day_ahead_ets_forecast')

  # deal with with not full days
  df <- cut_non_full_days(df)

  # determine period depending on the aggregation
  out <- determine_periods(aggregate_hours)
  period_1 <- out$period_1; period_2 <- out$period_2

  # fix inputs
  if (is.null(to)){
    to <- from + days(7)
  }
  from <- as_datetime(from)
  to <- as_datetime(to)

  ## allocate prediction data frame
  numof_days_to_predict <- as.numeric(to - floor_date(from, "day"))
  numof_qu_h_to_predict <- numof_days_to_predict*96
  day_ahead_prediction <- data_frame(timestamp = seq(as.POSIXct(from, tz = 'UTC'),
                                                     as.POSIXct(to, tz = 'UTC'), by = '15 min'),
                                     value = numeric(length = numof_qu_h_to_predict))

  ## get list of holidays
  list_of_holidays <- get_holidays_from_timeseries(df,postal_code, forecast_start_date = from)

  ## put this in a different place
  additional_days_around_new_years <- 2*7

  ## throw away all data not needed
  training_set <- df %>%
    filter(timestamp >= from - days(1 + days_of_modelbuilding + additional_days_around_new_years))


  ## remove holidays from this "training set"
  cleaned_df <- overwrite_holiday_with_regular_day(df, list_of_holidays, training_set)

  ## remove zeros
  cleaned_df <- replace_zeros_for_multiplicative_ets(cleaned_df)

  cleaned_training_set <- cleaned_df %>% filter(timestamp < from-days(1) &
                                                  timestamp >= from - days(1 + days_of_modelbuilding) )
  if (verbose) print('cleaning done')


  #set up some constants for performance improvement
  christmas <- ymd("2015-12-24")
  week_after_new_year <- ymd("2016-01-07")


  ## start incremental forecasting
  if (verbose) print('forecasting incrementally')
  i <- 1
  while (i <= numof_days_to_predict){
    if (!(i %% 100) & verbose ) print(paste('currently at day', i))

    use_data_up_until_this_point  <- from + days(i-2)
    day_which_is_predicted_in_this_step <- as.Date(from + days(i-1))

    ## go this far back in using data for model estimation
    use_data_this_far_in_the_past <- use_data_up_until_this_point - days(days_of_modelbuilding)

    # we don't want new years at the beginning of our training set (messes with the initial values)
    if (christmas >= use_data_this_far_in_the_past && christmas <= use_data_up_until_this_point){
      use_data_this_far_in_the_past <- use_data_up_until_this_point - days(days_of_modelbuilding+additional_days_around_new_years)
    } else if (week_after_new_year >= use_data_this_far_in_the_past && week_after_new_year <= use_data_up_until_this_point){
      use_data_this_far_in_the_past <- use_data_up_until_this_point - days(days_of_modelbuilding - 2*7)
    }
    cleaned_training_set <- cleaned_df %>% filter(timestamp < use_data_up_until_this_point & timestamp >= use_data_this_far_in_the_past)

    if (cleaned_training_set %>% slice(1) %>% pull(timestamp) != use_data_this_far_in_the_past ){
      # this means the history is not long enough to use the desired number of training
    }

    # reestimate model
    if (i %% reestimate == 0){
      model = NULL
    }

    ## if ts is constant, use naive forecast
    if (sd(cleaned_training_set$value) < 0.001){
      naive_fc <- naive_seasonal_holiday_version_2(df, holidays = list_of_holidays, from = from)
      days_since_last_reestimate <- i %% reestimate
      days_until_next_reestimate <- reestimate - days_since_last_reestimate
      # if time until next reestimation is longer than forecast horizon, quit forecast here
      if (reestimate > numof_days_to_predict){
        day_ahead_prediction$value[1:numof_qu_h_to_predict] <- naive_fc$value[1:numof_qu_h_to_predict]
        return(day_ahead_prediction)
      }
      days_left_to_predict <- numof_days_to_predict-i
      day_ahead_prediction$value[((i-1)*96+1):((i-1+min(days_until_next_reestimate,days_left_to_predict))*96)] <- naive_fc$value[((i-1)*96+1):((i-1+min(days_until_next_reestimate,days_left_to_predict))*96)]
      i <- i + days_until_next_reestimate
      # this loop is done, go back to beginning
      next
    }

    # if no holiday -> produce fc
    if (!(day_which_is_predicted_in_this_step %in% list_of_holidays )){
      out <- estimate_model_and_produce_fc(cleaned_training_set, model, period_1, period_2, aggregate_hours, fc_type,armethod)
      model <- out$model;
      relevant_forecast <- out$relevant_forecast

    } else{ # if no regular day look for last sunday
      # this procedure uses information not available in actual application if a monday is a holiday. FIX THIS.
      last_sunday <- floor_date(day_which_is_predicted_in_this_step, "week")
      if (last_sunday == day_which_is_predicted_in_this_step){
        last_sunday <- last_sunday - days(7)
      }
      last_sunday_in_df <- as.Date(df$timestamp) == last_sunday
      last_sunday_in_df <- lag(last_sunday_in_df, default = FALSE)
      ts_last_sunday <- df[last_sunday_in_df, ]
      if (nrow(ts_last_sunday) != 96) {
        print(nrow(ts_last_sunday))
        stop('something went wrong when looking for the last sunday. maybe the data is missing.')
      }
      relevant_forecast <- ts_last_sunday$value
    }

    day_ahead_prediction$value[((i-1)*96+1) : (i*96)] <- relevant_forecast
    i <- i+1
  }

  if (verbose) print('forecasting incrementally done')
  if (verbose) print('finished increm_day_ahead_ets_forecast')

  return(day_ahead_prediction)
}



cut_non_full_days <- function(df) {

  first_timestamp <- df %>% slice(1) %>% pull(timestamp)
  while (first_timestamp %>% hour() != 0 | first_timestamp %>% minute() != 15){
    df <- df %>% slice(-1)
    first_timestamp <- df %>% slice(1) %>% pull(timestamp)
  }
  last_timestamp <- df %>% slice(nrow(df)) %>% pull(timestamp)
  while (last_timestamp %>% hour() != 0 | last_timestamp %>% minute() != 0){
    df <- df %>% slice(-nrow(df))
    last_timestamp <- df %>% slice(nrow(df)) %>% pull(timestamp)
  }
  return(df)
}


determine_periods <- function(aggregate_hours) {
  period_1 <- 96
  period_2 <- 96*7
  if (aggregate_hours){
    period_1 <- period_1/aggregate_hours
    if (period_1 != floor(period_1)){
      stop("aggregate_hours has to be a divisor of 96")
    }
    period_2 <- period_2/aggregate_hours
  }
  return(list(period_1 = period_1, period_2 = period_2))
}

# helper function that takes a preexisting model and produces the one day-ahead forecast
# if no model is given, it is estimated
# this function only exists for better readability of the main file
estimate_model_and_produce_fc <- function(cleaned_training_set, model, period_1, period_2, aggregate_hours, fc_type, armethod) {

  vals <- cleaned_training_set$value
  if (aggregate_hours){ # aggregate
    vals <- colSums(matrix(vals, nrow=aggregate_hours))
  }
  # choose model
  if (fc_type == "tbats"){
    model <- tbats(vals, model = model)
    fc <- forecast(model, h= period_1*2)
  }else if (fc_type == "mult_dshw"){
    model <- mult_dshw(vals, model=model, period1=period_1, period2=period_2, armethod=armethod, h = period_1*2)
  }else if (fc_type == "additive_dshw"){
    model <- additive_dshw(vals, model=model, period1=period_1, period2=period_2, armethod=armethod, h = period_1*2)
  }else if (fc_type == "dshw_regular") {
    model <- dshw(vals, model=model, period1=period_1, period2=period_2, armethod=armethod, h = period_1*2)
  }else if (fc_type == "hw") {
    # Holt-Winter with a single seasonality,
    model <- mult_HW(vals, model=model, period2=period_2, armethod=armethod, h = period_1*2)
  } else if (fc_type == "96_simple_models" ){
    #(s)ets model for every qh
    stop("model not implemented")
  } else {
    stop("model not implemented")
  }
  if (fc_type %in% c("tbats")){
    relevant_forecast <- fc$mean[-(1:period_1)]
  }else{
    relevant_forecast <-  model$mean[-(1:period_1)]
  }
  #disaggregate
  if (aggregate_hours){
    relevant_forecast <- rep(relevant_forecast/aggregate_hours, each=aggregate_hours)
  }

  ## add. model sometimes produces neg. numbers
  relevant_forecast[relevant_forecast<0] <- 0

  return(list(model = model, relevant_forecast = relevant_forecast))

}

