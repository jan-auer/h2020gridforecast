# __Documentation for mapping_table_day_to_datetime ####
#' Mapping table between day to datetime.
#'
#' @format A data frame
#' \describe{
#'   \item{day}{day}
#'   \item{datetime}{datetime}
#' }
"mapping_table_day_to_datetime"

# CODE FOR GENERATING: mapping_table_datetime_to_day SAVED NOW IN THE DATA FOLDER!! ############################
#
# rm(list = ls())
#
# library(tidyverse)
# library(lubridate)
#
# seq_of_datetimes <- ymd_hms(seq(ymd_hms('2014-01-01 00:00:00'), ymd_hms('2017-01-01 00:00:00'), by = '15 min'))
#
# mapping_table_datetime_to_day <-
#   data_frame(timestamp = seq_of_datetimes) %>%
#   mutate(timestamp_new = ymd(substr(timestamp, 1, 10)))
#
# devtools::use_data(mapping_table_datetime_to_day, overwrite = TRUE)

# __Documentation for mapping_table_datetime_to_day ####
#' Mapping table between datetime and the corresponding day.
#' This mapping table is used to convert datetimes (with hour:min:sec) to dates.
#' It is used for code speed-up.
#'
#' Note that "2018-03-15 00:00:00" is converted to date "2018-03-15" even though the time stamp corresponds to the last quarter hour of the day "2018-03-14".
#' Usually, this mapping table is used after transforming the timestamp with "\code{mutate(timestamp = timestamp - minutes(15))}" and then grouping by obtained date.
#' One can search in R-Studio for its use with \code{Ctrl + Shift + F}.
#'
#' @format A data frame
#' \describe{
#'   \item{timestamp}{timestamp in datetime format}
#'   \item{timestamp_new}{timestamp in day format}
#' }
"mapping_table_datetime_to_day"


# CODE FOR GENERATING: mapping_table_datetime_to_day_used SAVED NOW IN THE DATA FOLDER!! ############################
# rm(list = ls())
#
# library(tidyverse)
# library(lubridate)
#
# seq_of_datetimes <- ymd_hms(seq(ymd_hms('2014-01-01 00:15:00'), ymd_hms('2017-01-01 00:00:00'), by = '15 min'))
#
# mapping_table_datetime_to_day_used <-
#   data_frame(timestamp = seq_of_datetimes) %>%
#   mutate(timestamp_new = timestamp -minutes(15)) %>%
#   mutate(timestamp_date = ymd(substr(timestamp_new, 1, 10))) %>%
#   select(-timestamp_new)
#
# devtools::use_data(mapping_table_datetime_to_day_used, overwrite = TRUE)

# __Documentation for mapping_table_datetime_to_day_used ####
#' Mapping table between datetime and the corresponding day.
#'
#' This mapping table is used to convert datetimes (with hour:min:sec) to dates.
#' Midnight is handled differently than in \link{mapping_table_datetime_to_day}!.
#' Here, it is taken into account that the time stamp "2018-03-15 00:00:00" actually belongs to "2018-03-14".
#' It is not necessary to first transform the timestamp with "\code{mutate(timestamp = timestamp - minutes(15))}", which makes the code faster.
#'
#' @format A data frame
#' \describe{
#'   \item{timestamp}{timestamp in datetime format}
#'   \item{timestamp_new}{timestamp in day format}
#' }
#' @seealso \link{mapping_table_datetime_to_day}
"mapping_table_datetime_to_day_used"





# CODE FOR GENERATING: mapping_table_postal_code_to_state & mapping_table_state_to_holiday SAVED NOW IN THE DATA FOLDER!! ############################

# rm(list = ls())
#
# library(tidyverse)
# library(lubridate)
# library(DT)
#
# holiday_DE <- read_csv2('../../input/holiday_data/feiertage_in_DE.csv')
# names(holiday_DE) <- c('state', 'state_abbreviation', 'date', 'name_of_holiday', 'missing')
# holiday_DE <- holiday_DE %>% select(state, state_abbreviation, date, name_of_holiday)
#
# postal_code_mapping_table <- read_tsv('../../input/holiday_data/postleitzahlen_feiertage_in_DE_v10.txt',
#                                       col_names = c('postal_code', 'city', 'some_numer', 'more_city_name', 'another_number', 'state'))
#
# mapping_table_postal_code_to_state <- postal_code_mapping_table %>% select(postal_code, state) %>% unique()
# # these were missing:
# missing_postal_codes <- data_frame()
# missing_postal_codes <- bind_rows(missing_postal_codes, data_frame(postal_code = '55252', state = 'Hessen'))
# missing_postal_codes <- bind_rows(missing_postal_codes, data_frame(postal_code = '16227', state = 'Brandenburg'))
# missing_postal_codes <- bind_rows(missing_postal_codes, data_frame(postal_code = '06861', state = 'Sachsen-Anhalt'))
# missing_postal_codes <- bind_rows(missing_postal_codes, data_frame(postal_code = '14947', state = 'Brandenburg'))
# missing_postal_codes <- bind_rows(missing_postal_codes, data_frame(postal_code = '99098', state = 'Thüringen'))
# missing_postal_codes <- bind_rows(missing_postal_codes, data_frame(postal_code = '99820', state = 'Thüringen'))
#
# mapping_table_postal_code_to_state <- bind_rows(mapping_table_postal_code_to_state, missing_postal_codes)
#
# mapping_table_postal_code_to_state <-
#   mapping_table_postal_code_to_state %>%
#   filter(!( postal_code == '19357' & state == 'Mecklenburg-Vorpommern') )
#
# mapping_table_postal_code_to_state <- mapping_table_postal_code_to_state %>% group_by(postal_code) %>% slice(1) %>% ungroup()
#
# mapping_table_state_to_holiday <- holiday_DE %>% select(state, date) %>% unique()
#
# devtools::use_data(mapping_table_postal_code_to_state, mapping_table_state_to_holiday, overwrite = TRUE)

# __Documentation for mapping_table_postal_code_to_state and mapping_table_state_to_holiday ####

#' Mapping table between postal codes and states of Germany.
#'
#' A data set containing all the necessary information to
#' map a postal code to its state in Germany.
#'
#' @format A data frame
#' \describe{
#'   \item{postal_code}{postal code}
#'   \item{state}{one of the 16 states in Germany}
#' }
"mapping_table_postal_code_to_state"


#' Mapping table between each state and its holidays in Germany.
#'
#' A data set containing all the necessary information to
#' map a German state to its holidays.
#'
#' @format A data frame
#' \describe{
#'   \item{state}{one of the 16 states in Germany}
#'   \item{date}{the date of the holiday}
#' }
"mapping_table_state_to_holiday"

# CODE FOR GENERATING: mapping_table_state_to_shifted_holidays SAVED NOW IN THE DATA FOLDER!! ############################

# rm(list = ls())
#
# library(tidyverse)
# library(lubridate)
# library(EWEPackage)
#
# # little helper fun that maps a day to all its timestamps
# day_to_timestamp <- function(day) ymd_hms(seq(ymd_hms(paste(day,'00:00:00')), ymd_hms(paste(day,'23:45:00')), by = '15 min'))
#
#
# # This sequence of dates should be enough for now
# forecast_period <- seq(ymd('2014-02-01'), ymd('2017-01-01'), by = 'day')
#
# all_states <- unique(mapping_table_state_to_holiday$state)
# all_states <- c(all_states, 'all')
#
# mapping_table_state_to_shifted_holidays <- data_frame()
#
# for (i in seq_along(all_states)){
#
#   current_state <- all_states[i]
#
#   print(current_state)
#
#   holidays <- get_holidays_from_postal_code(current_state)
#
#   shifted_days <- get_shifted_dates_using_holiday_data_helper(current_state, forecast_period)
#
#   shifted_days <-
#     shifted_days %>%
#     mutate(original_timestamp = map(original_day, day_to_timestamp),
#            shifted_timestamp = map(shifted_day, day_to_timestamp))
#
#   shifted_timestamps <-
#     shifted_days %>%
#     select(original_timestamp, shifted_timestamp) %>%
#     unnest()
#
#   shifted_days <-
#     shifted_days %>%
#     select(original_day, shifted_day)
#
#   mapping_table_state_to_shifted_holidays <- bind_rows(mapping_table_state_to_shifted_holidays,
#                                                        data_frame(state = current_state,
#                                                                   shifted_days = list(shifted_days),
#                                                                   shifted_timestamps = list(shifted_timestamps)))
#
# }
#
# # quick test if all shifted dates are strctly before the original date
# tmp <- mapping_table_state_to_shifted_holidays %>% select(shifted_days) %>% unnest() %>% mutate( test = original_day > shifted_day ) %>% pull(test) %>% sum
# if( tmp != nrow(mapping_table_state_to_shifted_holidays %>% select(shifted_days) %>% unnest()) ) {print('ERROR SOME SHIFTED DAYS ARE NOT STRIKTLY BEFORE THE ORIGINAL DATE')}
# tmp <- mapping_table_state_to_shifted_holidays %>% select(shifted_timestamps) %>% unnest() %>% mutate( test = original_timestamp > shifted_timestamp ) %>% pull(test) %>% sum
# if( tmp != nrow(mapping_table_state_to_shifted_holidays %>% select(shifted_timestamps) %>% unnest()) ) {print('ERROR SOME SHIFTED TIMESTAMPS ARE NOT STRIKTLY BEFORE THE ORIGINAL DATE')}
#
# devtools::use_data(mapping_table_state_to_shifted_holidays, overwrite = TRUE)

# __Documentation for mapping_table_state_to_shifted_holidays ####
#' Mapping table between each state and the table of shifted dates according to
#' the holidays in the corresponding state.
#'
#' A data set containing all the necessary information to map a German state to
#' a data frame of shifted dates according to the methodology in
#' \link{get_shifted_dates_using_holiday_data_helper}.
#'
#' @format A data frame \describe{
#' \item{state}{one of the 16 states in Germany}
#'   \item{shifted_days}{list column with mapping table of original date to
#'   shifted date, accounting for holiday effects}
#'   \item{shifted_timestamps}{list column with mapping table of original
#'   timestamp to shifted timestamp, accounting for holiday effects} }
"mapping_table_state_to_shifted_holidays"






# CODE FOR GENERATING: mapping_table_state_to_shifted_holidays_including_bridging_days SAVED NOW IN THE DATA FOLDER!! ############################

# rm(list = ls())
#
# library(tidyverse)
# library(lubridate)
# library(EWEPackage)
#
# # little helper fun that maps a day to all its timestamps
# day_to_timestamp <- function(day) ymd_hms(seq(ymd_hms(paste(day,'00:00:00')), ymd_hms(paste(day,'23:45:00')), by = '15 min'))
#
#
# # This sequence of dates should be enough for now
# forecast_period <- seq(ymd('2014-02-01'), ymd('2017-01-01'), by = 'day')
#
# all_states <- unique(mapping_table_state_to_holiday$state)
# all_states <- c(all_states, 'all')
#
# mapping_table_state_to_shifted_holidays_including_bridging_days <- data_frame()
#
# for (i in seq_along(all_states)){
#
#   current_state <- all_states[i]
#
#   print(current_state)
#
#   holidays <- get_holidays_from_postal_code(current_state)
#
#   shifted_days <- get_shifted_dates_using_holiday_data_helper(current_state, forecast_period,
#                                                               account_for_bridging_days = TRUE)
#
#   shifted_days <-
#     shifted_days %>%
#     mutate(original_timestamp = map(original_day, day_to_timestamp),
#            shifted_timestamp = map(shifted_day, day_to_timestamp))
#
#   shifted_timestamps <-
#     shifted_days %>%
#     select(original_timestamp, shifted_timestamp) %>%
#     unnest()
#
#   shifted_days <-
#     shifted_days %>%
#     select(original_day, shifted_day)
#
#   mapping_table_state_to_shifted_holidays_including_bridging_days <- bind_rows(mapping_table_state_to_shifted_holidays_including_bridging_days,
#                                                        data_frame(state = current_state,
#                                                                   shifted_days = list(shifted_days),
#                                                                   shifted_timestamps = list(shifted_timestamps)))
#
# }
#
# # quick test if all shifted dates are strctly before the original date
# tmp <- mapping_table_state_to_shifted_holidays_including_bridging_days %>% select(shifted_days) %>% unnest() %>% mutate( test = original_day > shifted_day ) %>% pull(test) %>% sum
# if( tmp != nrow(mapping_table_state_to_shifted_holidays_including_bridging_days %>% select(shifted_days) %>% unnest()) ) {print('ERROR SOME SHIFTED DAYS ARE NOT STRIKTLY BEFORE THE ORIGINAL DATE')}
# tmp <- mapping_table_state_to_shifted_holidays_including_bridging_days %>% select(shifted_timestamps) %>% unnest() %>% mutate( test = original_timestamp > shifted_timestamp ) %>% pull(test) %>% sum
# if( tmp != nrow(mapping_table_state_to_shifted_holidays_including_bridging_days %>% select(shifted_timestamps) %>% unnest()) ) {print('ERROR SOME SHIFTED TIMESTAMPS ARE NOT STRIKTLY BEFORE THE ORIGINAL DATE')}
#
# devtools::use_data(mapping_table_state_to_shifted_holidays_including_bridging_days, overwrite = TRUE)


# __Documentation for mapping_table_state_to_shifted_holidays_including_bridging_days ####

#' Mapping table between each state and the table of shifted dates according to the holidays and bridging days in the corresponding state.
#'
#' A data set containing all the necessary information to
#' map a German state to a data frame of shifted dates according to
#' the methodology in \link{get_shifted_dates_using_holiday_data_helper}.
#'
#' @format A data frame
#' \describe{
#'   \item{state}{one of the 16 states in Germany}
#'   \item{shifted_days}{list column with mapping table of original date
#'   to shifted date, accounting for holiday effects and bridging days}
#'   \item{shifted_timestamps}{list column with mapping table of
#'   original timestamp to shifted timestamp, accounting for holiday effects and bridging days}
#' }
"mapping_table_state_to_shifted_holidays_including_bridging_days"



# CODE FOR GENERATING: dummies_listcol (Dummies for Bank Holidays, Bridging Days, and School Holidays) ############################
# 1) get states
# 2) generate dummies for holidays for each state
# 3) generate dummies for bridging days for each state
#
# library(tidyverse)
# library(stringr)
#
# my_states <- mapping_table_postal_code_to_state %>% select(state) %>% unique() %>% as_data_frame
# timestamp()
# dummies_listcol <- my_states %>%
#   mutate(dummy_holidays = map(state, ~create_holiday_dummy(.x, date_end = lubridate::ymd("2017-01-01"), quarter_hour = TRUE))) %>%
#   mutate(dummy_bridgingdays = map(state, ~create_bridgingday_dummy(.x, date_end = lubridate::ymd("2017-01-01"), quarter_hour = TRUE)))
# timestamp()
#
# # __Generate School holidays dummies and left-join them along "state" ####
# # Import
# holidays_school <- read_delim("../../input/holiday_data/schulferien.csv",
#                               ";", escape_double = FALSE, col_types = cols(DATUM = col_date(format = "%d.%m.%Y"),
#                                                                            WERT = col_logical()), trim_ws = TRUE)
# holidays_school <- holidays_school %>% rename(state_id = ZRD_ID,
#                                               timestamp = DATUM,
#                                               value = WERT,
#                                               status_ext = STATUS_EXT)
#
# # Check start and end dates:
# # Problem 1: For all states, the dummy start with 02 Jan 2014, not 01 Jan 2014.
# # Problem 2: For one state, 02 Jan 2017 is included as well.
#
#
# # Solve problems
# # Problem 1: For every state, add 01 Jan 2014 as school holiday
# # Problem 2: Delete 02 Jan 2017 for this one particular state
#
# # Add rows
# new_rows <- holidays_school %>%
#   filter(timestamp == ymd("2014-01-02")) %>%
#   mutate(timestamp = ymd("2014-01-01"))
#
# holidays_school <- holidays_school %>%
#   bind_rows(new_rows)
#
# # Delete timestamp at 02 Jan 2017
# holidays_school <- holidays_school %>%
#   filter(timestamp <= ymd("2017-01-01")) %>%
#   arrange(state_id, timestamp)
#
#
# # status_ext?
# holidays_school <- holidays_school %>% select(-status_ext)
#
# # Add names of states from "stammdaten_schulferien"
# holidays_school_masterdata <- read_delim("../../input/holiday_data/schulferien_stammdaten.csv",
#                                          ";", escape_double = FALSE, trim_ws = TRUE)
# holidays_school_masterdata <- holidays_school_masterdata %>%
#   rename(state_id = `Zrd-ID`,
#          state = Name)
# holidays_school <- left_join(holidays_school, holidays_school_masterdata, by = "state_id") %>%
#   select(-state_id) %>%
#   dplyr::rename(day = timestamp) %>%
#   dplyr::left_join(mapping_table_day_to_datetime, by = "day") %>%
#   dplyr::select(state, datetime, value) %>%
#   dplyr::rename(timestamp = datetime) %>%
#   tidyr::unnest() %>%
#   dplyr::select(state, timestamp, value) %>%
#   group_by(state) %>% nest(.key = "dummy_holidays_school")
#
# dummies_listcol <- dummies_listcol%>% left_join(holidays_school, by = "state")
# devtools::use_data(dummies_listcol, overwrite = TRUE)



# __Documentation of holiday and bridging day dummies ####

#' Data_frame of list-columns with holiday and bridging day dummies for each state
#'
#' This dataframe is important due to performance issues.
#'
#' @format A data frame with columns
#' \describe{
#'   \item{state}{String containing one of 16 German states}
#'   \item{dummy_holidays}{data_frame in the generic format with columns \code{timestamp} and \code{value}. Contains dummy for holidays.}
#'   \item{dummy_bridgingdays}{data_frame in the generic format with columns \code{timestamp} and \code{value}. Contains dummy for bridging days.}
#'   \item{dummy_holidays_school}{data_frame in the generic format with columns \code{timestamp} and \code{value}. Contains dummy for school holidays.}
#' }
"dummies_listcol"


# # CODE FOR GENERATING: Dummies for Weekdays ##############################################
# library(tidyverse)
# library(lubridate)
#
# # 1) get column with timestamp
# # 2) create model.matrix (no intercept) and rename columns
# # 3) save it
#
# # ad 1)
# start and end date
# date_start <- lubridate::ymd("2014-01-01")
# date_end <- lubridate::ymd("2017-01-01")
#
# # daily timestamps
# my_timestamp_qhour <- mapping_table_day_to_datetime %>%
#   filter(day >= date_start, day <= date_end) %>%
#   transmute(timestamp = datetime) %>%  unnest() %>%
#   mutate(timestamp_shifted = timestamp - lubridate::minutes(15))
#
#
# my_timestamp_daily <- dplyr::data_frame(timestamp = seq(from = date_start, to = date_end, by = "1 day"))
#
# # ad 2)
# # add weekday as factor
# dummy_wday_factor <- my_timestamp_qhour %>% mutate(wday = as.factor(lubridate::wday(timestamp_shifted))) %>%
#   select(-timestamp_shifted)
#
# # model matrix
# new_names <- paste0("dummy_", c("sun", "mon", "tue", "wed", "thu", "fri", "sat"))
# my_dummy <- model.matrix(~dummy_wday_factor$wday -1) %>% as_data_frame() %>% mutate_all(as.integer) %>% setNames(new_names)
#
# # finish off
# dummies_wday <- bind_cols(dummy_wday_factor %>% select(timestamp), my_dummy)
#
# # ad 3)
# # save("dummies_wday", file = "../../input/other_data/dummies_wday.rda")
# # save("dummies_wday", file = "data/dummies_wday.rda")
# devtools::use_data(dummies_wday, overwrite = TRUE)

# __Documentation of weekdays dummies ###########################################################################################################

#' Data_frame with columns \code{timestamp} and one for each day of the week.
#'
#' @format A data frame with columns
#' \describe{
#'   \item{timestamp}{Datetime vector. Starting on 01 Jan 2014 and ending on 31 Dec 2018}
#'   \item{dummy_sun}{Integer vector. One if it's a Sunday, zero otherwise. data_frame in the generic format with columns \code{timestamp} and \code{value}. Contains dummy for holidays.}
#'   \item{dummy_mon}{Same as \code{dummy_sun}.}
#'   \item{dummy_tue}{Same as \code{dummy_sun}.}
#'   \item{dummy_wed}{Same as \code{dummy_sun}.}
#'   \item{dummy_thu}{Same as \code{dummy_sun}.}
#'   \item{dummy_fri}{Same as \code{dummy_sun}.}
#'   \item{dummy_sat}{Same as \code{dummy_sun}.}
#' }
"dummies_wday"

