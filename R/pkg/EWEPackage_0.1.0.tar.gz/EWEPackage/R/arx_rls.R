#' Automated Recursive Least Squares with interaction terms (RLS)
#'
#' For every 15 min period, choose the best model according to BIC (training data = 2 years) and use it to forecast.
#'
#' Similar to \link{forecast_rls}. However, models are created differently (using \link{get_interaction_grid}).
#'
#' @inheritParams create_arx_regression
#' @param from Start of forecasting period
#' @param to End of forecasting period
#' @param use_cpp Boolean. Default set to TRUE. If FALSE, the (equivalent) R code is used (instead of Rcpp).
#'
#' @return Forecast in the usual data_frame format (columns timestamp and value)
#' @export
#'
forecast_rls_interaction <- function(my_df_load,
                                     my_postal_code,
                                     from,
                                     to,
                                     use_cpp = TRUE) {

  from <- dplyr::enquo(from)
  to <- dplyr::enquo(to)

  sliced_df <- create_arx_regression(my_df_load = my_df_load,
                                     my_postal_code = my_postal_code,
                                     my_dummies_wday_hb = list(c(1,7), c(2, 3, 4, 5, 6), 8, 9, c(2, 3), c(4,5,6)),
                                     my_lags = dplyr::tibble(lag_day = c(2, 7), lag_q_hour = 0),
                                     data_driven = FALSE)

  sliced_df <- sliced_df %>% rowid_to_column()

  model_formulas <- get_interaction_formulas()

  sliced_df <- sliced_df %>%
    mutate(result_list = map(univ_regr,
                             ~arx_rls_interaction_vectorized(.x, model_formulae = model_formulas, end_of_train = 730)))

  sliced_df <- sliced_df %>%
    mutate(df_prediction = map(result_list, ~ .x$df_prediction %>% .[[1]])) %>%
    mutate(fev_honest = map_dbl(result_list, ~ .x$fev_honest %>% .[[1]])) %>%
    mutate(formula = map_chr(result_list, ~ .x$formula %>% .[[1]])) %>%
    select(-result_list)

  out <- sliced_df %>%
    select(df_prediction) %>%
    unnest() %>%
    arrange(timestamp) %>%
    filter(timestamp >= rlang::UQ(from))

  return(out)

}

#' Automated Recursive Least Squares (RLS)
#'
#' For every 15 min period, choose the best model according to BIC (training data = 2 years) and use it to forecast.
#'
#' @inheritParams create_arx_regression
#' @param from Start of forecasting period
#' @param to End of forecasting period
#' @param model_complexity Integer value. 1 corresponds to low complexity (15 dummy-lag combos), 3 to high complexity (90 dummy-lag combos).
#'   It determines the number of dummy/lag combinations considered.
#'   Default set to 2 (42 dummy-lag combos).
#' @param use_cpp Boolean. Default set to TRUE. If FALSE, the (equivalent) R code is used (instead of Rcpp).
#' @param debug_mode Boolean. Default set to FALSE. If TRUE, more info is printed.
#'
#' @return Forecast in the usual data_frame format (columns timestamp and value)
#' @export
#'
forecast_rls <- function(my_df_load,
                         my_postal_code,
                         from,
                         to,
                         model_complexity = 1,
                         use_cpp = TRUE,
                         debug_mode = FALSE) {

  if (debug_mode) {
    print(my_postal_code)
  }
    from <- dplyr::enquo(from)
    to <- dplyr::enquo(to)

    # sliced_df <- create_arx_regression(my_df_load = my_df_load,
    #                                    my_postal_code = my_postal_code,
    #                                    my_dummies_wday_hb = list(1, 2, 3, 4, 5, 6, 7, 8, 9),
    #                                    my_lags = dplyr::tibble(lag_day = c(2, 3, 4, 7, 14, 21), lag_q_hour = 0),
    #                                    data_driven = data_driven)



    # lags inputs for pmap (choose best BIC)
    ll_tmp <- get_model_grid(model_complexity = model_complexity, school = FALSE)
    all_dummies_grid <- ll_tmp[["all_dummies_grid"]]
    all_lags_grid <- ll_tmp[["all_lags_grid"]]
    rm(ll_tmp)

    # Here is the main action ####

    # __HUGE AND SLOW: create univariate models for all models ####
    out <- all_lags_grid %>%
        dplyr::mutate(model_id = 1:nrow(.)) %>%
        dplyr::mutate(data_all = purrr::map2(all_dummies_grid, my_lags,
                                             ~ create_arx_regression(my_df_load = my_df_load,
                                                                     my_postal_code = my_postal_code,
                                                                     my_dummies_wday_hb = .x,
                                                                     my_lags = .y,
                                                                     data_driven = FALSE)))
    # __unnest and add an ID for each quarter hour (is this error prone?) ####
    out <- out %>%
        tidyr::unnest(data_all) %>%
        dplyr::group_by(model_id) %>%
        dplyr::mutate(q_hour_id = 1:n()) %>%
        dplyr::ungroup()

    # __that's slow too ####
    out <- out %>%
      mutate(end_of_train_arg = map_dbl(univ_regr, ~ which(lubridate::as_date(.x$timestamp - lubridate::minutes(15)) == lubridate::as_date(rlang::eval_tidy(from))) -  1))

    out <- out %>%
      mutate(prediction_list = map2(univ_regr, end_of_train_arg, ~ arx_rls(.x, end_of_train = .y, use_cpp = use_cpp))) %>%
      mutate(df_prediction = map(prediction_list, "df_prediction")) %>%
      mutate(fev_honest = map_dbl(prediction_list, "fev_honest"))

    out <- out %>%
      select(-prediction_list) %>%
      group_by(q_hour_id) %>%
      slice(which.min(fev_honest)) %>%
      ungroup()

    out <- out %>%
      tidyr::unnest(df_prediction) %>%
      dplyr::select(timestamp, value) %>%
      dplyr::arrange(timestamp) %>%
      dplyr::filter(timestamp >= rlang::UQ(from) & timestamp <= rlang::UQ(to))

    return(out)

}

#' Non-vectorized RLS preparation function for interactions
#'
#' comment_bf: docu rudimentary
#'
#' @param df A tibble with columnns (timestamp, value) the (untransformed) full set of dummies, all lags.
#'   This functions transforms and selects dummies, selects lags, and cleans NAs etc
#' @param model_formula. Character containing one formula, specifying a particular model to be estimated for interaction dummies.
#' @param end_of_train Integer. Index characterizing the end of the training period.
#'   Important for calculating the honest prediction error.
#' @param use_cpp. Boolean. Default set to TRUE. If FALSE, the (equivalent) R code is used (instead of Rcpp).
#'
#' @return Tibble containing the prediction with optimal (according to honest prediction error) forgetting factor.
#'   Variables in tibble are (timestamp, value).
#' @export
arx_rls_interaction <- function(df, model_formula, end_of_train, use_cpp = TRUE){

  if (length(model_formula) != 1) {
    stop("There should only be one model_formula.")
  }

  n_obs <- nrow(df)

  X_mat <- model.matrix(as.formula(model_formula), data = df)
  n_na <- n_obs - nrow(X_mat)

  y_mat <- df %>% slice(-(1:n_na)) %>% select(value) %>% as.matrix()

  # For one model do RLS
  if (use_cpp == TRUE) {
    tt <- max(21, ncol(X_mat)*3)
    tmp <- arx_rls_core_cpp(y_mat, X_mat, n_init = tt, end_of_train = as.integer(end_of_train))
    tmp$y_pred <- c(tmp$y_pred)
    tmp$fev_honest <- c(tmp$fev_honest)
  } else {
    tmp <- arx_rls_core(y_mat, X_mat, end_of_train = end_of_train)
  }


  if (n_na > 0) {
    df_prediction <- tibble(timestamp = df$timestamp,
                            value = c(rep(NA, n_na),
                                      tmp$y_pred))
  } else {
    df_prediction <- tibble(timestamp = df$timestamp,
                            value = tmp$y_pred)
  }

  return(list(df_prediction = df_prediction,
              fev_honest =   tmp$fev_honest))
}

#' RLS preparation function for interactions (vectorized)
#'
#' comment_bf: docu rudimentary
#'
#' @inheritParams arx_rls_interaction
#' @param model_formulae Character vector containing (possibly many) formulas, specifying differend model to be estimated for interaction dummies.
#'
#' @return Tibble containing the prediction which is optimal among all given models contained in \code{model_formulae} and has the optimal (according to honest prediction error) forgetting factor.
#'   Variables in tibble are (timestamp, value).
#' @export
arx_rls_interaction_vectorized <- function(df, model_formulae, end_of_train, use_cpp = TRUE){

  df_best_model <- model_formulae %>% as_tibble() %>% rename(formula = value) %>%
    mutate(result_list = map(formula, ~ arx_rls_interaction(df, .x, end_of_train = end_of_train, use_cpp = use_cpp))) %>%
    mutate(df_prediction = map(result_list, "df_prediction")) %>%
    mutate(fev_honest = map_dbl(result_list, "fev_honest")) %>%
    select(-result_list)

  df_best_model <- df_best_model %>%
    filter(fev_honest == min(fev_honest))

  if (nrow(df_best_model) != 1) {
    warning("There should be precisely one model that has the minimal honest prediction error (for a particular quarter hour). The first one is chosen.")
      df_best_model <- df_best_model %>% slice(1)
  }



  # comment_bf: add the chosen forgetting factor
  return(list(df_prediction = df_best_model$df_prediction,
              fev_honest = df_best_model$fev_honest,
              formula = df_best_model$formula))


}


#' RLS preparation function
#'
#' comment_bf: docu rudimentary
#'
#' @param df A tibble with columnns (timestamp, value) the (untransformed) full set of dummies, all lags.
#'   This functions transforms and selects dummies, selects lags, and cleans NAs etc
#' @param end_of_train Integer. Index characterizing the end of the training period.
#'   Important for calculating the honest prediction error.
#' @param use_cpp. Boolean. Default set to TRUE. If FALSE, the (equivalent) R code is used (instead of Rcpp).
#'
#' @return Tibble containing the prediction with optimal (according to honest prediction error) forgetting factor.
#'   Variables in tibble are (timestamp, value).
#' @export
arx_rls <- function(df, end_of_train, use_cpp = TRUE){

  n_obs <- nrow(df)

  df_noNAs <- df %>% filter_all(all_vars(!is.na(.)))

  n_na <- n_obs - nrow(df_noNAs)

  y_mat <- df_noNAs %>% select(value) %>% as.matrix()
  X_mat <- df_noNAs %>% select(-c(timestamp, value)) %>% as.matrix()

  # For one model do RLS
  if (use_cpp == TRUE){
    tt <- max(21, ncol(X_mat)*3)
    tmp <- arx_rls_core_cpp(y_mat, X_mat, n_init = tt, end_of_train = as.integer(end_of_train))
    tmp$y_pred <- c(tmp$y_pred)
    tmp$fev_honest <- c(tmp$fev_honest)
  } else {
    tmp <- arx_rls_core(y_mat, X_mat, end_of_train = end_of_train)
  }


  if(n_na > 0){
    df_prediction <- tibble(timestamp = df$timestamp,
                            value = c(rep(NA, n_na),
                                      tmp$y_pred))
  } else {
    df_prediction <- tibble(timestamp = df$timestamp,
                            value = tmp$y_pred)
  }


  return(list(df_prediction = df_prediction,
              fev_honest =   tmp$fev_honest))
}



#' RLS core function
#'
#' comment_bf: docu rudimentary
#'
#' @param y Vector of doubles. NAs must be removed (not checked)
#' @param X Matrix of doubles. dimension = (length(y) x maximal number of regressors)
#' @param n_init Integer. Number of observations used for initial estimate of beta.
#'   If no value provided, at least 21 observations (3 weeks) or 3 times the number of regressors is used.
#' @param end_of_train Integer. Index specifying the end of the training set. (Afterwards the forecasting period starts.)
#'   Important for calculating the honest prediction error (otherwise it would not be out-of-sample...).
#'   comment_bf: If one wants to use arx_rls_core() outside the automated forecasting framework,
#'   set \code{end_of_train} to \code{length(y)}.
#'
#' @return List containing
#'   predictions \code{y_pred} (vector of same length as input y),
#'   honest prediction error \code{fev_honest} (calculated from \code{end_of_train - n_init} observations).
#'
#' @export
arx_rls_core <- function(y, X, n_init = NULL, end_of_train = NULL){

  # Number of observations for initial estimator should be at least 3 weeks or 3 times the number of regressors
  if (is.null(n_init)) {
    n_init <- max(3*dim(X)[2], 21)
  }

  # Check: End of training period
  if (is.null(end_of_train) || n_init >= end_of_train) {
    stop("arx_rls_core(): The end of the training data set must be specified and
         larger than the integer specifying the initial estimation period.")
  }

  # forgetting factors
  r <- c(0.9,
         0.9500000, 0.9750000, 0.9875000, 0.9937500, 0.9968750, 0.9984375, # cumsum(0.5^(1:6)/10)+0.9,
         1)

  # initial estimator for beta
  y_init <- y[1:n_init, , drop = FALSE]
  X_init <- X[1:n_init, , drop = FALSE]

  P <- solve(t(X_init) %*% X_init)
  beta <- P %*% t(X_init) %*% y_init


  # RLS, see Young page 55
  n_obs <- length(y)
  y_pred <- vector("numeric", n_obs)
  y_pred[1:n_init] <- NA
  fe_honest <- vector("numeric", n_obs)
  fev_honest <- vector("numeric", length(r))

  for (i in seq_along(r)) {

    for (j in (n_init + 1):n_obs) {
      x <- X[j, , drop = FALSE]
      g <- P %*% t(x) %*% (r[i] + x %*% P %*% t(x))^(-1)

      y_pred[j] <- x %*% beta
      fe_honest[j] <- y[j] - y_pred[j]

      beta <- beta + g %*% fe_honest[j]
      P <- 1/r[i] * ( P - g %*% x %*% P )
    }

    fev_honest[i] <- mean(fe_honest[(n_init+1):end_of_train]^2)

    if (i == 1){
      fev_honest_final <- fev_honest[i]
      y_pred_final <- y_pred
    } else if ( fev_honest[i] < fev_honest[i-1] ){
      fev_honest_final <- fev_honest[i]
      y_pred_final <- y_pred
    }
  }

  r_final <- r[which.min(fev_honest)]

    return(list( y_pred = y_pred_final,
                 fev_honest = fev_honest_final,
                 min_forgetting = r_final))
}

# Rcpp roxygen stuff ####
#' @useDynLib EWEPackage
#' @importFrom Rcpp sourceCpp
NULL


