#' mxnet cross validation helper.
#'
#' Helper function to perform cross validation.
#'
#' This function performs standard cross validation to select the optimal number
#' of training rounds using \link{mx.model.FeedForward.create}.
#'
#' @param net neural network specification.
#' @param train_x X of training.
#' @param train_y Y of training.
#' @param number_of_folds Number of folds to use for cross validation. Defaults
#'   to 5.
#' @param verbose Print during cross validation.
#' @param verbose_mxnet Print during mxnet training.
#' @param ... other parameters passed to \link{mx.model.FeedForward.create}
#'
#' @importFrom caret createFolds
#' @importFrom mxnet mx.model.FeedForward.create
#' @importFrom mxnet mx.io.arrayiter
#' @importFrom mxnet mx.cpu
#'
#' @export

mx.crossvalidation.helper <- function(net, train_x, train_y, number_of_folds = 5, verbose = TRUE, verbose_mxnet = FALSE, ...){

  dots <- list(...)
  if (verbose) message(paste('Optimizer: ', dots$optimizer))

  # allocate vector containing the best rounds for each fold.
  best_rounds <- c()
  validation_errors <- c()

  # create folds
  folds <- createFolds(1:nrow(train_y), k = number_of_folds, list = TRUE)

  # run through folds (this could be parallelized)
  for (current_fold in 1:number_of_folds){

    if (verbose) message(paste('Starting Fold', current_fold))

    # get current train/validation split
    train_validation_split <- folds[[current_fold]]

    # set up train and validation sets
    val_x_fold   <- train_x[-train_validation_split,]
    val_y_fold   <- train_y[-train_validation_split,]
    train_x_fold <- train_x[ train_validation_split,]
    train_y_fold <- train_y[ train_validation_split,]

    # creat mxnet train and validation iterators
    trainIter <- mx.io.arrayiter(data = t(train_x_fold), label = t(train_y_fold))
    valIter   <- mx.io.arrayiter(data = t(val_x_fold) , label = t(val_y_fold))

    # creat mxnet logger for early stopping
    my_logger <- mx.metric.logger.early.stopping$new()

    # creat model of current fold
    model <- mx.model.FeedForward.create(net,
                                         X = trainIter,
                                         eval.data = valIter,
                                         ctx = mx.cpu(sample(1:1000, 1)),
                                         verbose = verbose_mxnet,
                                         num.round = 2000,
                                         array.batch.size = 128,
                                         array.layout = 'rowmajor',
                                         eval.metric = mx.metric.mae.ewe,
                                         epoch.end.callback = mx.callback.log.train.metric.early.stopping(1, my_logger, early.stopping.round = 200),
                                         ...)

    if (verbose) message(paste('Fold', current_fold, 'of', number_of_folds, 'done. Best round', my_logger$best_round, 'with validation score', min(my_logger$eval)))
    best_rounds <- c(best_rounds, my_logger$best_round)
    validation_errors <- c(validation_errors,  min(my_logger$eval))

  }

  # get final number of training rounds
  final_number_of_training_rounds <- round(mean(best_rounds))
  if(verbose) message(paste('Final model will train for', final_number_of_training_rounds))

  # set up final training iterator
  trainIter <- mx.io.arrayiter(data = t(train_x), label = t(train_y))

  # train final model
  model <- mx.model.FeedForward.create(net,
                                       X = trainIter,
                                       ctx = mx.cpu(sample(1:1000, 1)),
                                       verbose = verbose_mxnet,
                                       num.round = final_number_of_training_rounds,
                                       array.batch.size = 128,
                                       array.layout = 'rowmajor',
                                       eval.metric = mx.metric.mae.ewe,
                                       ...)

  if (verbose){

    message('####################################################################################################################################')
    message('##                                               FOLLOWING MODEL FITTED                                                           ##')
    message('####################################################################################################################################')
    message(net$field('arguments'))
    message('####################################################################################################################################')
    message('##                                              AVERAGE VALIDATION SCORE                                                         ##')
    message(paste('##                                                       ', round(mean(validation_errors), 2), '                                                                ##'))
    message('####################################################################################################################################')
    message('####################################################################################################################################')

  }

  return(list(model = model, final_number_of_training_rounds = final_number_of_training_rounds, validation_errors = mean(validation_errors)))

}


#' mxnet cross validation
#'
#' Function to perform cross validation over differnt network architectures.
#'
#' This function is built on top of \link{mx.crossvalidation.helper}. It runs
#' over different neural network models and performs cross validation in order
#' to find the optimal number of training rounds. Among others, the neural
#' network structure, the fitted models and the validation errors are returned.
#'
#' @param net list of neural network specification.
#' @param train_x X of training.
#' @param train_y Y of training.
#' @param number_of_folds Number of folds to use for cross validation. Defaults
#'   to 5.
#' @param verbose Print during cross validation.
#' @param verbose_mxnet Print during mxnet training.
#' @param additional_model_slug Additional model slug.
#' @param ... other parameters passed to \link{mx.crossvalidation.helper}
#'
#' @import dplyr
#'
#' @export


mx.crossvalidation <- function(net, train_x, train_y, number_of_folds = 5, verbose = TRUE, verbose_mxnet = FALSE, additional_model_slug = '',...){

  if(!is.list(net)){
    net <- list(net)
  }

  model_list <- list()
  validation_errors <- c()
  final_number_of_training_rounds <- c()

  # run over networks
  for (current_net_idx in seq_along(net)){

    if (verbose) message(paste('FIITTING NETWORK NUMBER', current_net_idx, 'OUT OF A TOTAL OF', length(net), 'NETWORKS'))

    # perform standard cross validation
    out <- mx.crossvalidation.helper(net = net[[current_net_idx]],
                                     train_x = train_x,
                                     train_y = train_y,
                                     number_of_folds = number_of_folds,
                                     verbose = verbose,
                                     verbose_mxnet = verbose_mxnet,
                                     ...)

    # append useful information
    model_list <- c(model_list, list(out$model))
    final_number_of_training_rounds <- c(final_number_of_training_rounds, out$final_number_of_training_rounds)
    validation_errors <- c(validation_errors, out$validation_errors)

  }

  # construct result data frame
  result_df <- data_frame(network = net,
                          model = model_list,
                          model_slug = paste0(additional_model_slug, names(net)),
                          final_number_of_training_rounds = final_number_of_training_rounds,
                          validation_error = validation_errors)

}

