#' Automated ARX model
#'
#' For every 15 min period, choose the best model according to BIC (training data = 2 years) and use it to forecast.
#'
#' @inheritParams create_arx_regression
#' @param from Start of forecasting period
#' @param to End of forecasting period
#' @param model_complexity Integer value. 1 corresponds to low complexity (15 dummy-lag combos), 3 to high complexity (90 dummy-lag combos). It determines the number of dummy/lag combinations considered.
#'   Default set to 2 (42 dummy-lag combos).
#' @param school Boolean value. If TRUE, school holiday dummies are included in analysis. Default set to TRUE.
#' @param model_selection_crit Character. Either "AIC" or "BIC". Default set to "BIC"
#' @param robust Boolean value.  If TRUE, then \link[quantreg]{rq} is used instead of \link{lm} for fitting the model. Default set to \code{lm}.
#' @param data_driven Default set to FALSE. If TRUE, then the holiday dummies are determined with \link{get_holidays_from_timeseries}.
#' @param recursive Default set to FALSE. If TRUE, the forecasting period is separated into 4 different periods such that the forecasting model is updated 4 times (model selection is done only once though.)
#' @param forgetting Default set to 1 If between 0 and 1, past observations will be exponentially weighted down.
#' @return Forecast in the usual data_frame format (columns timestamp and value)
#' @export
#'
forecast_auto_arx <- function(my_df_load,
                              my_postal_code,
                              from,
                              to,
                              model_complexity = 2,
                              school = TRUE,
                              model_selection_crit = "BIC",
                              robust = FALSE,
                              data_driven = FALSE,
                              recursive = FALSE,
                              forgetting = 1) {
  try({
    my_df_load <- dplyr::enquo(my_df_load)
    my_postal_code <- dplyr::enquo(my_postal_code)
    # TODO Should work without NSE!!!!
    from <- dplyr::enquo(from)
    to <- dplyr::enquo(to)

    # BEGIN NSE TODO ####
    # model_selection_crit <- dplyr::enquo(model_selection_crit)
    # model_call <- ???
    # predict.qr(object, newdata, type = "none", interval = c("none", "confidence"), level = .95, na.action = na.pass, ...)
    # predict(object, newdata, se.fit = FALSE, scale = NULL, df = Inf,
    # interval = c("none", "confidence", "prediction"),
    # level = 0.95, type = c("response", "terms"),
    # terms = NULL, na.action = na.pass,
    # pred.var = res.var/weights, weights = 1, ...)
    # rq(formula, tau=.5, data, subset, weights, na.action, method="br", model = TRUE, contrasts, ...)
    # lm(formula, data, subset, weights, na.action, method = "qr", model = TRUE, x = FALSE, y = FALSE, qr = TRUE, singular.ok = TRUE, contrasts = NULL, offset, ...)
    # END NSE TODO ####



    # Separate in different forecasting period (only relevant for recursive estimation)
    if (recursive) {
      # TODO NSE???
      period_length <-
        (rlang::eval_tidy(to) - rlang::eval_tidy(from)) / 7
      from_2 <- rlang::eval_tidy(from) + floor(period_length)
      from_3 <- rlang::eval_tidy(from) + 2 * floor(period_length)
      from_4 <- rlang::eval_tidy(from) + 3 * floor(period_length)
      from_5 <- rlang::eval_tidy(from) + 4 * floor(period_length)
      from_6 <- rlang::eval_tidy(from) + 5 * floor(period_length)
      from_7 <- rlang::eval_tidy(from) + 6 * floor(period_length)
    }

    # lags inputs for pmap (choose best BIC)
    ll_tmp <-
      get_model_grid(model_complexity = model_complexity, school = school)
    all_dummies_grid <- ll_tmp[["all_dummies_grid"]]
    all_lags_grid <- ll_tmp[["all_lags_grid"]]
    rm(ll_tmp)

    # Here is the main action ####

    if (recursive) {
      out <- all_lags_grid %>%
        dplyr::mutate(model_id = 1:nrow(.)) %>%
        dplyr::mutate(data_all = purrr::map2(
          all_dummies_grid,
          my_lags,
          ~ create_arx_regression(
            my_df_load = rlang::UQ(my_df_load),
            my_postal_code = rlang::UQ(my_postal_code),
            my_dummies_wday_hb = .x,
            my_lags = .y,
            data_driven = data_driven
          )
        ))
      out1 <- out %>%
        tidyr::unnest(data_all) %>%
        dplyr::group_by(model_id) %>%
        dplyr::mutate(q_hour_id = 1:n()) %>%
        dplyr::ungroup()

      if (robust) {
        out2 <- out1 %>%
          dplyr::mutate(data_train_1 = purrr::map(
            univ_regr,
            ~ .x %>% dplyr::filter(timestamp < rlang::UQ(from))
          )) %>%
          dplyr::mutate(lm_model_1 = purrr::map(
            data_train_1,
            ~ .x %>% dplyr::select(-timestamp) %>% safe_rq()
          )) %>% # weights is evaluated in the same environment as "formula", i.e. in "data"!!!
          dplyr::mutate(my_glance = purrr::map(lm_model_1, ~ broom::glance(.x))) %>%
          tidyr::unnest(my_glance)
      } else {
        out2 <- out1 %>%
          dplyr::mutate(data_train_1 = purrr::map(
            univ_regr,
            ~ .x %>% dplyr::filter(timestamp < rlang::UQ(from))
          )) %>%
          dplyr::mutate(lm_model_1 = purrr::map(
            data_train_1,
            ~ stats::lm(
              value ~ . - 1,
              data = .x %>% dplyr::select(-timestamp),
              na.action = na.exclude,
              singular.ok = FALSE,
              weights = forgetting ^
                ((length(value) - 1):0)
            )
          )) %>% # weights is evaluated in the same environment as "formula", i.e. in "data"!!!
          dplyr::mutate(my_glance = purrr::map(lm_model_1, ~ broom::glance(.x))) %>%
          tidyr::unnest(my_glance)
      }

      if (model_selection_crit == "BIC") {
        out2bis <- out2 %>%
          dplyr::group_by(q_hour_id) %>%
          dplyr::slice(which.min(BIC)) %>%
          dplyr::ungroup()
      } else if (model_selection_crit == "AIC") {
        out2bis <- out2 %>%
          dplyr::group_by(q_hour_id) %>%
          dplyr::slice(which.min(AIC)) %>%
          dplyr::ungroup()
      } else {
        stop("Parameter lection_crit must be set to either BIC or AIC")
      }

      if (robust) {
        out3 <- out2bis %>%
          dplyr::mutate(data_train_2 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_2))) %>%
          dplyr::mutate(lm_model_2 = purrr::map(
            data_train_2,
            ~ .x %>% dplyr::select(-timestamp) %>% safe_rq()
          )) %>%

          dplyr::mutate(data_train_3 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_3))) %>%
          dplyr::mutate(lm_model_3 = purrr::map(
            data_train_3,
            ~ .x %>% dplyr::select(-timestamp) %>% safe_rq()
          )) %>%

          dplyr::mutate(data_train_4 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_4))) %>%
          dplyr::mutate(lm_model_4 = purrr::map(
            data_train_4,
            ~ .x %>% dplyr::select(-timestamp) %>% safe_rq()
          )) %>%

          dplyr::mutate(data_train_5 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_5))) %>%
          dplyr::mutate(lm_model_5 = purrr::map(
            data_train_5,
            ~ .x %>% dplyr::select(-timestamp) %>% safe_rq()
          )) %>%

          dplyr::mutate(data_train_6 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_6))) %>%
          dplyr::mutate(lm_model_6 = purrr::map(
            data_train_6,
            ~ .x %>% dplyr::select(-timestamp) %>% safe_rq()
          )) %>%

          dplyr::mutate(data_train_7 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_7))) %>%
          dplyr::mutate(lm_model_7 = purrr::map(
            data_train_7,
            ~ .x %>% dplyr::select(-timestamp) %>% safe_rq()
          ))

      } else {
        out3 <- out2bis %>%
          dplyr::mutate(data_train_2 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_2))) %>%
          dplyr::mutate(lm_model_2 = purrr::map(
            data_train_2,
            ~ stats::lm(
              value ~ . - 1,
              data = .x %>% dplyr::select(-timestamp),
              na.action = na.exclude,
              singular.ok = FALSE,
              weights = forgetting ^
                ((length(value) - 1):0)
            )
          )) %>%

          dplyr::mutate(data_train_3 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_3))) %>%
          dplyr::mutate(lm_model_3 = purrr::map(
            data_train_3,
            ~ stats::lm(
              value ~ . - 1,
              data = .x %>% dplyr::select(-timestamp),
              na.action = na.exclude,
              singular.ok = FALSE,
              weights = forgetting ^
                ((length(value) - 1):0)
            )
          )) %>%

          dplyr::mutate(data_train_4 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_4))) %>%
          dplyr::mutate(lm_model_4 = purrr::map(
            data_train_4,
            ~ stats::lm(
              value ~ . - 1,
              data = .x %>% dplyr::select(-timestamp),
              na.action = na.exclude,
              singular.ok = FALSE,
              weights = forgetting ^
                ((length(value) - 1):0)
            )
          )) %>%

          dplyr::mutate(data_train_5 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_5))) %>%
          dplyr::mutate(lm_model_5 = purrr::map(
            data_train_5,
            ~ stats::lm(
              value ~ . - 1,
              data = .x %>% dplyr::select(-timestamp),
              na.action = na.exclude,
              singular.ok = FALSE,
              weights = forgetting ^
                ((length(value) - 1):0)
            )
          )) %>%

          dplyr::mutate(data_train_6 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_6))) %>%
          dplyr::mutate(lm_model_6 = purrr::map(
            data_train_6,
            ~ stats::lm(
              value ~ . - 1,
              data = .x %>% dplyr::select(-timestamp),
              na.action = na.exclude,
              singular.ok = FALSE,
              weights = forgetting ^
                ((length(value) - 1):0)
            )
          )) %>%

          dplyr::mutate(data_train_7 = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < from_7))) %>%
          dplyr::mutate(lm_model_7 = purrr::map(
            data_train_7,
            ~ stats::lm(
              value ~ . - 1,
              data = .x %>% dplyr::select(-timestamp),
              na.action = na.exclude,
              singular.ok = FALSE,
              weights = forgetting ^
                ((length(value) - 1):0)
            )
          ))

      }

      out4 <- out3 %>%
        dplyr::mutate(data_test_1 = purrr::map(
          univ_regr,
          ~ .x %>% dplyr::filter(timestamp >= rlang::UQ(from), timestamp < from_2) %>% dplyr::select(-value)
        )) %>%
        dplyr::mutate(data_test_2 = purrr::map(
          univ_regr,
          ~ .x %>% dplyr::filter(timestamp >= from_2, timestamp < from_3) %>% dplyr::select(-value)
        )) %>%
        dplyr::mutate(data_test_3 = purrr::map(
          univ_regr,
          ~ .x %>% dplyr::filter(timestamp >= from_3, timestamp < from_4) %>% dplyr::select(-value)
        )) %>%
        dplyr::mutate(data_test_4 = purrr::map(
          univ_regr,
          ~ .x %>% dplyr::filter(timestamp >= from_4, timestamp < from_5) %>% dplyr::select(-value)
        )) %>%
        dplyr::mutate(data_test_5 = purrr::map(
          univ_regr,
          ~ .x %>% dplyr::filter(timestamp >= from_5, timestamp < from_6) %>% dplyr::select(-value)
        )) %>%
        dplyr::mutate(data_test_6 = purrr::map(
          univ_regr,
          ~ .x %>% dplyr::filter(timestamp >= from_6, timestamp < from_7) %>% dplyr::select(-value)
        )) %>%
        dplyr::mutate(data_test_7 = purrr::map(
          univ_regr,
          ~ .x %>% dplyr::filter(timestamp >= from_7, timestamp <= rlang::UQ(to)) %>% dplyr::select(-value)
        ))

      if (robust) {
        out5 <- out4 %>%
          dplyr::mutate(
            my_prediction_value = purrr::map2(
              lm_model_1,
              data_test_1,
              ~ quantreg::predict.rq(
                object = .x,
                newdata = .y %>% dplyr::select(-timestamp)
              )
            )
          ) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_1, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_1 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(
            my_prediction_value = purrr::map2(
              lm_model_2,
              data_test_2,
              ~ quantreg::predict.rq(
                object = .x,
                newdata = .y %>% dplyr::select(-timestamp)
              )
            )
          ) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_2, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_2 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(
            my_prediction_value = purrr::map2(
              lm_model_3,
              data_test_3,
              ~ quantreg::predict.rq(
                object = .x,
                newdata = .y %>% dplyr::select(-timestamp)
              )
            )
          ) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_3, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_3 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(
            my_prediction_value = purrr::map2(
              lm_model_4,
              data_test_4,
              ~ quantreg::predict.rq(
                object = .x,
                newdata = .y %>% dplyr::select(-timestamp)
              )
            )
          ) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_4, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_4 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(
            my_prediction_value = purrr::map2(
              lm_model_5,
              data_test_5,
              ~ quantreg::predict.rq(
                object = .x,
                newdata = .y %>% dplyr::select(-timestamp)
              )
            )
          ) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_5, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_5 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(
            my_prediction_value = purrr::map2(
              lm_model_6,
              data_test_6,
              ~ quantreg::predict.rq(
                object = .x,
                newdata = .y %>% dplyr::select(-timestamp)
              )
            )
          ) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_6, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_6 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(
            my_prediction_value = purrr::map2(
              lm_model_7,
              data_test_7,
              ~ quantreg::predict.rq(
                object = .x,
                newdata = .y %>% dplyr::select(-timestamp)
              )
            )
          ) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_7, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_7 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          )
      } else {
        out5 <- out4 %>%
          dplyr::mutate(my_prediction_value = purrr::map2(
            lm_model_1,
            data_test_1,
            ~ stats::predict.lm(
              object = .x,
              newdata = .y %>% dplyr::select(-timestamp)
            )
          )) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_1, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_1 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(my_prediction_value = purrr::map2(
            lm_model_2,
            data_test_2,
            ~ stats::predict.lm(
              object = .x,
              newdata = .y %>% dplyr::select(-timestamp)
            )
          )) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_2, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_2 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(my_prediction_value = purrr::map2(
            lm_model_3,
            data_test_3,
            ~ stats::predict.lm(
              object = .x,
              newdata = .y %>% dplyr::select(-timestamp)
            )
          )) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_3, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_3 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(my_prediction_value = purrr::map2(
            lm_model_4,
            data_test_4,
            ~ stats::predict.lm(
              object = .x,
              newdata = .y %>% dplyr::select(-timestamp)
            )
          )) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_4, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_4 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(my_prediction_value = purrr::map2(
            lm_model_5,
            data_test_5,
            ~ stats::predict.lm(
              object = .x,
              newdata = .y %>% dplyr::select(-timestamp)
            )
          )) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_5, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_5 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(my_prediction_value = purrr::map2(
            lm_model_6,
            data_test_6,
            ~ stats::predict.lm(
              object = .x,
              newdata = .y %>% dplyr::select(-timestamp)
            )
          )) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_6, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_6 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          ) %>%

          dplyr::mutate(my_prediction_value = purrr::map2(
            lm_model_7,
            data_test_7,
            ~ stats::predict.lm(
              object = .x,
              newdata = .y %>% dplyr::select(-timestamp)
            )
          )) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test_7, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction_7 =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          )
      }


      out6 <- out5 %>%
        dplyr::select(
          my_prediction_1,
          my_prediction_2,
          my_prediction_3,
          my_prediction_4,
          my_prediction_5,
          my_prediction_6,
          my_prediction_7
        ) %>%
        tidyr::gather(value = "prediction_all") %>%
        tidyr::unnest() %>%
        dplyr::arrange(timestamp)

      out7 <- out6 %>%
        dplyr::select(-key)
    } else{
      out <- all_lags_grid %>%
        dplyr::mutate(model_id = 1:nrow(.)) %>%
        dplyr::mutate(data_all = purrr::map2(
          all_dummies_grid,
          my_lags,
          ~ create_arx_regression(
            my_df_load = rlang::UQ(my_df_load),
            my_postal_code = rlang::UQ(my_postal_code),
            my_dummies_wday_hb = .x,
            my_lags = .y,
            data_driven = data_driven
          )
        ))
      out1 <- out %>%
        tidyr::unnest(data_all) %>%
        dplyr::group_by(model_id) %>%
        dplyr::mutate(q_hour_id = 1:n()) %>%
        dplyr::ungroup()

      out2 <- out1 %>%
        dplyr::mutate(data_train = purrr::map(univ_regr, ~ .x %>% dplyr::filter(timestamp < rlang::UQ(from)))) %>%
        dplyr::mutate(data_test = purrr::map(
          univ_regr,
          ~ .x %>% dplyr::filter(timestamp >= rlang::UQ(from)) %>% dplyr::select(-value)
        ))

      if (robust) {
        out3 <- out2 %>%
          dplyr::select(-univ_regr) %>%
          dplyr::mutate(lm_model = purrr::map(
            data_train,
            ~ .x %>% dplyr::select(-timestamp) %>% safe_rq()
          )) %>%
          dplyr::select(-data_train)
      } else {
        out3 <- out2 %>%
          dplyr::select(-univ_regr) %>%
          dplyr::mutate(lm_model = purrr::map(
            data_train,
            ~ stats::lm(
              value ~ . - 1,
              data = .x %>% dplyr::select(-timestamp),
              na.action = na.exclude
            )
          )) %>%
          dplyr::select(-data_train)
      }

      out4 <- out3 %>%
        dplyr::mutate(my_glance = purrr::map(lm_model, ~ broom::glance(.x))) %>%
        tidyr::unnest(my_glance) %>%
        dplyr::group_by(q_hour_id)

      # out5 <- out4 %>%
      #   dplyr::slice(which.min(BIC)) %>%
      #   dplyr::ungroup() %>%
      #   dplyr::select(lm_model, data_test)

      if (model_selection_crit == "BIC") {
        out5 <- out4 %>%
          dplyr::slice(which.min(BIC)) %>%
          dplyr::ungroup() %>%
          dplyr::select(lm_model, data_test)
      } else if (model_selection_crit == "AIC") {
        out5 <- out4 %>%
          dplyr::slice(which.min(AIC)) %>%
          dplyr::ungroup() %>%
          dplyr::select(lm_model, data_test)
      } else {
        stop("Parameter model_selection_crit must be set to either BIC or AIC")
      }

      if (robust) {
        out6 <- out5 %>%
          dplyr::mutate(my_prediction_value = purrr::map2(
            lm_model,
            data_test,
            ~ quantreg::predict.rq(
              object = .x,
              newdata = .y %>% dplyr::select(-timestamp)
            )
          )) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          )

      } else{
        out6 <- out5 %>%
          dplyr::mutate(my_prediction_value = purrr::map2(
            lm_model,
            data_test,
            ~ stats::predict.lm(
              object = .x,
              newdata = .y %>% dplyr::select(-timestamp)
            )
          )) %>%
          dplyr::mutate(my_prediction_timestamp =  purrr::map(data_test, ~
                                                                .x %>% dplyr::select(timestamp))) %>%
          dplyr::mutate(
            my_prediction =  purrr::map2(
              my_prediction_timestamp,
              my_prediction_value,
              ~ tidyr::unnest(.x, .y) %>% dplyr::rename(value = .y)
            )
          )
      }

      out7 <- out6 %>%
        tidyr::unnest(my_prediction) %>%
        dplyr::arrange(timestamp) %>%
        dplyr::filter(timestamp >= rlang::UQ(from) &
                        timestamp <= rlang::UQ(to))
    }

    return(out7)
  })

  naive_seasonal_holiday_version_2(
    df = rlang::eval_tidy(my_df_load),
    postal_code_or_state = rlang::eval_tidy(my_postal_code),
    from = rlang::eval_tidy(from),
    to = rlang::eval_tidy(to),
    generate_holidays_data_driven = FALSE
  )


}
