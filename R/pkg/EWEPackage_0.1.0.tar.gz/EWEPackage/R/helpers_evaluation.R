# Filtering functions ####

#' Filter available load time series
#'
#' This function is a wrapper for \link{filter_appropriate_meter_points}.
#' It filters all load time series which are not NULL.
#' By default, it focuses only on the \strong{load} time series and not on the internal benchmark forecast provided by EWE, i.e. the ar
#'
#' @param df_base A \link[dplyr]{data_frame} with list columns, a "_base" data_frame, see . Here, \code{ts_load} and \code{ts_fc_ewe} are accessed
#' @param ts_fc_ewe_nonNA Boolean, default set to FALSE. If TRUE, then meter points where the internal forecast is missing, i.e. NULL, are removed.
#'
#' @return A data_frame of the same kind (base), but with fewer rows, i.e. meter points.
#' @export
filter_nonNA <- function(df_base = df_base, ts_fc_ewe_nonNA = FALSE){
  filter_appropriate_meter_points(df_base = df_base, with_ts_fc_ewe = ts_fc_ewe_nonNA)
}

#' Filter meter points on which evaluation is possible
#'
#' It removes the meter points on which evaluation (comparison of forecast errors) is not possible.
#' This function filters, i.e. keeps, only meter points such that
#' \enumerate{
#' \item the timeseries \code{ts_load} and \code{ts_fc_ewe} have the same number of measurements in the forecast period, and that
#' \item the forecast period comprises at least 3 weeks.
#' }
#'
#' This function is similar to \link{filter_those_where_nothing_is_missing} but has the additional argument \code{forecast_start_date}.
#'
#' @param df_base \link{data_frame} of type "base", see confluence.
#' @param forecast_start_date Date object. Default set to "2016-01-01 00:15:00".
#'
#' @return Cleaned base data frame (with fewer rows, i.e. meter points).
#'
#' @import dplyr
#' @importFrom purrr map2_int
#'
#' @export
filter_same_fc_period <- function(df_base, forecast_start_date = lubridate::ymd_hms("2016-01-01 00:15:00")){

  forecast_start_date_enquo <- rlang::enquo(forecast_start_date)

  df_base <- df_base %>%
    mutate(forecast_points_in_ts_load      = map2_int(ts_load,   rlang::UQ(forecast_start_date_enquo), ~ (sum(.x$timestamp >= .y))),
           forecast_points_in_ts_fc_ewe    = map2_int(ts_fc_ewe, rlang::UQ(forecast_start_date_enquo), ~ (sum(.x$timestamp >= .y))),
           number_of_forecast_points_equal = forecast_points_in_ts_load == forecast_points_in_ts_fc_ewe) %>%
    filter(number_of_forecast_points_equal == TRUE) %>%
    filter(forecast_points_in_ts_load > 96*7*3) # at least 3 weeks!!

  return(df_base %>% select(-c(forecast_points_in_ts_load, forecast_points_in_ts_fc_ewe, number_of_forecast_points_equal)))
}

#' Filter meter points with specific observation and forecasting period
#'
#' This function keeps only the meter points for which the load time series \code{ts_load} starts on "2014-01-01 00:15:00",
#' such that with forecast starting date is "2016-01-01 00:15:00" and such that the forecasting period ends on "2017-01-01 00:00:00".
#' In this case one has the full observation period of 2 years and the full forecasting period of 1 year.
#' The default values can be adjusted to arbitrary periods.
#' Setting the argument \code{full_nobs_in_ts_fc_ewe} to TRUE enforces that the internal benchmark forecast should also be available for 3 years (default is that this is not necessary).
#'
#' This function is similar to \link{filter_those_in_the_correct_date_range} but has more arguments and a more convenient name.
#'
#' @param df_base \link{data_frame} of type "base", see confluence.
#' @param observation_start_date Date object, default set to "2014-01-01 00:15:00". Indicates start of observation period.
#' @param forecast_start_date Date object, default set to "2016-01-01 00:15:00". Indicates start of forecasting period.
#' @param forecast_end_date Date object, default set to "2017-01-01 00:00:00". Indicates end of forecasting period.
#' @param full_nobs_in_ts_fc_ewe Boolean, default set to FALSE.
#'   If true, ts_fc_ewe must have the same number of observations as ts_load.
#'
#' @return Base data frame (with fewer rows)
#'
#' @export

filter_periods <- function(df_base,
                           observation_start_date = lubridate::ymd_hms("2014-01-01 00:15:00"),
                           forecast_start_date = lubridate::ymd_hms("2016-01-01 00:15:00"),
                           forecast_end_date = lubridate::ymd_hms("2017-01-01 00:00:00"),
                           full_nobs_in_ts_fc_ewe = FALSE){

  observation_start_date_enquo <- rlang::enquo(observation_start_date)
  forecast_start_date_enquo <- rlang::enquo(forecast_start_date)
  forecast_end_date_enquo <- rlang::enquo(forecast_end_date)

  df_base <- df_base %>%
    dplyr::filter(observation_start_date == rlang::UQ(observation_start_date_enquo),
                  forecast_start_date == rlang::UQ(forecast_start_date_enquo),
                  forecast_end_date == rlang::UQ(forecast_end_date_enquo))

  if (full_nobs_in_ts_fc_ewe) {
    df_base <- df_base %>%
      dplyr::mutate(points_in_ts_load = purrr::map_int(ts_load, nrow),
                    points_in_ts_fc_ewe = purrr::map_int(ts_fc_ewe, nrow),
                    number_of_points_equal = (points_in_ts_load == points_in_ts_fc_ewe)) %>%
      dplyr::filter(number_of_points_equal == TRUE) %>%
      dplyr::select(-c(points_in_ts_load, points_in_ts_fc_ewe, number_of_points_equal))
  }

  return(df_base)
}

#' Function to filter appropriate meter points
#'
#' Function to filter appropriate meter points given a base data frame.
#'
#' This function removes all meter points that don\'t have a load timeseries.
#' Using the argument \code{with_ts_fc_ewe} one can keep those who do not have a
#' robotron forecast. This is when we want to evaluate the naive forecast on
#' more data. By default those with missing robotron forecast will also be
#' removed.
#'
#' @param df_base \link{data_frame} of type "base", see confluence.
#' @param with_ts_fc_ewe flag to indicate weather or not to keep meter points
#'   with missing robotron forecast. If \code{TRUE} (default) meter points with
#'   missing robotron forecast will be removed. If \code{FALSE} meter points
#'   with missing robotron forecast are kept.
#'
#' @return Cleaned data frame.
#'
#' @import dplyr
#' @importFrom purrr map_lgl
#'
#' @export

filter_appropriate_meter_points <- function(df_base, with_ts_fc_ewe = TRUE){

  # remove those where ts_load is missing
  df_base <- df_base %>%
    filter(! map_lgl(ts_load, is.null) )

  # remove those where ts_fc_ewe is missing
  if (with_ts_fc_ewe) {

    df_base <- df_base %>%
      filter(! map_lgl(ts_fc_ewe, is.null) )

  }

  return(df_base)

}





#' Function to filter meter points where nothing is missing
#'
#' Function to filter meter points where nothing is missing.
#' It removes the meter points on which evaluation (comparison of forecast errors) is not possible.
#'
#' This function filters, i.e. keeps, only meter points with the same number of measurements
#' in the forecast period in the timeseries ts_load and ts_fc_ewe and at least 3
#' weeks of forecast period.
#'
#' @param df_base \link{data_frame} of type "base", see confluence.
#'
#' @return Cleaned data frame.
#'
#' @import dplyr
#' @importFrom purrr map2_int
#'
#' @export
# function to remove those where there is no possible evaluation
filter_those_where_nothing_is_missing <- function(df_base){

  df_base <- df_base %>%
    mutate(forecast_points_in_ts_load      = map2_int(ts_load,   forecast_start_date, ~ (sum(.x$timestamp >= .y))),
           forecast_points_in_ts_fc_ewe    = map2_int(ts_fc_ewe, forecast_start_date, ~ (sum(.x$timestamp >= .y))),
           number_of_forecast_points_equal = forecast_points_in_ts_load == forecast_points_in_ts_fc_ewe) %>%
    filter(number_of_forecast_points_equal == TRUE) %>%
    filter(forecast_points_in_ts_load > 96*7*3) # at least 3 weeks!!

  return(df_base %>% select(-c(forecast_points_in_ts_load, forecast_points_in_ts_fc_ewe, number_of_forecast_points_equal)))

}





#' Function to filter meter points in correct date range
#'
#' Function to filter meter points in correct date range for aggregated
#' evaluation.
#'
#' This function removes all meter points which do not start on 2014-01-01
#' 00:15:00 with forecast starting date '2016-01-01 00:15:00' and end on
#' 2017-01-01 00:00:00. Using the argument
#' \code{equal_number_of_observations_in_ts_load_and_ts_fc_ewe} one can allow
#' timeseries where the horizons of ts_load and ts_fc_ewe are different.
#'
#' @param df_base \link{data_frame} of type "base", see confluence.
#' @param equal_number_of_observations_in_ts_load_and_ts_fc_ewe flag to control
#'   the above. When \code{TRUE} only meter points where there the exact same
#'   horizons in ts_load and ts_fc_ewe. If \code{FALSE} (Default) the horizons
#'   can be different.
#'
#' @return Cleaned data frame.
#'
#' @import dplyr
#' @importFrom lubridate ymd_hms
#' @importFrom purrr map_int
#'
#' @export

# function removes meter points with different number of observations
filter_those_in_the_correct_date_range <- function(df_base, equal_number_of_observations_in_ts_load_and_ts_fc_ewe = FALSE){

  df_base <- df_base %>%
    filter(observation_start_date == ymd_hms('2014-01-01 00:15:00'),
           forecast_start_date == ymd_hms('2016-01-01 00:15:00'),
           forecast_end_date == ymd_hms('2017-01-01 00:00:00'))

  if (equal_number_of_observations_in_ts_load_and_ts_fc_ewe) {

    df_base <- df_base %>%
      mutate(points_in_ts_load = map_int(ts_load, nrow),
             points_in_ts_fc_ewe = map_int(ts_fc_ewe, nrow),
             number_of_points_equal = points_in_ts_load == points_in_ts_fc_ewe) %>%
      filter(number_of_points_equal == TRUE)

  }

  return(df_base)

}

# Aggregation functions ####

#' Function to calculate the daily timeseries aggregated per control are
#'
#' Function to calculate the daily timeseries aggregated per control are.
#'
#' This function calculates the daily timeseries aggreated on a certain control
#' area. It only uses those as discribed in
#' \link{filter_those_in_the_correct_date_range}.
#'
#' @param df_base \link{data_frame} of type "base", see confluence.
#' @param column timeseries to be agregated
#' @param equal_number_of_observations_in_ts_load_and_ts_fc_ewe See
#'   \link{filter_those_in_the_correct_date_range}. When \code{TRUE} only meter
#'   points where there the exact same horizons in ts_load and ts_fc_ewe. If
#'   \code{FALSE} (Default) the horizons can be different.
#'
#' @return timeseries data frame.
#'
#' @import dplyr
#' @importFrom lubridate minutes
#' @importFrom lubridate ymd
#' @importFrom lubridate as_date
#'
#' @export

# calculate_daily_ts_per_control_area
summarise_ts_per_control_area_daily <- function(df_base, column, equal_number_of_observations_in_ts_load_and_ts_fc_ewe = FALSE){

  # see https://blog.rstudio.org/2017/06/13/dplyr-0-7-0/
  column <- enquo(column)

  df_base %>%
    filter_those_in_the_correct_date_range(equal_number_of_observations_in_ts_load_and_ts_fc_ewe = equal_number_of_observations_in_ts_load_and_ts_fc_ewe) %>%
    select(!!column) %>%
    unnest() %>%
    group_by(timestamp) %>%
    summarise(value = sum(value)) %>%
    mutate(timestamp = timestamp - minutes(15)) %>%
    mutate(timestamp = as_date(timestamp)) %>%
    group_by(timestamp) %>%
    summarise(value = sum(value))

}

# Error calculation for aggregated series ####

#' Function to summarise all timeseries per control area
#'
#' Function to summarise all timeseries per control area.
#'
#' This function calculates timeseries aggreated on a certain control area. It
#' only uses those meter points as discribed in
#' \link{filter_those_in_the_correct_date_range} via the argument
#' \code{equal_number_of_observations_in_ts_load_and_ts_fc_ewe}.
#'
#' @param df_base \link{data_frame} of type "base", see confluence.
#' @param column timeseries to be agregated
#' @param equal_number_of_observations_in_ts_load_and_ts_fc_ewe See
#'   \link{filter_those_in_the_correct_date_range}. When \code{TRUE} only meter
#'   points where there the exact same horizons in ts_load and ts_fc_ewe. If
#'   \code{FALSE} (Default) the horizons can be different.
#'
#' @return timeseries data frame.
#'
#' @import dplyr
#'
#' @export

summarise_ts_per_control_area <- function(df_base, column, equal_number_of_observations_in_ts_load_and_ts_fc_ewe = FALSE){

  column <- enquo(column)

  df_base %>%
    filter_those_in_the_correct_date_range(equal_number_of_observations_in_ts_load_and_ts_fc_ewe) %>%
    select(!!column) %>%
    unnest() %>%
    group_by(timestamp) %>%
    summarise(value = sum(value))

}


#' Helper for DAE per meterpoint
#'
#' Calculates DAE on a disaggregated level, i.e. for each meter point in a base dataframe.
#'
#' @param controll_area_base Data_frame containing meter points (primary key) and
#' @param ts_type Name (unquoted) of a time series to be evaluated.
#'
#' @return Data_frame of base-kind with an additional column containin the daily absolute error (as tibble since it is a time series too).
#'
#' @import dplyr
#'
#' @export
#'
calculate_DAE_per_meter_point_helper <- function(controll_area_base, ts_type){

  DAE_ts_type_string <- paste('DAE_', ts_type_string, sep = '')
  DAE_ts_type <- dplyr::enquo(DAE_ts_type_string)

  use_mapping_table <- TRUE

  controll_area_base <- controll_area_base %>%
    dplyr::mutate(!!DAE_ts_type_string := purrr::pmap(list(ts_load, !!ts_type, forecast_start_date),
                                                      daily_absolute_error,
                                                      use_mapping_table = use_mapping_table))

  return(controll_area_base)

}

#' Helper for MDAE per meterpoint
#'
#' Calculates DAE on a disaggregated level, i.e. for each meter point in a base dataframe.
#'
#' @inheritParams calculate_DAE_per_meter_point_helper
#' @param DAE_ts_type Name (unquoted) of the DAE time series whose mean shall be calculated
#'
#' @return Data_frame of the base kind, with additional column containing the MDAE for a specific meter point (a dbl).
#' @export
#'
calculate_MDAE_per_meter_point_helper <- function(controll_area_base, DAE_ts_type){

  DAE_ts_type <- dplyr::enquo(DAE_ts_type)
  DAE_ts_type_string <- as.character(DAE_ts_type)[2]

  MDAE_ts_type_string <- paste('M', DAE_ts_type_string, sep = '')

  use_mapping_table <- TRUE

  controll_area_base <- controll_area_base%>%
    dplyr::mutate(!!MDAE_ts_type_string := purrr::map_dbl(!!DAE_ts_type, ~mean(.x$value)))

  return(controll_area_base)

}


#' DAE and MDAE for aggregates
#'
#' Calculates DAE and MDAE on an aggregated level, i.e. it first sums across all loads in a given control area and then calculates the DAE and subsequently the MDAE for the aggregated area.
#'
#' @inheritParams calculate_DAE_per_meter_point_helper
#' @param equal_number_of_observations_in_ts_load_and_ts_fc_ewe Parameter from function \link{filter_those_in_the_correct_date_range}, indicating if the benchmark forecast provided by EWE needs to have three years of history.
#'
#' @return List with elements "DAE" and "DAPE", each of which are data_frames.
#' @export
#'
calculate_DAE_DAPE_aggregated_on_control_area <- function(controll_area_base, ts_type, equal_number_of_observations_in_ts_load_and_ts_fc_ewe){

  ts_type <- dplyr::enquo(ts_type)
  ts_type_string <- as.character(ts_type)[2]

  DAE <-
    daily_absolute_error(controll_area_base %>%
                           summarise_ts_per_control_area(ts_load_forecast_period,
                                                         equal_number_of_observations_in_ts_load_and_ts_fc_ewe = equal_number_of_observations_in_ts_load_and_ts_fc_ewe),
                         controll_area_base %>%
                           summarise_ts_per_control_area(!!ts_type,
                                                         equal_number_of_observations_in_ts_load_and_ts_fc_ewe = equal_number_of_observations_in_ts_load_and_ts_fc_ewe))

  DAPE <-
    daily_absolute_percentage_error(controll_area_base %>%
                                      summarise_ts_per_control_area(ts_load_forecast_period,
                                                                    equal_number_of_observations_in_ts_load_and_ts_fc_ewe =equal_number_of_observations_in_ts_load_and_ts_fc_ewe),
                                    controll_area_base %>%
                                      summarise_ts_per_control_area(!!ts_type,
                                                                    equal_number_of_observations_in_ts_load_and_ts_fc_ewe = equal_number_of_observations_in_ts_load_and_ts_fc_ewe))

  return(list(DAE = DAE, DAPE = DAPE))

}


#' Evaluate aggregate forecast obtained from disaggregated ones
#'
#' @param df_control_area Data_frame containing as columns at least "ts_load", "ts_fc_ewe", and the proprietary forecasts to be evaluated.
#' @param my_fc_name (Unquoted) name of the column containing proprietary forecast (in nested form, containing timestamp and value as columns)
#' @param forecast_start_date Datetime. Start of forcasting period (inclusive)
#'
#' @return Data_frame with outlier analysis.
#' @export
#' @importFrom purrr %>%
analyse_forecast_error <- function(df_control_area, my_fc_name, forecast_start_date){

  my_fc_name <- dplyr::enquo(my_fc_name)

  # that's a hack. just needed the daily timestamp, so i copied stuff from below
  timestamp_daily <- df_control_area %>%
    summarise_ts_per_control_area(ts_load) %>%
    dplyr::filter(timestamp >= forecast_start_date) %>%
    dplyr::mutate(timestamp = lubridate::as_date(timestamp - lubridate::minutes(15))) %>%
    dplyr::group_by(timestamp) %>%
    dplyr::summarise(value = sum(value)) %>%
    dplyr::pull(timestamp)

  ts_load_aggr <- df_control_area %>%
    summarise_ts_per_control_area(ts_load) %>%
    dplyr::filter(timestamp >= forecast_start_date) %>%
    dplyr::mutate(timestamp = lubridate::as_date(timestamp - lubridate::minutes(15))) %>%
    dplyr::group_by(timestamp) %>%
    dplyr::summarise(value = sum(value)) %>%
    dplyr::pull(value)

  ts_fc_ewe_aggr <- df_control_area %>%
    summarise_ts_per_control_area(ts_fc_ewe) %>%
    dplyr::filter(timestamp >= forecast_start_date) %>%
    dplyr::mutate(timestamp = lubridate::as_date(timestamp - lubridate::minutes(15))) %>%
    dplyr::group_by(timestamp) %>%
    dplyr::summarise(value = sum(value)) %>%
    dplyr::pull(value)

  ts_my_fc_aggr <- df_control_area %>%
    summarise_ts_per_control_area(rlang::UQ(my_fc_name)) %>%
    dplyr::filter(timestamp >= forecast_start_date) %>%
    dplyr::mutate(timestamp = lubridate::as_date(timestamp - lubridate::minutes(15))) %>%
    dplyr::group_by(timestamp) %>%
    dplyr::summarise(value = sum(value)) %>%
    dplyr::pull(value)


  error1 <- dplyr::data_frame(timestamp = timestamp_daily,
                              error_fc_ewe_aggr = ts_fc_ewe_aggr - ts_load_aggr,
                              error_my_fc_aggr =  ts_my_fc_aggr - ts_load_aggr)
  error2 <- error1 %>%
    dplyr::mutate(q_u = stats::quantile(error_my_fc_aggr, probs = 0.75, na.rm = TRUE, names = FALSE),
                  q_d = stats::quantile(error_my_fc_aggr, probs = 0.25, na.rm = TRUE, names = FALSE),
                  iqr = q_u - q_d) %>%
    dplyr::mutate(is_outlier = ifelse(error_my_fc_aggr > q_u + 1.5 * iqr || error_my_fc_aggr < q_d - 1.5 * iqr, TRUE, FALSE)) %>%
    dplyr::mutate(outlier_score = 0)

  error3 <- error2 %>%
    dplyr::mutate(outlier_score = ifelse(error_my_fc_aggr > q_u, (error_my_fc_aggr - q_u)/iqr, outlier_score)) %>%
    dplyr::mutate(outlier_score = ifelse(error_my_fc_aggr < q_d, (error_my_fc_aggr - q_d)/iqr, outlier_score)) %>%
    dplyr::select(-c(q_u, q_d, iqr))

  error4 <- error3 %>%
    dplyr::mutate(day_of_week = lubridate::wday(timestamp, label = TRUE))

  error5 <- error4 %>%
    dplyr::mutate(is_holiday = create_holiday_dummy("Sachsen",
                                                    date_start = min(timestamp_daily),
                                                    date_end = max(timestamp_daily)) %>% pull(value))
  error6 <- error5 %>%
    dplyr::mutate(is_bridging = create_bridgingday_dummy("Sachsen",
                                                         date_start = min(timestamp_daily),
                                                         date_end = max(timestamp_daily)) %>% pull(value))


  return(error6)
}



