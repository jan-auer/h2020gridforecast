#' input generation of simple nn with holiday data.
#'
#' Generates the all the input for neural network fitting.
#'
#' @param df timeseries data frame.
#' @param from forecast starting date.
#' @param postal_code of current meter point.
#' @param number_of_weeks number of weeks to use for lagging.
#' @param days_to_use days to use as lagged input.
#' @param add_yearly_regressor yearly regressor as input flag.
#' @param generate_holidays_data_driven generate the holiday calender data
#'   driven. See \link{get_holidays_from_timeseries}.
#'
#' @import dplyr
#' @importFrom lubridate ymd
#' @importFrom lubridate ymd_hms
#' @importFrom lubridate minutes
#' @importFrom lubridate as_datetime
#' @importFrom lubridate ceiling_date
#'
#' @export

simple_nn_with_holiday_input_generation <- function(df, from, postal_code, number_of_weeks = 1, days_to_use = NULL, add_yearly_regressor = FALSE, generate_holidays_data_driven = FALSE){

  #####################################################################################################################################################  
  #                           IN ORDER TO ADD EXTERNAL REGRESSORS:                                                                                    #
  #   *) add additional argument (xreg) which gets the external regressors corresponding to the external variables.                                   #
  #      It should be a data frame with columns 'timestamp' and 'value' with the same number of rows as df (the timeseries data frame)                #
  #   *) Next it is sufficient to add it to the all_data_x matrix                                                                                     #
  #####################################################################################################################################################
  
  # get first full day
  first_date_in_df <- min(df$timestamp)
  first_full_day <- first_date_in_df %>% ceiling_date(unit = 'day') %>% paste('00:15:00') %>% ymd_hms
  df <- df %>% filter(timestamp >= first_full_day)

  from_datetime <- as_datetime(from)

  # get forecast interval
  fc_interval <- df %>% filter(timestamp >= from_datetime) %>% pull(timestamp)

  # trimm forecast starting date to the actual day
  from <- ymd(substr(from_datetime, 1, 10))

  # get dates of timeseries
  dates <-
    df %>%
    mutate(timestamp = timestamp - minutes(15)) %>%
    select(timestamp) %>%
    left_join(mapping_table_datetime_to_day, by = 'timestamp') %>%
    pull(timestamp_new) %>%
    unique()

  # get indizes of observation and forecast periods
  observation_idx <- which(dates < from)
  forecast_idx <- which(dates >= from)

  # initialize naive forecast
  naive_holiday_forecast <- naive_seasonal_holiday_version_2(df = df, postal_code_or_state = postal_code, generate_holidays_data_driven = generate_holidays_data_driven, from = from_datetime, return_all = TRUE)

  # get lagged values of corresponding weeks
  for (i in 1:number_of_weeks){

    last_week <- matrix(naive_holiday_forecast$value, ncol = 96, byrow = TRUE)
    if(number_of_weeks > 1){
      naive_holiday_forecast <- naive_seasonal_holiday_version_2(df = naive_holiday_forecast, postal_code_or_state = postal_code, generate_holidays_data_driven = generate_holidays_data_driven, from = from_datetime, return_all = TRUE)
    }

    if (i == 1){
      all_data_x <- last_week
    } else {
      all_data_x <- cbind(all_data_x, last_week)
    }

  }

  # get lagged values of corresponding days
  for (i in seq_along(days_to_use)){

    last_day <- matrix(lag(df$value, 96*days_to_use[i]), ncol = 96, byrow = TRUE)
    all_data_x <- cbind(all_data_x, last_day)

  }

  if(add_yearly_regressor & nrow(all_data_x) >= 3*365){

    all_data_x <- cbind(all_data_x, matrix(lag(df$value, 96*7*52), ncol = 96, byrow = TRUE))

  }

  # generate y values
  all_data_y <- matrix(df$value, ncol = 96, byrow = TRUE)

  # set up train and test set
  train_x <- all_data_x[observation_idx,] %>% data.matrix()
  train_y <- all_data_y[observation_idx,] %>% data.matrix()
  test_x  <- all_data_x[forecast_idx,] %>% data.matrix()
  test_y  <- all_data_y[forecast_idx,] %>% data.matrix()


  na_row_indizes <- 1:ncol(train_x) %>% map(~which(is.na(train_x[,.x]))) %>% unlist() %>% unique()

  # remove NAs due to lagging
  train_x <- train_x[-na_row_indizes,]
  train_y <- train_y[-na_row_indizes,]

  return(list(train_x = train_x, train_y = train_y, test_x = test_x, test_y = test_y, fc_interval = fc_interval))

}

#' forecast using simple nn with holiday effects
#'
#' Final function to perform neural network forecasting
#'
#' @param df timeseries data frame.
#' @param net neurel network specification.
#' @param from forecast starting date.
#' @param model_selection flag to perform model selection based on validation
#'   errors.
#' @param convex_combine flag to perform convex combination during model
#'   selection.
#' @param number_of_weeks number of weeks to use for lagging.
#' @param days_to_use days to use as lagged input.
#' @param add_yearly_regressor yearly regressor as input flag.
#' @param generate_holidays_data_driven see \link{get_holidays_from_timeseries}.
#' @param number_of_folds number of folds to be used in
#'   \link{mx.crossvalidation}.
#' @param postal_code postal code of current timeseries.
#' @param verbose print during cross validation.
#' @param verbose_mxnet Print during mxnet training.
#' @param ... other parameters passed to \link{mx.crossvalidation}.
#'
#' @import dplyr
#' @importFrom lubridate as_datetime
#'
#' @export

simple_nn_with_holiday_forecast <- function(df, net = NULL, from, model_selection = FALSE, convex_combine = FALSE, number_of_weeks = 1, days_to_use = NULL, add_yearly_regressor = FALSE, generate_holidays_data_driven = FALSE, number_of_folds = 5, postal_code, verbose = TRUE, verbose_mxnet = FALSE, ...){

  if(is.null(net)) net <- get_default_networks()

  from <- as_datetime(from)

  # generate input
  input_data <-
    simple_nn_with_holiday_input_generation(df = df,
                                            from = from,
                                            postal_code = postal_code,
                                            number_of_weeks = number_of_weeks,
                                            days_to_use = days_to_use,
                                            add_yearly_regressor = add_yearly_regressor,
                                            generate_holidays_data_driven = generate_holidays_data_driven)

  # get input
  train_x <- input_data$train_x
  train_y <- input_data$train_y
  test_x  <- input_data$test_x
  test_y  <- input_data$test_y
  fc_interval <- input_data$fc_interval

  additional_model_slug <- paste0('simple_nn_with_holiday_NrWeeks:',number_of_weeks, '_data_holidays', generate_holidays_data_driven)

  # perform cross validation
  result_df <- mx.crossvalidation(net = net,
                                  train_x = train_x,
                                  train_y = train_y,
                                  number_of_folds = number_of_folds,
                                  verbose = verbose,
                                  verbose_mxnet = verbose_mxnet,
                                  additional_model_slug = additional_model_slug,
                                  ...)

  # get results
  result_df <-
    result_df %>%
    mutate(forecast = map(model, ~mx.data.output.generation(model = .x, test_x = test_x, test_y = test_y, fc_interval = fc_interval))) %>%
    mutate(na_in_forecast = map_int(forecast, ~sum(is.na(.x$value)))) %>% filter(na_in_forecast == 0)

  naive_result_df <- naive_model_validation(df = df, from = from, postal_code = postal_code)

  result_df <- bind_rows(result_df, naive_result_df)

  # perform model selection
  if (model_selection) {

    return(nn_model_selection(result_df, convex_combine = convex_combine))

  }

  return(result_df)

}
