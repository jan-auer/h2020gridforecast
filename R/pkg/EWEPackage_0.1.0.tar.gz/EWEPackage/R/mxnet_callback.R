#' Custom logger function for logging and early stopping using mxnet
#'
#' @importFrom mxnet mx.metric.logger
#' @export mx.metric.logger.early.stopping

# get current mxnet logger class
mx.metric.logger.early.stopping <- getRefClass("mx.metric.logger")
# introduce new logger class with additional field best_round
mx.metric.logger.early.stopping <-
  setRefClass("mx.metric.logger.early.stopping",
              fields = list(train = "numeric", eval = "numeric", best_round = "numeric"))


#' Custom callback function for logging and early stopping using mxnet
#'
#' @param period The number of batch to log the training evaluation metric.
#' @param logger The logger class.
#' @param early.stopping.round The number of rounds, in which is the validation
#'   score did not improve, to use for early stopping.
#'
#' @export

mx.callback.log.train.metric.early.stopping <- function(period,
                                                        logger=NULL,
                                                        early.stopping.round) {
  function(iteration, nbatch, env, verbose) {
    if (nbatch %% period == 0 && !is.null(env$metric)) {
      result <- env$metric$get(env$train.metric)
      if (nbatch != 0)
        if(verbose) cat(paste0("Batch [", nbatch, "] Train-", result$name, "=", result$value, "\n"))
      if (!is.null(logger)) {
        if (class(logger) != "mx.metric.logger.early.stopping") {
          stop("Invalid mx.metric.logger.")
        }
        logger$train <- c(logger$train, result$value)
        if (!is.null(env$eval.metric)) {
          result <- env$metric$get(env$eval.metric)
          if (nbatch != 0)
            cat(paste0("Batch [", nbatch, "] Validation-", result$name, "=", result$value, "\n"))
          logger$eval <- c(logger$eval, result$value)
        }
      }
    }

    logger$best_round <- which.min(logger$eval)
    # if best score did not improve in early.stopping.round the stop!!
    if(length(logger$eval) > logger$best_round + early.stopping.round){
      return(FALSE)
    }

    return(TRUE)
  }
}
