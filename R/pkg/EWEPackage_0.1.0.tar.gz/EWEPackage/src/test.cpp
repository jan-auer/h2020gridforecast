#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;

// [[Rcpp::export]]
void showMatrix(arma::mat X, const char* name) {
  Rcout << name << std::endl << X << std::endl;
}

//' RLS core function
//'
//' comment_bf: docu rudimentary
//'
//' @param y Vector of doubles. NAs must be removed (not checked)
//' @param X Matrix of doubles. dimension = (length(y) x maximal number of regressors)
//' @param n_init Integer. Number of observations used for initial estimate of beta.
//'   If no value provided, at least 21 observations (3 weeks) or 3 times the number of regressors is used.
//' @param end_of_train Integer. Index specifying the end of the training set. (Afterwards the forecasting period starts.)
//'   Important for calculating the honest prediction error (otherwise it would not be out-of-sample...).
//'   comment_bf: If one wants to use arx_rls_core() outside the automated forecasting framework,
//'   set \code{end_of_train} to \code{length(y)}.
//'
//' @return List containing
//'   predictions \code{y_pred} (vector of same length as input y),
//'   honest prediction error \code{fev_honest} (calculated from \code{end_of_train - n_init} observations).
//'
// [[Rcpp::export]]
Rcpp::List arx_rls_core_cpp(const arma::mat y,
                            const arma::mat X,
                            int n_init,
                            int end_of_train){

// Number of observations for initial estimator should be at least 3 weeks or 3 times the number of regressors
//  if (is.null(n_init)){
//     n_init <- max(3*dim(X)[2], 21)
// }

/* Check: End of training period
  if (is.null(end_of_train) || n_init >= end_of_train){
    stop("arx_rls_core(): The end of the training data set must be specified and
      larger than the integer specifying the initial estimation period.")
  }

*/


// forgetting factors
// mat r = zeros(8,1);

  NumericVector r = NumericVector::create(0.9,
                                          0.9500000, 0.9750000, 0.9875000, 0.9937500, 0.9968750, 0.9984375,
                                          1);


  // dimensions
  int k = X.n_cols;
  int n_obs = y.n_rows;

// initial estimator for beta


    mat y_init = zeros(n_init, 1);
    mat X_init = zeros(n_init, k);
    mat P = zeros(k, k);
    mat beta = zeros(k, 1);

    //showMatrix(X_init, "X_init: ");
    X_init = X(span(0, n_init-1), span(0,k-1));
    //showMatrix(X_init, "X_init: ");
    P = pinv(X_init.t() * X_init );
    beta = P * X_init.t() * y_init;


// RLS, see Young page 55
        mat y_pred = zeros(n_obs, 1);
        mat fe_honest = zeros(n_obs, 1);
        mat fev_honest = zeros(8, 1);

        mat y_pred_final = zeros(n_obs, 1);
        mat fev_honest_final = zeros(1, 1);

        int i;
        int j;

        mat x = zeros(1, k);
        mat g = zeros(k, 1);
        mat Px = zeros(k, 1);

        for (i = 0; i < 8; i++){
          //Rprintf("\n %d \n", i);
          for (j = n_init; j < n_obs; j++){
            x = X(j, span());
            //showMatrix(x, "x: ");
            //Rprintf("\n %d \n", r[i]);
            Px = (P * x.t());
            g = Px.each_row() / ( r[i] + x * P * x.t());

            y_pred(span(j), 0) =  x * beta;
            fe_honest(span(j), 0) = y(span(j), 0) - y_pred(span(j), 0);

            beta = beta + g * fe_honest(span(j), 0);
            P = 1/r[i] * ( P - g * x * P );
          }

          fev_honest(span(i), 0) = mean(fe_honest(span(n_init, end_of_train - 1), 0) % fe_honest(span(n_init, end_of_train - 1), 0));

          if (i == 0){
              fev_honest_final = fev_honest(span(i), 0);
              y_pred_final = y_pred;
            } else if ( fev_honest(i, 0) < fev_honest(i-1, 0) ){
              fev_honest_final = fev_honest(span(i), 0);
              y_pred_final = y_pred;
            }
        }

        return Rcpp::List::create(Rcpp::Named("y_pred") = y_pred_final,
                                  Rcpp::Named("fev_honest") = fev_honest_final);
}



