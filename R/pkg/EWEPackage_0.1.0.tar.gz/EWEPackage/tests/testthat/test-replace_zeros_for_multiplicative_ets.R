context('replace_zeros_for_multiplicative_ets testing')

test_that('replace_zeros_for_multiplicative_ets test 1', {

  df <- data_frame(timestamp = rep(ymd_hms("2016-01-01 00:15:00"),12 ), value = c(0,0,3,4,9,0,0,5,6,0,64,0))

  df_zero_free <- replace_zeros_for_multiplicative_ets(df)

  # test if equal
  expect_equal(sum(abs(df_zero_free$value - c(1.5,1.5,3,4,9,7,7,5,6,35,64,32))), 0)


})







