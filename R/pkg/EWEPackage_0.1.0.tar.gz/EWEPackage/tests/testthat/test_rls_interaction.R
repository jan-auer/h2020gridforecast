context("RLS with interactions of dummies and lags")

# Load data ####
load("../../input/TransnetBW/TransnetBW_base.RData")

# Choose representative meter point, postal code, etc. ####
df_load <- TransnetBW_base %>%
  dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
  dplyr::select(ts_load) %>%
  tidyr::unnest()
postal_code <- TransnetBW_base %>%
  dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
  dplyr::select(postal_code) %>%
  as.character()


sliced_df <- create_arx_regression(my_df_load = df_load,
                                   my_postal_code = postal_code,
                                   my_dummies_wday_hb = list(c(1,7), c(2, 3, 4, 5, 6), 8, 9, c(2, 3), c(4,5,6)),
                                   my_lags = dplyr::tibble(lag_day = c(2, 7), lag_q_hour = 0),
                                   data_driven = FALSE)
sliced_df_1 <- sliced_df %>% slice(1) %>% unnest()

ff <- get_interaction_formulas()


test_that("forecasting of one daily time series works as expected", {
  debugonce(arx_rls_interaction)
  timestamp()
  out <- arx_rls_interaction(df = sliced_df_1,
                             model_formula = ff,
                             end_of_train = 730,
                             use_cpp = TRUE)
  timestamp()
  expect_that(max(out$value-out2$value) < sqrt(.Machine$double.eps))
})

test_that("forecasting of one daily time series works as expected in vectorized form", {
  debugonce(arx_rls_interaction_vectorized)
  timestamp()
  out <- arx_rls_interaction_vectorized(df = sliced_df_1,
                             model_formula = ff,
                             end_of_train = 730,
                             use_cpp = TRUE)
  timestamp()
  expect_that(max(out$value-out2$value) < sqrt(.Machine$double.eps))
})


test_that("forecasting of one meterpoint works correctly", {
  debugonce(forecast_rls_interaction)
  timestamp()
  out <- forecast_rls_interaction(my_df_load = df_load,
                                  my_postal_code = postal_code,
                                  from = lubridate::ymd_hms("2016-01-01 00:15:00"),
                                  to = lubridate::ymd("2017-01-01"),
                                  use_cpp = TRUE)
  timestamp()
  expect_that(max(out$value-out2$value) < sqrt(.Machine$double.eps))
})


