context("Recursive least squares")


# Create data for testing arx_rls_core() ####

X_mat <- matrix(rnorm(200), nrow = 100)
y_mat <- X_mat %*% matrix(c(2,3), nrow = 2) + rnorm(100)
end_train <- 90

test_that("Core function does stuff correctly", {
  out <- arx_rls_core(y_mat, X_mat, end_of_train = 90)
  expect_equal(length(out$y_pred), dim(y_mat)[1])
})

test_that("Cpp does stuff",{
  out_cpp <- EWEPackage:::arx_rls_core_cpp(y_mat, X_mat, n_init = 21, end_of_train = 90)
})


# Load and transform data for testing arx_rls() ####

load("../../input/TransnetBW/TransnetBW_base.RData")

df_load <- TransnetBW_base %>%
  dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
  dplyr::select(ts_load) %>%
  tidyr::unnest()

df_load <- df_load %>%  mutate(value_lag_02_00 = dplyr::lag(value, 2),
                               value_lag_07_00 = dplyr::lag(value, 7))

test_that("Stuff works", {
  debugonce(arx_rls)
  out <- arx_rls(df_load, end_of_train = which(df_load$timestamp == ymd_hms("2016-01-01 00:00:00")))
  out$df_prediction
  out$fev_honest
})

# Load data ####
load("../../input/TransnetBW/TransnetBW_base.RData")

# Choose representative meter point, postal code, etc. ####
df_load <- TransnetBW_base %>%
  dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
  dplyr::select(ts_load) %>%
  tidyr::unnest()
postal_code <- TransnetBW_base %>%
  dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
  dplyr::select(postal_code) %>%
  as.character()

test_that("Rcpp generates the same results as non-Rcpp version", {
  out <- forecast_rls(my_df_load = df_load,
             my_postal_code = postal_code,
             from = lubridate::ymd_hms("2016-01-01 00:15:00"),
             to = lubridate::ymd("2017-01-01"),
             model_complexity = 4,
             use_cpp = TRUE)
  out2 <- forecast_rls(my_df_load = df_load,
             my_postal_code = postal_code,
             from = lubridate::ymd_hms("2016-01-01 00:15:00"),
             to = lubridate::ymd("2017-01-01"),
             model_complexity = 4,
             use_cpp = FALSE)
  expect_that(max(out$value-out2$value) < sqrt(.Machine$double.eps))
})

test_that("Non-trivial model_complexity works", {
  debugonce(forecast_rls)
  timestamp()
  out <- forecast_rls(my_df_load = df_load,
                      my_postal_code = postal_code,
                      from = lubridate::ymd_hms("2016-01-01 00:15:00"),
                      to = lubridate::ymd("2017-01-01"),
                      model_complexity = 1,
                      use_cpp = TRUE)
  timestamp()
  expect_that(max(out$value - out2$value) < sqrt(.Machine$double.eps))
})




