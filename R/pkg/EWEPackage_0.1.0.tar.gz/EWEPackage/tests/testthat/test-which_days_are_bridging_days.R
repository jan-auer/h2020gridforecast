context('which_days_are_bridging_days testing')

test_that('which_days_are_bridging_days test', {

  # generate generic holiday data
  holidays <- c(ymd('2017-01-03'), # tuesday
                ymd('2017-01-12'), # thursday
                ymd('2017-01-18'), # wednesday
                ymd('2017-01-20')) # friday

  # test if '2017-01-19' is recognized as a bridging day since it is a day
  # between two holidays
  expect_equal(which_days_are_bridging_days(days_to_check = ymd('2017-01-19'), holidays = holidays), TRUE)


  #check whether the vectorized and non-vectorized versions are in fact equal
  days_to_check <- seq(lubridate::ymd('2014-01-01'), lubridate::ymd('2017-01-01'), by = 'day')
  holidays <- get_holidays_from_postal_code("all")
  tmp <- all(which_days_are_bridging_days(days_to_check, holidays) == map_lgl(days_to_check,
                                                                              ~is_bridging_day(current_day = .x, holidays = holidays)))
  expect_equal(tmp, TRUE)

})
