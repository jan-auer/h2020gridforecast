context('is_bridging_tag testing')

test_that('is_bridging_tag test', {

  # generate generic holiday data
  holidays <- c(ymd('2017-01-03'), # tuesday
                ymd('2017-01-12'), # thursday
                ymd('2017-01-18'), # wednesday
                ymd('2017-01-20')) # friday

  # test if '2017-01-02' is recognized as a bridging day since it is the monday
  # between a sunday and a holiday
  expect_equal(is_bridging_day(current_day = ymd('2017-01-02'), holidays = holidays), TRUE)

  # test if '2017-01-13' is recognized as a bridging day since it is the friday
  # between a holiday and a saturday
  expect_equal(is_bridging_day(current_day = ymd('2017-01-13'), holidays = holidays), TRUE)

  # test if '2017-01-19' is recognized as a bridging day since it is a day
  # between two holidays
  expect_equal(is_bridging_day(current_day = ymd('2017-01-19'), holidays = holidays), TRUE)

  # test if normal monday is not a bridgingday
  expect_equal(is_bridging_day(current_day = ymd('2017-01-23'), holidays = holidays), FALSE)

  # test if normal tuesday is not a bridgingday
  expect_equal(is_bridging_day(current_day = ymd('2017-01-24'), holidays = holidays), FALSE)

  # test if normal wednesday is not a bridgingday
  expect_equal(is_bridging_day(current_day = ymd('2017-01-25'), holidays = holidays), FALSE)

  # test if normal thursday is not a bridgingday
  expect_equal(is_bridging_day(current_day = ymd('2017-01-26'), holidays = holidays), FALSE)

  # test if normal friday is not a bridgingday
  expect_equal(is_bridging_day(current_day = ymd('2017-01-27'), holidays = holidays), FALSE)

  # test if normal saturday is not a bridgingday
  expect_equal(is_bridging_day(current_day = ymd('2017-01-28'), holidays = holidays), FALSE)

  # test if normal sunday is not a bridgingday
  expect_equal(is_bridging_day(current_day = ymd('2017-01-29'), holidays = holidays), FALSE)


})
