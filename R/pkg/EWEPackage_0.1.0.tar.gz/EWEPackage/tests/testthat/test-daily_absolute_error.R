context('daily_absolute_error testing')

test_that('daily_absolute_error test 1', {

  df_actual <-
    data_frame(timestamp = seq(as.POSIXct('2014-01-01', tz = 'UTC'), as.POSIXct('2015-01-01', tz = 'UTC'), by = '15 min'),
               value = -100) # this df has 366 days in there

  df_forecast <- df_actual

  # test if two equal data frames have zero error
  expect_equal(sum(abs(daily_absolute_error(df_actual, df_forecast)$value)), 0)
  # check if
  expect_equal(nrow(daily_absolute_error(df_actual, df_forecast)), 366)

})
