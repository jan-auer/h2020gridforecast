context('Factor model forecasting')

library(tidyverse)   ## 
library(lubridate)   ## for date timestamps
library(EWEPackage)  ##

load("/home/datascience/powR/input/TransnetBW/TransnetBW_base.RData")

#' Choose representative meter point, postal code, etc. ####
df <- TransnetBW_base %>%
dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
dplyr::select(ts_load) %>%
tidyr::unnest()

postal_code <- TransnetBW_base %>%
dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
dplyr::select(postal_code) %>%
as.character()

from <- lubridate::ymd_hms("2016-01-01 00:15:00")
to <- lubridate::ymd_hms("2017-01-01 00:00:00")

## load_all("./pkg/EWEPackage/")

test_that('Stuff works', {
  
  res_ffc <- forecast_fm (df=df, postal_code=postal_code, var_expl = 0.95, n_factors = NULL, from=from, to=to)

})