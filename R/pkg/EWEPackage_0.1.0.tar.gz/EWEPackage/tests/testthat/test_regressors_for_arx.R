context('Create regression variables for ARX models')

  # Load data ####
  load("../../input/TransnetBW/TransnetBW_base.RData")

  # Choose representative meter point, postal code, etc. ####
  b_df_load <- TransnetBW_base %>%
    dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
    dplyr::select(ts_load) %>%
    tidyr::unnest()
  b_postal_code <- TransnetBW_base %>%
    dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
    dplyr::select(postal_code) %>%
    as.character()
  b_id_load <- TransnetBW_base %>%
    dplyr::filter(meter_point_intern == "EWEU_1671959") %>%
    dplyr::select(id_load)
  b_lags <- dplyr::data_frame(lag_day = c(1, 2, 3, 4, 5, 6, 7, 14, 21), lag_q_hour = 0)
  data_driven <- TRUE

  # Different settings for dummies ####
  dummy_combos <- list(
    list(c(1,7), c(2,3,4,5,6), c(8,9), 10), # (Saturday and Sunday), (Monday to Friday), (Hol and Bridge)
    list(2, c(3,4,5), 6, c(7,9), c(1,8), 10) # Monday, (Tue to Thu), Fri, (Sat and Bridge), (Sun and Hol)
  )

  df_load_non_multiple96 <- TransnetBW_base %>%
    dplyr::filter(meter_point_intern == "EWEU_39148538") %>%
    dplyr::select(ts_load) %>%
    tidyr::unnest()

test_that('Output has the correct number of rows', {



  # my_test <- function(x){
  #   out <- create_arx_regression(my_df_load = b_df_load,my_postal_code = b_postal_code, my_lags = NULL, verbose = TRUE,
  #                                my_dummies_wday_hb = x)
  #   return(out[[2]])
  # }
  #
  # my_test(dummy_combos[[1]])
  # my_test(dummy_combos[[2]])

  aa <- create_arx_regression(my_df_load = b_df_load,
                              my_postal_code = b_postal_code,
                              my_lags = data_frame(lag_day = 0, lag_q_hour = 0),
                              verbose = FALSE,
                              my_dummies_wday_hb = list(1, c(2,3,4),5, 6, c(7, 9), 8, 10),
                              data_driven = FALSE)

  expect_equal(nrow(aa), 96)
  # create_arx_regression(my_df_load = b_df_load,my_postal_code = b_postal_code, my_lags = NULL, verbose = TRUE,
  #                       my_dummies_wday_hb = list(c(1,7), c(2,6), c(3,4,5)))




  #################


  # wd1 <- list(c(1,2,3,4,5,6,7), 8, 9)
  # 8 %in% wd1
  # wd2 <- list(c(8,9))
  # 8 %in% wd2
  # 8 %in% unlist(wd2)
  # dummies_wday
  # dummies_listcol %>% slice(1) %>% unnest()
  #
  # # Too many zeros ####
  #
  # load_w_zeros <- TransnetBW_base %>%
  #   filter(id_customer == "141192") %>%
  #   slice(1) %>%
  #   select(ts_load) %>%
  #   unnest()
  # postal_code_w_zeros <- TransnetBW_base %>%
  #   filter(id_customer == "141192") %>%
  #   slice(1) %>%
  #   select(postal_code) %>%
  #   as.character()
  # debugonce(create_arx_regression)
  # aa <- create_arx_regression(my_df_load = load_w_zeros,
  #                             my_postal_code = postal_code_w_zeros,
  #                             my_lags = data_frame(lag_day = 0, lag_q_hour = 0),
  #                             verbose = FALSE,
  #                             my_dummies_wday_hb = list(1, c(2,3,4),5, 6, c(7, 9), 8, 10),
  #                             data_driven = TRUE)


})

expect_that("School holidays (dummy_10) are part of the regressors", {
  out <- create_arx_regression(my_df_load = b_df_load,
                        my_postal_code = b_postal_code,
                        my_lags = data_frame(lag_day = 0, lag_q_hour = 0),
                        verbose = TRUE,
                        my_dummies_wday_hb = list(c(1,2,3,4,5, 6,7), 10),
                        data_driven = FALSE)

  nn <- names(out[[2]])

  expect_true("dummy_10" %in% nn)

})

expect_that("If number of observations is not a multiple of 96, then no observation is lost through slicing in univariate time series",{
  o <- create_arx_regression(my_df_load = df_load_non_multiple96,
                        my_postal_code = NULL,
                        my_lags = data_frame(lag_day = 0, lag_q_hour = 0),
                        verbose = TRUE,
                        my_dummies_wday_hb = list(c(1,7), c(2,3,4,5,6)),
                        data_driven = FALSE)

  nn1 <- nrow(df_load_non_multiple96)
  nn2 <- o[[1]] %>% mutate(a = map_int(univ_regr, ~ nrow(.x))) %>% summarise(sum(a))
  expect_equal(nn2, nn1)


})
