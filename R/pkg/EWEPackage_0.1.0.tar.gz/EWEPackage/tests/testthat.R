library(testthat)
library(EWEPackage)

test_check("EWEPackage")
