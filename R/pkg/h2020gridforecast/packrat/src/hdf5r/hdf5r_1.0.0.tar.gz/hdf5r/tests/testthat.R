library(testthat)
library(hdf5r)

test_check("hdf5r")

